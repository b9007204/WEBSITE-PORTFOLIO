// b9007204_assignment1_2.cpp.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include "pch.h"
#include <iostream>
#include <iomanip>
#include <string>

using namespace std;


string month; //declaring the variable of month input as a string, as it will be typed as "january" or "february

int date; //declaring the date as an interger



void getDate(); //declaring the function for 'getDate();' which contains the system prompting the user to input the month and date.


//start of void function declaration for retreiving day from given month -----------------------
void getJanMonth();
void getFebMonth();
void getMarMonth();
void getAprMonth();
void getMayMonth();
void getJunMonth();
void getJulMonth();  //this is where i declare the functions to be used later on in the code
void getAugMonth();
void getSepMonth();
void getOctMonth();
void getNovMonth();
void getDecMonth();
//end of void function declaration for retreiving day from given month--------------------------



int main()
{
	cout << "This program will find the day of a given date!" << endl;
	cout << endl;
	cout << "Please don't use capital letters! EG 'january' not 'January'!" << endl;
	cout << endl;
	getDate(); //calls the function for user input of month and date.


	//------------------------------------------------------------------------------------------
	getJanMonth();		   //after getDate(); is called, which is for user input, these functions are called.
	getFebMonth();		   
	getMarMonth();		   //these functions wont run unless the if statements are met. For example, if the month input is january, then only getjanMonth(); will run
	getAprMonth();
	getMayMonth();         //calls the functions for getting the day of '________' from a given date.
	getJunMonth();		   
	getJulMonth();	       //these functions contain 'cout' functions to output what day the date falls on
	getAugMonth();
	getSepMonth();         //these functions contain the if statements for if the month is january
	getOctMonth();		   
	getNovMonth();		   //they also contain switch cases. So if the date is 1, 8, 15 ect.. then it will output the day.
	getDecMonth();
	//------------------------------------------------------------------------------------------


}

void getDate()
{

	cout << "Please input month : \n";			//prompt for user to input month
	
	cin >> month;								//user input for month



	cout << "Please input the date : \n";       //prompt user to input date
	
	cin >> date;								//user input for date
}


//function for getting day of january from given date--------------------------------------------
void getJanMonth()					 //this function will ask the system if the string declared as 'month' is 'january', then use a switch to 
{									 //assign 'tuesday' to case 1,8,15,22 and 29, which are all tuesdays within january. 
	if (month == "january")
	{
		switch (date)
		{
		case 1: case 8: case 15: case 22: case 29:
			cout << "The day is Tuesday! \n";
			break;

		case 2: case 9: case 16: case 23: case 30:			//the same would go for wednesday, 2,9,16,23 and 30 are all wednesdays.
			cout << "The day is Wednesday! \n";
			break;

		case 3: case 10: case 17: case 24: case 31:
			cout << "The day is Thursday! \n";
			break;

		case 4: case 11: case 18: case 25:
			cout << "The day is Friday! \n";
			break;

		case 5: case 12: case 19: case 26:
			cout << "The day is Saturday! \n";
			break;

		case 6: case 13: case 20: case 27:
			cout << "The day is Sunday! \n";
			break;

		case 7: case 14: case 21: case 28:
			cout << "The day is Monday! \n";
			break;
		}
	}
}
//end of function for getting day of january from given date-------------------------------------



//function for getting day of february from given date-------------------------------------------
void getFebMonth()
{
	if (month == "february")
	{
		switch (date)
		{
		case 1: case 8: case 15: case 22:
			cout << "The day is Friday! \n";
			break;

		case 2: case 9: case 16: case 23:
			cout << "The day is Saturday! \n";
			break;

		case 3: case 10: case 17: case 24:
			cout << "The day is Sunday! \n";
			break;

		case 4: case 11: case 18: case 25:
			cout << "The day is Monday! \n";
			break;

		case 5: case 12: case 19: case 26:
			cout << "The day is Tuesday! \n";
			break;

		case 6: case 13: case 20: case 27:
			cout << "The day is Wednesday! \n";
			break;

		case 7: case 14: case 21: case 28:
			cout << "The day is Thursday! \n";
			break;
		}
	}
}
//end of function for getting day of february from given date -----------------------------------



//function for getting day of march from given date----------------------------------------------
void getMarMonth()
{
	if (month == "march")
	{
		switch (date)
		{
		case 1: case 8: case 15:  case 22:  case 29:
			cout << "The day is Friday! \n";
			break;

		case 2: case 9: case 16: case 23: case 30:
			cout << "The day is Saturday! \n";
			break;

		case 3: case 10: case 17: case 24: case 31:
			cout << "The day is Sunday! \n";
			break;

		case 4: case 11: case 18: case 25:
			cout << "The day is Monday! \n";
			break;

		case 5: case 12: case 19: case 26:
			cout << "The day is Tuesday! \n";
			break;

		case 6: case 13: case 20: case 27:
			cout << "The day is Wednesday! \n";
			break;

		case 7: case 14: case 21: case 28:
			cout << "The day is Thursday! \n";
			break;
		}
	}
}
//end of function for getting day of march from given date---------------------------------------



//function for getting day of april from given date----------------------------------------------
void getAprMonth()
{
	if (month == "april")
	{
		switch (date)
		{
		case 1: case 8: case 15: case 22: case 29:
			cout << "The day is Monday! \n";
			break;

		case 2: case 9: case 16: case 23:  case 30:
			cout << "The day is Tuesday! \n";
			break;

		case 3: case 10: case 17: case 24:
			cout << "The day is Wednesday! \n";
			break;

		case 4: case 11: case 18: case 25:
			cout << "The day is Thursday! \n";
			break;

		case 5: case 12: case 19: case 26:
			cout << "The day is Friday! \n";
			break;

		case 6: case 13: case 20: case 27:
			cout << "The day is Saturday! \n";
			break;

		case 7: case 14: case 21: case 28:
			cout << "The day is Sunday! \n";
			break;
		}
	}
}
//end of function for getting day of april for given date----------------------------------------



//function for getting day of may from given date------------------------------------------------
void getMayMonth()
{
	if (month == "may")
	{
		switch (date)
		{
		case 1: case 8: case 15: case 22: case 29:
		
			cout << "The day is Wednesday! \n";
			break;

		case 2: case 9: case 16: case 23: case 30:
			cout << "The day is Thursday! \n";
			break;

		case 3: case 10: case 17: case 24: case 31:
			cout << "The day is Friday! \n";
			break;

		case 4: case 11: case 18: case 25:
			cout << "The day is Saturday! \n";
			break;

		case 5: case 12: case 19: case 26:
			cout << "The day is Sunday! \n";
			break;

		case 6: case 13: case 20: case 27:
			cout << "The day is Monday! \n";
			break;

		case 7: case 14: case 21: case 28:
			cout << "The day is Tuesday! \n";
			break;

		}
	}
}
//end of function for getting day of may from given date-----------------------------------------



//function for getting day of june from given date-----------------------------------------------
void getJunMonth()
{
	if (month == "june")
	{
		switch (date)
		{

			case 1: case 8: case 15: case 22: case 29:
				cout << "The day is Saturday! \n";
				break;

			case 2: case 9: case 16: case 23: case 30:
				cout << "The day is Sunday! \n";
				break;

			case 3: case 10: case 17: case 24:
				cout << "The day is Monday! \n";
				break;

			case 4: case 11: case 18: case 25:
				cout << "The day is Tuesday! \n";
				break;

			case 5: case 12: case 19: case 26:
				cout << "The day is Wednesday! \n";
				break;

			case 6: case 13: case 20: case 27:
				cout << "The day is Thursday! \n";
				break;

			case 7: case 14: case 21: case 28:
				cout << "The day is Friday! \n";
				break;

			
		}
	}
}
//end of function for getting day of june from given date----------------------------------------



//function for getting day of july from given date-----------------------------------------------
void getJulMonth()
{
	if (month == "july")
	{
		switch (date)
		{
		case 1: case 8: case 15: case 22: case 29:
			cout << "The day is Monday! \n";
			break;

		case 2: case 9: case 16: case 23: case 30:
			cout << "The day is Tuesday! \n";
			break;

		case 3: case 10: case 17: case 24: case 31:
			cout << "The day is Wednesday! \n";
			break;

		case 4: case 11: case 18: case 25:
			cout << "The day is Thursday! \n";
			break;

		case 5: case 12: case 19: case 26:
			cout << "The day is Friday! \n";
			break;

		case 6: case 13: case 20: case 27:
			cout << "The day is Saturday! \n";
			break;

		case 7: case 14: case 21: case 28:
			cout << "The day is Sunday! \n";
			break;
		}
	}
}
//end of function for getting day of july from given date----------------------------------------



//function for getting day of august from given date---------------------------------------------
void getAugMonth()
{
	if (month == "august")
	{
		switch (date)
		{
		case 1: case 8: case 15: case 22: case 29:
			cout << "The day is Thursday! \n";
			break;

		case 2: case 9: case 16: case 23: case 30:
			cout << "The day is Friday! \n";
			break;

		case 3:	case 10: case 17: case 24: case 31:
			cout << "The day is Saturday! \n";
			break;

		case 4: case 11: case 18: case 25:
			cout << "The day is Sunday! \n";
			break;

		case 5: case 12: case 19: case 26:
			cout << "The day is Monday! \n";
			break;

		case 6: case 13: case 20: case 27:
			cout << "The day is Tuesday! \n";
			break;

		case 7: case 14: case 21: case 28:
			cout << "The day is Wednesday! \n";
			break;
		}
	}
}
//end of function for getting day of august from given date--------------------------------------



//function for getting day of september from given date------------------------------------------
void getSepMonth()
{
	if (month == "september")
	{
		switch (date)
		{
		case 1: case 8: case 15: case 22: case 29:
			cout << "The day is Sunday! \n";
			break;

		case 2: case 9: case 16: case 23: case 30:
			cout << "The day is Monday! \n";
			break;

		case 3:	case 10: case 17: case 24:
			cout << "The day is Tuesday! \n";
			break;

		case 4: case 11: case 18: case 25:
			cout << "The day is Wednesday! \n";
			break;

		case 5: case 12: case 19: case 26:
			cout << "The day is Thursday! \n";
			break;

		case 6: case 13: case 20: case 27:
			cout << "The day is Friday! \n";
			break;

		case 7: case 14: case 21: case 28:
			cout << "The day is Saturday! \n";
			break;
		}
	}
}
//end of function for getting day of september from given date-----------------------------------



//function for getting day of october from given date--------------------------------------------
void getOctMonth()
{
	if (month == "october")
	{
		switch (date)
		{
		case 1: case 8: case 15: case 22: case 29:
			cout << "The day is Tuesday! \n";
			break;

		case 2: case 9: case 16: case 23: case 30:
			cout << "The day is Wednesday! \n";
			break;

		case 3:	case 10: case 17: case 24: case 31:
			cout << "The day is Thursday! \n";
			break;

		case 4: case 11: case 18: case 25:
			cout << "The day is Friday! \n";
			break;

		case 5: case 12: case 19: case 26:
			cout << "The day is Saturday! \n";
			break;

		case 6: case 13: case 20: case 27:
			cout << "The day is Sunday! \n";
			break;

		case 7: case 14: case 21: case 28:
			cout << "The day is Monday! \n";
			break;
		}
	}

}
//end of function for getting day of october from given date-------------------------------------



//function for getting day of november from given date ------------------------------------------
void getNovMonth()
{
	if (month == "november")
	{
		switch (date)
		{
		case 1: case 8: case 15: case 22: case 29:
			cout << "The day is Friday! \n";
			break;

		case 2: case 9: case 16: case 23: case 30:
			cout << "The day is Saturday! \n";
			break;

		case 3:	case 10: case 17: case 24:
			cout << "The day is Sunday! \n";
			break;

		case 4: case 11: case 18: case 25:
			cout << "The day is Monday! \n";
			break;

		case 5: case 12: case 19: case 26:
			cout << "The day is Tuesday! \n";
			break;

		case 6: case 13: case 20: case 27:
			cout << "The day is Wednesday! \n";
			break;

		case 7: case 14: case 21: case 28:
			cout << "The day is Thursday! \n";
			break;
		}
	}
}
//end of function for getting day of octover from given date-------------------------------------



//function for getting day of december from given date-------------------------------------------
void getDecMonth()
{
	if (month == "december")
	{
		switch (date)
		{
		case 1: case 8: case 15: case 22: case 29:
			cout << "The day is Sunday! \n";
			break;

		case 2: case 9: case 16: case 23: case 30:
			cout << "The day is Monday! \n";
			break;

		case 3:	case 10: case 17: case 24: case 31:
			cout << "The day is Tuesday! \n";
			break;

		case 4: case 11: case 18: case 25:
			cout << "The day is Wednesday! \n";
			break;

		case 5: case 12: case 19: case 26:
			cout << "The day is Thursday! \n";
			break;

		case 6: case 13: case 20: case 27:
			cout << "The day is Friday! \n";
			break;

		case 7: case 14: case 21: case 28:
			cout << "The day is Saturday! \n";
			break;
		}
	}
}
//end of function for getting day of december from given date------------------------------------