// b9007204_assignment1_1a.cpp.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include "pch.h"
#include <iostream>
#include <iomanip>
#include <string>

using namespace std;

int main()
{
	int num1, num2, num3;

	cout << "Please enter num1 \n" << endl;  //this prompts the user to enter the first number 
	cin >> num1;   //this allows the user to enter a number into the system

	cout << "Please enter num2 \n" << endl; //same as previous
	cin >> num2;

	cout << "Please enter num3 \n" << endl; //same as previous
	cin >> num3;
	cout << endl;


	if (num1 < num2 && num2 < num3)
		cout << num1 << endl << num2 << endl << num3 << endl; 
	/*if num1 is smaller than num2, and num2 is smaller
	than num3, then the system will output num1,num2 and
	num3.*/

	else if (num1 < num3 && num3 < num2)
		cout << num1 << endl << num3 << endl << num2 << endl; 
	/*if num1 is smaller than num3, and num3 is smaller
	than num2, then the system will output num1, num3 and
	num2.*/

	else if (num2 < num1 && num1 < num3)
		cout << num2 << endl << num1 << endl << num3 << endl; 
	/*if num2 is smaller than num1, and num1 is smaller
	than num3, then the system will output num2, num1 and
	num3.*/

	else if (num2 < num3 && num3 < num1)
		cout << num2 << endl << num3 << endl << num1 << endl; 
	/*if num2 is smaller than num3 and num 3 is smaller
	than num1, then the system will output num2, num3 and
	num1.*/

	else if (num3 < num1 && num1 < num2)
		cout << num3 << endl << num1 << endl << num2 << endl; 
	/*if num 3 is smaller than num1 and num1 is smaller
	than num2, and the system will output num3, num1 and
	num 2*/


	else if (num3 < num2 && num2 < num1)
		cout << num3 << endl << num2 << endl << num1 << endl; 
	/*if num3 is smaller than num2 and num2 is smaller
	than num1 then the system will output num3, num2 and
	num1*/

}
