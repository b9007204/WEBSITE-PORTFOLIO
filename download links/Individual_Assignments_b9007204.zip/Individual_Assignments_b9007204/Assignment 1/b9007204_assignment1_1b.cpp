// b9007204_assignment1_1b.cpp.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include "pch.h"
#include <iostream>
#include <iomanip>
#include <string>

using namespace std;


int main()
{
	string string1;   //these declare the strings for use later in the code. just like delcaring int's
	string string2;   //this is called declaring variables.
	string string3;

	cout << "This program will sort words alphabetically! \n" << endl;

	cout << "Please enter the first word : \n" << endl;  //this prompts the user to enter the first word.
	cin >> string1;   //this allows the user to input the first word, which would be string1, as declared above.

	cout << "Please enter the second word : \n" << endl;  //same as above
	cin >> string2;

	cout << "Please enter the third word : \n" << endl;   //same as above
	cin >> string3;



	if (string1 < string2 && string2 < string3)
		cout << string1 << string2 << string3 << endl;     /*this tells the system to output the strings
															 as shown in line 31. if string 1 is smaller than
															 string 2, and string2 is smaller than string3,
															 the system will output string1, string2 and string3
															 in that order. This is the same as the below code.*/

	else if (string1 < string3 && string3 < string2)
		cout << string1 << string3 << string2 << endl;

	else if (string2 < string1 && string1 < string3)
		cout << string2 << string1 << string3 << endl;

	else if (string2 < string3 && string3 < string1)
		cout << string2 << string3 << string1 << endl;

	else if (string3 < string1 && string1 < string2)
		cout << string3 << string1 << string2 << endl;

	else if (string3 < string2 && string2 < string1)
		cout << string3 << string2 << string1 << endl;
}

