// b9007204_assignment3.cpp.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include "pch.h"
#include <iostream>
#include <string>
using namespace std;

int a = 1000;	//start digit


int digits; //
int tens;
int hundreds;
int thousands;


int average;

int sumCounter;

int number;

int totalNumber;

int eightAndTwoCounter = 0; //declaraion for the counter for 8s and 2s. this sets the counter to zero before it starts.

void countingEightandTwoAndSum();



int main()
{
	cout << "the numbers 8 and 2 appear: ";
	countingEightandTwoAndSum();  //calls the function containing the sum and the count of 8 and 2.

	cout << endl;
	cout << endl;
}


void countingEightandTwoAndSum()
{
	for (a > 999; a <= 2000; a++) //for variable a being greater than 999, and less than or equal to 2000, a increments by 1. 
	{
		thousands = (a / 1000) % 10;  //thousands digit is (a divided by 1000) then get the modulus of that. same for all and their respective divisors.
		hundreds = (a / 100) % 10;
		tens = (a / 10) % 10;		//if a was 1032 and this was divided by 10, like in the brackets, it would be 103.2. the modulus of this would be 3.2. because 100 divided by 10 is 10, and the remainding 3.2 is the modulus.
		digits = (a / 1) % 10;
		if (thousands == 8 || thousands == 2 || hundreds == 8 || hundreds == 2 || tens == 8 || tens == 2 || digits == 8 || digits == 2) //if any of the digits contain 2 or 8
		{
			eightAndTwoCounter++; //increment the eight and two counter
			totalNumber = totalNumber + a; //the total number is itsself plus the original number (a)
		}
	}
	cout << eightAndTwoCounter << endl;
	cout << "The Sum of All Numbers containing 8 and 2 is: " << totalNumber << endl; //outputs the sum. 

	average = totalNumber / eightAndTwoCounter; //the average is the total number divided by how many times 8 and 2 appear.

	cout << "The Average of all numbers containing 8 and 2 is: " << average; //outputs the average after informing the user what is about to be shown.
}