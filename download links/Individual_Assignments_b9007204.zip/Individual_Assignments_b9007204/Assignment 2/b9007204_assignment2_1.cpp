// b9007204_assignment2_1.cpp.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include "pch.h"
#include <iostream>
#include <iomanip>
#include <string>
#include <cmath>

using namespace std;

//----------------------------------------------------------------------------------
int a;
int b;					//Interger declaration.
int c;

//----------------------------------------------------------------------------------




int main()
{
	//----------------------------------------------------------------------------------
	cout << "This program will calculte the Highest Common Factor of Two Positive Numbers!";
	cout << endl;				//system output for declaring what the program is for.
	//----------------------------------------------------------------------------------


	//----------------------------------------------------------------------------------
	cout << "Please input the first Number!";
	cout << endl;										//user input for first number
	cin >> a;
	//----------------------------------------------------------------------------------


	//----------------------------------------------------------------------------------
	cout << "Please input the second Number!";
	cout << endl;										//user input for second number
	cin >> b;
	//----------------------------------------------------------------------------------


	c = a % b;			//The modulus of a and b equals c
	while (c != 0)
	{
		a = b;
		b = c;

		c = a % b;
	}

	cout << "Highest Common factor :" << b;

}