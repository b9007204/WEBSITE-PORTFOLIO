// b9007204_assignment2_2.cpp.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include "pch.h"
#include <iostream>
#include <iomanip>
#include <string>
#include <cstdlib> //this allows the program to use the random number function, rand().
#include <cmath> //This allows the program to use advanced math such as the sqrt() function. (square root)

using namespace std;

//----------------------------choices declaration Start----------------------------------
int a = 1;
int b = 2;
int c = 3;
int d = 4;

int y, Y;
int n, N;

int timesTableInt;
//----------------------------Choices Declaration End------------------------------------



//----------------------------Float Declaration Start------------------------------------
float x;

//----------------------------Float Declaration End--------------------------------------



//----------------------------String Declaration Start-----------------------------------
int menuChoice;
string endChoice;

//----------------------------String Declaration End-------------------------------------



//----------------------------Function Declaration Start---------------------------------
void randomNumber();
void squareRootFunction();
void timesTable();

//----------------------------Function Declaration End-----------------------------------



//----------------------------Main Starts Here-------------------------------------------
int main()
{
	do {		//i have added a do statement, so at the end of the menu, a while statement is added to allow the user to enter y or n to exit or continue.
//----------------------------Menu-------------------------------------------------------
		cout << "=====================================================" << endl;
		cout << "1 : Generate 5 random numbers(between 0 to 500)" << endl;
		cout << "2 : Square Root" << endl;
		cout << "3 : Generate Times Table" << endl;
		cout << "4 : Exit" << endl;
		cout << "=====================================================" << endl;
		cout << endl;
		cout << endl;
		cout << "Select a number from the menu above: 1-4" << endl;
		cout << endl;
		cin >> menuChoice;
		cout << endl;

		//---------------------------Menu End----------------------------------------------------

		if (menuChoice == 1)			//this part of the main lets the system decide the menu number to execute based on user input.
		{								//IF the menu choice is 1, then the switch executes case 1, which is the random number function.
			switch (menuChoice)
			{
			case 1:

				randomNumber();
				cout << endl;
				break;
			}

		}

		else if (menuChoice == 2)		//if the choice is 2, execute square root function
		{
			switch (menuChoice)
			{
			case 2:
				squareRootFunction();
				cout << endl;
			}

		}

		else if (menuChoice == 3)		//if the menu choice is 3, execute timesTable() function.
		{
			switch (menuChoice)
			{
			case 3:
				timesTable();
			}
		}

		else if (menuChoice == 4)			//if the menuChoice is 4, execute exit.
		{
			switch (menuChoice)
			{
			case 4:
				exit(0);
			}
		}

		cout << endl;
		cout << "Would you like to start again? Press either Y or N: " << endl;
		cin >> endChoice;
		cout << endl;
		cout << endl;


	} while (endChoice == "y" || endChoice == "Y");				//this section ends the DO statement that the main started with, with a while statement. this ends the program.
	if (endChoice == "n" || "N")								//if the end choice is not y, it doesnt fit the while statement. then it asks if, the end choice n then the program exits.
	{
		exit(0);
	}
	system("pause");
	return main();


}

//function creation below.---------------------------------------------------------------

//-------------------------Function Creation For Random Number---------------------------
void randomNumber()
{
	cout << "Your random numbers are: " << endl;
	cout << rand() % 100 * 5 << endl;		//the numbers are generated using rand() which was allowed with #include <cstdlib>. i then modulus this by 100 and times it by 5. 
	cout << rand() % 100 * 5 << endl;		//so the random number is 'modulus'ed' to a number smaller than 100, and then multiplied by 5 to ensure it doesn't exceed 500.
	cout << rand() % 100 * 5 << endl;
	cout << rand() % 100 * 5 << endl;
	cout << rand() % 100 * 5 << endl;
}
//------------------------Function Creation For Random Number End------------------------


//------------------------Function Creation for Finding Square Root----------------------
void squareRootFunction()
{
	cout << "=========================================================" << endl;
	cout << "Please input a Positive Integer to find the Square root!" << endl;
	cin >> x;
	cout << endl;

	if (x < 0)
	{
		cout << "Don't be silly! I said a POSITIVE Integer" << endl;
		cout << "=========================================================" << endl;

	}
	else if (x > 0)
	{
		float result = sqrt(x);
		cout << "The square root of " << x << " is " << result << endl;
		cout << "=========================================================" << endl;

	}
}
//------------------------Function Creation For Finding Square Root End------------------



//------------------------Function Creation For Times Tables 1-15------------------------
void timesTable()
{
	cout << "===========================================================================" << endl;
	cout << "Please input a Integer between 1-15 to return the times table up to times 12" << endl;
	cout << "===========================================================================" << endl;
	cout << endl;
	cin >> timesTableInt;
	cout << endl;

	if (timesTableInt == 1) //1 times table
	{
		cout << "1 x 1 = 1" << endl;			//if the number entered to get the times table is "1", then the system will display the 1 times table.
		cout << "1 x 2 = 2" << endl;
		cout << "1 x 3 = 3" << endl;
		cout << "1 x 4 = 4" << endl;
		cout << "1 x 5 = 5" << endl;
		cout << "1 x 6 = 6" << endl;
		cout << "1 x 7 = 7" << endl;
		cout << "1 x 8 = 8" << endl;
		cout << "1 x 9 = 9" << endl;
		cout << "1 x 10 = 10" << endl;
		cout << "1 x 11 = 11" << endl;
		cout << "1 x 12 = 12" << endl;
		cout << endl;
		cout << "That was the Times table for 1!" << endl;
		cout << "===========================================================================";
		cout << endl;
	}

	else if (timesTableInt == 2) //2 times table
	{
		cout << "2 x 1 = 2" << endl;
		cout << "2 x 2 = 4" << endl;
		cout << "2 x 3 = 6" << endl;
		cout << "2 x 4 = 8" << endl;
		cout << "2 x 5 = 10" << endl;
		cout << "2 x 6 = 12" << endl;
		cout << "2 x 7 = 14" << endl;
		cout << "2 x 8 = 16" << endl;
		cout << "2 x 9 = 18" << endl;
		cout << "2 x 10 = 20" << endl;
		cout << "2 x 11 = 22" << endl;
		cout << "2 x 12 = 24" << endl;
		cout << endl;
		cout << "That was the Times Table for 2!" << endl;
		cout << "===========================================================================";
		cout << endl;
	}

	else if (timesTableInt == 3) //3 times table
	{
		cout << "3 x 1 = 3" << endl;
		cout << "3 x 2 = 6" << endl;
		cout << "3 x 3 = 9" << endl;
		cout << "3 x 4 = 12" << endl;
		cout << "3 x 5 = 15" << endl;
		cout << "3 x 6 = 18" << endl;
		cout << "3 x 7 = 21" << endl;
		cout << "3 x 8 = 24" << endl;
		cout << "3 x 9 = 27" << endl;
		cout << "3 x 10 = 30" << endl;
		cout << "3 x 11 = 33" << endl;
		cout << "3 x 12 = 36" << endl;
		cout << endl;
		cout << "That was the Times Table for 3!" << endl;
		cout << "===========================================================================";
		cout << endl;
	}

	else if (timesTableInt == 4) //4 times table
	{
		cout << "4 x 1 = 4" << endl;
		cout << "4 x 2 = 8" << endl;
		cout << "4 x 3 = 12" << endl;
		cout << "4 x 4 = 16" << endl;
		cout << "4 x 5 = 20" << endl;
		cout << "4 x 6 = 24" << endl;
		cout << "4 x 7 = 28" << endl;
		cout << "4 x 8 = 32" << endl;
		cout << "4 x 9 = 36" << endl;
		cout << "4 x 10 = 40" << endl;
		cout << "4 x 11 = 44" << endl;
		cout << "4 x 12 = 48" << endl;
		cout << endl;
		cout << "That was the Times Table for 4!" << endl;
		cout << "===========================================================================";
		cout << endl;
	}

	else if (timesTableInt == 5) //5 times table
	{
		cout << "5 x 1 = 5" << endl;
		cout << "5 x 2 = 10" << endl;
		cout << "5 x 3 = 15" << endl;
		cout << "5 x 4 = 20" << endl;
		cout << "5 x 5 = 25" << endl;
		cout << "5 x 6 = 30" << endl;
		cout << "5 x 7 = 35" << endl;
		cout << "5 x 8 = 40" << endl;
		cout << "5 x 9 = 45" << endl;
		cout << "5 x 10 = 50" << endl;
		cout << "5 x 11 = 55" << endl;
		cout << "5 x 12 = 60" << endl;
		cout << endl;
		cout << "That was the Times Table for 5!" << endl;
		cout << "===========================================================================";
		cout << endl;
	}

	else if (timesTableInt == 6) //6 times table
	{
		cout << "6 x 1 = 6" << endl;
		cout << "6 x 2 = 12" << endl;
		cout << "6 x 3 = 18" << endl;
		cout << "6 x 4 = 24" << endl;
		cout << "6 x 5 = 30" << endl;
		cout << "6 x 6 = 36" << endl;
		cout << "6 x 7 = 42" << endl;
		cout << "6 x 8 = 48" << endl;
		cout << "6 x 9 = 54" << endl;
		cout << "6 x 10 = 60" << endl;
		cout << "6 x 11 = 66" << endl;
		cout << "6 x 12 = 72" << endl;
		cout << endl;
		cout << "That was the Times Table for 6!" << endl;
		cout << "===========================================================================";
		cout << endl;
	}

	else if (timesTableInt == 7) //7 times table
	{
		cout << "7 x 1 = 7" << endl;
		cout << "7 x 2 = 14" << endl;
		cout << "7 x 3 = 21" << endl;
		cout << "7 x 4 = 28" << endl;
		cout << "7 x 5 = 35" << endl;
		cout << "7 x 6 = 42" << endl;
		cout << "7 x 7 = 49" << endl;
		cout << "7 x 8 = 56" << endl;
		cout << "7 x 9 = 63" << endl;
		cout << "7 x 10 = 70" << endl;
		cout << "7 x 11 = 77" << endl;
		cout << "7 x 12 = 84" << endl;
		cout << endl;
		cout << "That was the Times Table for 7!" << endl;
		cout << "===========================================================================";
		cout << endl;
	}

	else if (timesTableInt == 8) //8 times table
	{
		cout << "8 x 1 = 8" << endl;
		cout << "8 x 2 = 16" << endl;
		cout << "8 x 3 = 24" << endl;
		cout << "8 x 4 = 32" << endl;
		cout << "8 x 5 = 40" << endl;
		cout << "8 x 6 = 48" << endl;
		cout << "8 x 7 = 56" << endl;
		cout << "8 x 8 = 64" << endl;
		cout << "8 x 9 = 72" << endl;
		cout << "8 x 10 = 80" << endl;
		cout << "8 x 11 = 88" << endl;
		cout << "8 x 12 = 96" << endl;
		cout << endl;
		cout << "That was the Times Table for 8!" << endl;
		cout << "===========================================================================";
		cout << endl;
	}

	else if (timesTableInt == 9) //9 times table
	{
		cout << "9 x 1 = 9" << endl;
		cout << "9 x 2 = 18" << endl;
		cout << "9 x 3 = 27" << endl;
		cout << "9 x 4 = 36" << endl;
		cout << "9 x 5 = 45" << endl;
		cout << "9 x 6 = 54" << endl;
		cout << "9 x 7 = 63" << endl;
		cout << "9 x 8 = 72" << endl;
		cout << "9 x 9 = 81" << endl;
		cout << "9 x 10 = 90" << endl;
		cout << "9 x 11 = 99" << endl;
		cout << "9 x 12 = 108" << endl;
		cout << endl;
		cout << "That was the Times Table for 9!" << endl;
		cout << "===========================================================================";
		cout << endl;
	}

	else if (timesTableInt == 10) //10 times table
	{
		cout << "10 x 1 = 10" << endl;
		cout << "10 x 2 = 20" << endl;
		cout << "10 x 3 = 30" << endl;
		cout << "10 x 4 = 40" << endl;
		cout << "10 x 5 = 50" << endl;
		cout << "10 x 6 = 60" << endl;
		cout << "10 x 7 = 70" << endl;
		cout << "10 x 8 = 80" << endl;
		cout << "10 x 9 = 90" << endl;
		cout << "10 x 10 = 100" << endl;
		cout << "10 x 11 = 110" << endl;
		cout << "10 x 12 = 120" << endl;
		cout << endl;
		cout << "That was the Times Table for 10!" << endl;
		cout << "===========================================================================";
		cout << endl;
	}

	else if (timesTableInt == 11) //11 times table
	{
		cout << "11 x 1 = 11" << endl;
		cout << "11 x 2 = 22" << endl;
		cout << "11 x 3 = 33" << endl;
		cout << "11 x 4 = 44" << endl;
		cout << "11 x 5 = 55" << endl;
		cout << "11 x 6 = 66" << endl;
		cout << "11 x 7 = 77" << endl;
		cout << "11 x 8 = 88" << endl;
		cout << "11 x 9 = 99" << endl;
		cout << "11 x 10 = 110" << endl;
		cout << "11 x 11 = 121" << endl;
		cout << "11 x 12 = 132" << endl;
		cout << endl;
		cout << "That was the Times Table for 11!" << endl;
		cout << "===========================================================================";
		cout << endl;
	}

	else if (timesTableInt == 12) //12 times table
	{
		cout << "12 x 1 = 12" << endl;
		cout << "12 x 2 = 24" << endl;
		cout << "12 x 3 = 36" << endl;
		cout << "12 x 4 = 48" << endl;
		cout << "12 x 5 = 60" << endl;
		cout << "12 x 6 = 72" << endl;
		cout << "12 x 7 = 84" << endl;
		cout << "12 x 8 = 96" << endl;
		cout << "12 x 9 = 108" << endl;
		cout << "12 x 10 = 120" << endl;
		cout << "12 x 11 = 132" << endl;
		cout << "12 x 12 = 144" << endl;
		cout << endl;
		cout << "That was the Times Table for 12!" << endl;
		cout << "===========================================================================";
		cout << endl;
	}

	else if (timesTableInt == 13) //13 times table
	{
		cout << "13 x 1 = 13" << endl;
		cout << "13 x 2 = 26" << endl;
		cout << "13 x 3 = 39" << endl;
		cout << "13 x 4 = 52" << endl;
		cout << "13 x 5 = 65" << endl;
		cout << "13 x 6 = 78" << endl;
		cout << "13 x 7 = 91" << endl;
		cout << "13 x 8 = 104" << endl;
		cout << "13 x 9 = 117" << endl;
		cout << "13 x 10 = 130" << endl;
		cout << "13 x 11 = 143" << endl;
		cout << "13 x 12 = 156" << endl;
		cout << endl;
		cout << "That was the Times Table for 13!" << endl;
		cout << "===========================================================================";
		cout << endl;
	}

	else if (timesTableInt == 14) //14 times table
	{
		cout << "14 x 1 = 14" << endl;
		cout << "14 x 2 = 28" << endl;
		cout << "14 x 3 = 42" << endl;
		cout << "14 x 4 = 56" << endl;
		cout << "14 x 5 = 70" << endl;
		cout << "14 x 6 = 84" << endl;
		cout << "14 x 7 = 98" << endl;
		cout << "14 x 8 = 112" << endl;
		cout << "14 x 9 = 126" << endl;
		cout << "14 x 10 = 140" << endl;
		cout << "14 x 11 = 154" << endl;
		cout << "14 x 12 = 168" << endl;
		cout << endl;
		cout << "That was the Times Table for 14!" << endl;
		cout << "===========================================================================";
		cout << endl;
	}

	else if (timesTableInt == 15) //15 times table
	{
		cout << "15 x 1 = 15" << endl;
		cout << "15 x 2 = 30" << endl;
		cout << "15 x 3 = 45" << endl;
		cout << "15 x 4 = 60" << endl;
		cout << "15 x 5 = 75" << endl;
		cout << "15 x 6 = 90" << endl;
		cout << "15 x 7 = 105" << endl;
		cout << "15 x 8 = 120" << endl;
		cout << "15 x 9 = 135" << endl;
		cout << "15 x 10 = 150" << endl;
		cout << "15 x 11 = 165" << endl;
		cout << "15 x 12 = 180" << endl;
		cout << endl;
		cout << "That was the Times Table for 15!" << endl;
		cout << "===========================================================================";
		cout << endl;
	}


	else if (timesTableInt > 15)
	{
		cout << "Don't be daft! I said between 1 and 15!";
		cout << endl;
		cout << endl;
	}
}
//------------------------Function Creation For Times Table End--------------------------