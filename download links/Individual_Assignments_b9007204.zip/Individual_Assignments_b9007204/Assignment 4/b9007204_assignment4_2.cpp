// b9007204_assignment4_2.cpp.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include "pch.h"
#include <iostream>
#include <string>
using namespace std;


int previousNum = 0;   //declaring my variables globally, setting the previous number and the current number to their respective start values.
int currentNum = 1;
int nextNum;		//these two variables dont need to be assigned a value because they are un-determined thus far.
int targetNum;



int main()
{

	cout << "Please input a number to print the Fibonacci Sequence to the number you entered.";  //systems tells user to input the target number of the sequence they want.
	cin >> targetNum;			//user inputs target number of sequence.

	for (int a = 1; a < targetNum; a++)			//while local int a is 1, and local int a is less than the target number, the loop will increment a by 1 every loop.
	{
		if (a == 0)			//if a is equal to 0 then the system will output the previous number, which was declared as zero in the global variables.
		{
			cout << previousNum;
		}

		if (a == 1)			//if a is equal to 1 then the system will output the current number, which was declared as 1 in the global variables.
		{
			cout << currentNum;
		}

		nextNum = previousNum + currentNum;				//after these if statements, the next number becomes the previous number add the current number.
		previousNum = currentNum;				//then, the previous number becomes the current number, because the sequence is continuing.
		currentNum = nextNum;			//after this, the current number becomes the next number, because as stated above, the sequence is continuing.

		cout << " " << nextNum << " ";			//the system outputs the next number, and repeats till the for loop is satisfied to hit the target number given by the user.


	}
}