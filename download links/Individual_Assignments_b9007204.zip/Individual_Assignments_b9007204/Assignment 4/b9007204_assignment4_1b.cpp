// b9007204_assignment4_1b.cpp.cpp : This file contains the 'main' function. Program execution begins and ends there.
//


#include "pch.h"
#include <iostream>
#include <string>
using namespace std;

int main()
{

	int primeNumbers = 0; //the prime numbers counter is declared and set to 0.

	for (int i = 100; i < 2000; i++) //for loop for getting the range of numbers to check how many primes are present. int i starts at 100, and while int i is less than 2000, it will increment
	{
		int totalNumbersChecked = 0; //declaration of the local variable for total numbers checked. 

		for (int a = 1; a <= i; a++) //int a(local) is 1. while a is less than or equal to i, a will be incremented by 1 in a loop.
		{

			if (i%a == 0) //if the modulus of i and a is 0, the totalNumbersChecked counter will increase
			{
				totalNumbersChecked += 1; //totalNumberChecked is increased by 1 and looped.
			}
		}

		if (totalNumbersChecked == 2) //if the total numbers checked is 2, the primeNumbers is incremented by 1.
		{
			primeNumbers++; //primeNumbers is incremented by 1 each loop
		}
	}

	cout << "The total amount of Prime Numbers between 100 and 2000 is: " << primeNumbers << endl; //system outputs the total amount of prime numbers, as primeNumbers has been incremented thoughout the loop.
}
