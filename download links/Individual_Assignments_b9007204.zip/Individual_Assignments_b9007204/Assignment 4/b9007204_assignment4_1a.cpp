// b9007204_assignment4_1a.cpp.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include "pch.h"
#include <iostream>
#include <string>
using namespace std;

int userInputNumber;   //declares the integer userInpputNumber, which will be the user input to find the prime number.




int main()
{
	cout << "Please input a Positive Number to find out if it is a Prime Number or not: ";
	cin >> userInputNumber; //user inputs number to find if its prime or not

	for (int i = 2; i <= userInputNumber / 2; i++)	//i = 2 is the local variable declaration, which sets i to 2. the second statement tells for the code to be run, that i should be less than or equal to userinputnumber divided by 2. i++ is the increment.
	{
		if (userInputNumber % i == 0) //if the userinputnumber modulus 1 is equal to zero, then the system will output that it isnt a prime number.
		{
			cout << "That isn't a Prime Number!"; //system outputs that it isnt a prime number if the if statement is met
			break;
		}
		else  //if the condition is not met, then the system will output the number is prime.
		{
			cout << "The Number is Prime!"; //system outputs that it is a prime number if the if statement is not met.
			break;
		}
	}

}
