// b9007204_assignment4_1c.cpp.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include "pch.h"
#include <iostream>
#include <string>
using namespace std;

int sumOfPrimes;

int main()
{
	int primeNumbers = 0; //the prime numbers counter is declared and set to 0.

	for (int i = 1000; i < 3000; i++) //for loop for getting the range of numbers to check how many primes are present.
	{
		int totalNumbersChecked = 0; //declaration of the local variable for total numbers checked. 

		for (int a = 1; a <= i; a++) //int a(local) is 1. while a is less than or equal to i, a will be incremented by 1 in a loop.
		{

			if (i%a == 0) //if the modulus of i and a is 0, the totalNumbersChecked counter will increase
			{
				totalNumbersChecked += 1; //totalNumberChecked is increased by 1 and looped.
			}
		}

		if (totalNumbersChecked == 2) //if the total numbers checked is 2, the primeNumbers is incremented by 1.
		{
			primeNumbers++; //primeNumbers is incremented by 1 each loop

			sumOfPrimes += i; //the sum of all the prime numbers is every time a prime number is found, it is added to the variable sumOfPrimes.
		}
	}

	cout << "The sum of all the Prime Numbers between 1000 and 3000 is: " << sumOfPrimes << endl; //system outputs the sumOfPrimes variable after my text explaining it.


}
