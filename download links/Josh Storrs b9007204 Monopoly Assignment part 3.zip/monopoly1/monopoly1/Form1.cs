﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace monopoly1
{

    public partial class Form1 : Form
    {
        int totalvalue = 0;
        int dice_throw1;
        int dice_throw2;

        int player1Position = 100;
        int player2Position = 100;
        int player3Position = 100;
        int player4Position = 100;

        int player1Cash = 0;
        int player2Cash = 0;
        int player3Cash = 0;
        int player4Cash = 0;

        int activePlayers = 0;

        int bankruptedPlayers = 0;

        bool isPlayer1Active = false;
        bool isPlayer2Active = false;
        bool isPlayer3Active = false;
        bool isPlayer4Active = false;

        bool player1TurnBool = false;
        bool player2TurnBool = false;
        bool player3TurnBool = false;
        bool player4TurnBool = false;

        bool player1Bankrupt = false;
        bool player2Bankrupt = false;
        bool player3Bankrupt = false;
        bool player4Bankrupt = false;

        bool player1InJail;
        bool player2InJail;
        bool player3InJail;
        bool player4InJail;

        int currentPlayer = 1;

        int boardsquare = 0;

        int oldKentRoad = 0;
        int whitehapelRoad = 0;
        int kingsCrossStation = 0;
        int theAngelIslington = 0;
        int eustonRoad= 0;
        int pentonvilleRoad= 0;
        int pallMall = 0;
        int whiteHall = 0;
        int northumberlandAvenue = 0;
        int maryleboneStation = 0;
        int bowStreet = 0;
        int marlboroughStreet = 0;                  //ints for if a square is owned.
        int vineStreet = 0;
        int strand = 0;
        int fleetStreet = 0;
        int trafalgerSquare = 0;
        int fenchurchStreetStation = 0;
        int leicesterSquare = 0;
        int coventryStreet = 0;
        int piccadilly = 0;
        int regentStreet = 0;
        int oxfordStreet = 0;
        int bondStreet = 0;
        int liverpoolStreetStation = 0;
        int parkLane = 0;
        int mayfair = 0;

        int electricCompany = 0;
        int waterWorks = 0;



        //--------------------------------Main----------------------------------------------------------
        public Form1()          
        {
            InitializeComponent();

            player1PositionTextBox.Text = player1GamePiece.Location.ToString();
            player2PositionTextBox.Text = player2GamePiece.Location.ToString();
            player3PositionTextBox.Text = player3GamePiece.Location.ToString();
            player4PositionTextBox.Text = player4GamePiece.Location.ToString();

            Player1MoneyValue.Text = player1Cash.ToString();
            Player2MoneyValue.Text = player2Cash.ToString();
            Player3MoneyValue.Text = player3Cash.ToString();
            Player4MoneyValue.Text = player4Cash.ToString();

        }
        //--------------------------------Main End------------------------------------------------------
    

        //---------------------------Click Handler For Dice Button Click--------------------------------
        private void ThrowDiceButton_Click(object sender, EventArgs e)
        {
            int dice_throw1 = ThrowDice1();

            if (dice_throw1 == 1) DicePictureBox1.Image = Image.FromFile("dice1.png");
            if (dice_throw1 == 2) DicePictureBox1.Image = Image.FromFile("dice2.png");
            if (dice_throw1 == 3) DicePictureBox1.Image = Image.FromFile("dice3.png");
            if (dice_throw1 == 4) DicePictureBox1.Image = Image.FromFile("dice4.png");
            if (dice_throw1 == 5) DicePictureBox1.Image = Image.FromFile("dice5.png");
            if (dice_throw1 == 6) DicePictureBox1.Image = Image.FromFile("dice6.png");

           

            int dice_throw2 = ThrowDice2();

            if (dice_throw2 == 1) DicePictureBox2.Image = Image.FromFile("dice1.png");
            if (dice_throw2 == 2) DicePictureBox2.Image = Image.FromFile("dice2.png");
            if (dice_throw2 == 3) DicePictureBox2.Image = Image.FromFile("dice3.png");
            if (dice_throw2 == 4) DicePictureBox2.Image = Image.FromFile("dice4.png");
            if (dice_throw2 == 5) DicePictureBox2.Image = Image.FromFile("dice5.png");
            if (dice_throw2 == 6) DicePictureBox2.Image = Image.FromFile("dice6.png");

            Dice1ValueLabel.Text = dice_throw1.ToString();
            Dice2ValueLabel.Text = dice_throw2.ToString();

            totalvalue = dice_throw1 + dice_throw2;

            TotalDiceValue.Text = totalvalue.ToString();

            if ((activePlayers == 2) && (bankruptedPlayers == 1))
            {
                MessageBox.Show("You Win! Game Over!");
                totalvalue = 0;
            }

            if ((activePlayers == 3) && (bankruptedPlayers == 2))
            {
                MessageBox.Show("You Win! Game Over!");
                totalvalue = 0;
            }

            if ((activePlayers == 4) && (bankruptedPlayers == 3))
            {
                MessageBox.Show("You Win! Game Over!");
                totalvalue = 0;
            }

            if (activePlayers == 1) //if only one player is playing
            {
                if (currentPlayer == 1)
                {
                    player1Turn();
                }
            }

            else if (activePlayers == 2)  //if 2 players are playing
            {

                if (currentPlayer == 1)
                {
                    player1Turn();
                }

                if (currentPlayer == 2)
                {
                    player2Turn();
                }

            }

            else if (activePlayers == 3) //if 3 players are active
            {
                if (currentPlayer == 1) //current players 1-3 turns run
                {
                    player1Turn();
                }

                if (currentPlayer == 2)
                {
                    player2Turn();
                }

                if (currentPlayer == 3)
                {
                    player3Turn();
                }
            }

            else if (activePlayers == 4)
            {

                if (currentPlayer == 1)
                {
                    player1Turn();
                }

                if (currentPlayer == 2)
                {
                    player2Turn();
                }

                if (currentPlayer == 3)
                {
                    player3Turn();
                }

                if (currentPlayer == 4)
                {
                    player4Turn();
                }
            }


        }
        int ThrowDice1()
        {
            return new Random((int)DateTime.Now.Ticks).Next(1, 7);
        }

        int ThrowDice2()
        {
            return new Random((int)DateTime.Now.Ticks).Next(1, 7);
        }
        //-------------------------------End OF Dice Button Click Handler-------------------------------


        //-------------------------------Maximize Form and Show How to Play----------------------------
        private void Form1_Load(object sender, EventArgs e)     
        {
            this.WindowState = FormWindowState.Maximized;
            MessageBox.Show("How to Play! Each Player Presses 'Start' next to their score. After allowing all players to start, press Start Game!");
        }
        //-------------------------------Mazimize form and how to play end------------------------------


        void player1Turn()
        {
            if (player1Cash >= 0)
            {
                player1Move();
            }

            if (player1Cash < 0)
            {
                player1Cash = player1Cash - 1000000;
                MessageBox.Show("You are bankrupt! Better luck next time!");
                player1Bankrupt = true;
                bankruptedPlayers++;
                totalvalue = 0;
                currentPlayer++;
                Player1ScoreboardName.Visible = false;
                poundP1.Visible = false;
                Player1MoneyValue.Visible = false;

                player1TurnTB.Visible = false;
                player2TurnTB.Visible = true;
                player3TurnTB.Visible = false;
                player4TurnTB.Visible = false;
            }

            if (player1InJail == true)
            {
                if (totalvalue == 10 || totalvalue == 6 || totalvalue == 12)
                {
                    MessageBox.Show("You got out of jail!");
                    player1GamePiece.Location = new Point(26, 576);
                    player1Position = 10;
                    player1InJail = false;
                }
            }

        }

        void player2Turn()
        {
            if (player2Cash >= 0)
            {
                player2Move();
            }

            if (player2Cash < 0)
            {
                player2Cash = player2Cash - 1000000;
                MessageBox.Show("You are bankrupt! Better luck next time!");
                player2Bankrupt = true;
                bankruptedPlayers++;
                totalvalue = 0;
                currentPlayer++;
                Player2ScoreboardName.Visible = false;
                poundP2.Visible = false;
                Player2MoneyValue.Visible = false;

                player1TurnTB.Visible = false;
                player2TurnTB.Visible = false;
                player3TurnTB.Visible = true;
                player4TurnTB.Visible = false;
            }

            if (player2InJail == true)
            {
                if (totalvalue == 10 || totalvalue == 6 || totalvalue == 12)
                {
                    MessageBox.Show("You got out of jail!");
                    player2GamePiece.Location = new Point(26, 607);
                    player2Position = 10;
                    player2InJail = false;
                }
            }
        }

        void player3Turn()
        {
            if (player3Cash >= 0)
            {
                player3Move();
            }

            if (player3Cash < 0)
            {
                player3Cash = player3Cash - 1000000;
                MessageBox.Show("You are bankrupt! Better luck next time!");
                player3Bankrupt = true;
                bankruptedPlayers++;
                totalvalue = 0;
                currentPlayer++;
                Player3ScoreboardName.Visible = false;
                poundP3.Visible = false;
                Player3MoneyValue.Visible = false;

                player1TurnTB.Visible = false;
                player2TurnTB.Visible = false;
                player3TurnTB.Visible = false;
                player4TurnTB.Visible = true;
            }

            if (player3InJail == true)
            {
                if (totalvalue == 10 || totalvalue == 6 || totalvalue == 12)
                {
                    MessageBox.Show("You got out of jail!");
                    player3GamePiece.Location = new Point(50, 631);
                    player3Position = 10;
                    player3InJail = false;
                }
            }
        }

        void player4Turn()
        {
            if (player4Cash >= 0)
            {
                player4Move();
            }
            if (player4Cash < 0)
            {
                player4Cash = player4Cash - 100000;
                MessageBox.Show("You are bankrupt! Better luck next time!");
                player4Bankrupt = true;
                bankruptedPlayers++;
                totalvalue = 0;
                currentPlayer = 1;
                Player4ScoreboardName.Visible = false;
                poundP4.Visible = false;
                Player4MoneyValue.Visible = false;

                player1TurnTB.Visible = true;
                player2TurnTB.Visible = false;
                player3TurnTB.Visible = false;
                player4TurnTB.Visible = false;
            }

            if (player4InJail == true)
            {
                if (totalvalue == 10 || totalvalue == 6 || totalvalue == 12)
                {
                    MessageBox.Show("You got out of jail!");
                    player4GamePiece.Location = new Point(81, 631);
                    player4Position = 10;
                    player4InJail = false;
                }
            }
        }

        void player1Move() //player 1 move function with locations
        {
            player1Position = player1Position + totalvalue;

            if (player1Position >= 40) //if players location exceeds 40, reset position by 40 and display location
            {
                player1Cash = player1Cash + 200;
                player1Position = player1Position - 40;
            }

            if (player1Position == 100) //start square
            {
                player1GamePiece.Location = new Point(797, 59);
            }

            if (player1Position == 0) //go
            {
                player1GamePiece.Location = new Point (705, 593);
            }

            if (player1Position == 1)      //old kent road
            {
                player1GamePiece.Location = new Point(628, 599);  

                if (oldKentRoad == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Old Kent Road?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        oldKentRoad = 1;
                        player1Cash = player1Cash - 60;
                        Player1MoneyValue.Text = player1Cash.ToString();
                        oldKentRoadOwnedP1.Visible = true;
                    }
                }

                if (oldKentRoad == 1) // if old kent road is owned by p1
                {
                    //do nothing as this is p1
                }

                if (oldKentRoad == 2)
                {
                    MessageBox.Show("This square is owned by Player 2! Pay £60 to Player 2!");

                    player1Cash = player1Cash - 60;
                    Player1MoneyValue.Text = player1Cash.ToString();

                    player2Cash = player2Cash + 60;
                    Player2MoneyValue.Text = player2Cash.ToString();
                }

                if (oldKentRoad == 3)
                {
                    MessageBox.Show("This square is owned by Player 3! Pay £60 to Player 3!");

                    player1Cash = player1Cash - 60;
                    Player1MoneyValue.Text = player1Cash.ToString();

                    player3Cash = player3Cash + 60;
                    Player3MoneyValue.Text = player3Cash.ToString();
                }

                if (oldKentRoad == 4)
                {
                    MessageBox.Show("This square is owned by player 4! Pay £60 to Player 4!");

                    player1Cash = player1Cash - 60;
                    Player1MoneyValue.Text = player1Cash.ToString();

                    player4Cash = player4Cash + 60;
                    Player4MoneyValue.Text = player4Cash.ToString();

                }
            }

            if (player1Position == 2) //com chest
            {
                player1GamePiece.Location = new Point(567, 599);
                communityChestP1();
            } 

            if (player1Position == 3) //whitechapel
            {
                player1GamePiece.Location = new Point (503, 600);

                if (whitehapelRoad == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Whitechapel road?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        whitehapelRoad = 1;
                        player1Cash = player1Cash - 60;
                        Player1MoneyValue.Text = player1Cash.ToString();
                        whitechapelRoadOwnedP1.Visible = true;
                    }
                }

                if (whitehapelRoad == 1) // if Whitechapel road is owned by p1
                {
                    //do nothing as this is p1
                }

                if (whitehapelRoad == 2)
                {
                    MessageBox.Show("This square is owned by Player 2! Pay £60 to Player 2!");

                    player1Cash = player1Cash - 60;
                    Player1MoneyValue.Text = player1Cash.ToString();

                    player2Cash = player2Cash + 60;
                    Player2MoneyValue.Text = player2Cash.ToString();
                }

                if (whitehapelRoad == 3)
                {
                    MessageBox.Show("This square is owned by Player 3! Pay £60 to Player 3!");

                    player1Cash = player1Cash - 60;
                    Player1MoneyValue.Text = player1Cash.ToString();

                    player3Cash = player3Cash + 60;
                    Player3MoneyValue.Text = player3Cash.ToString();
                }

                if (whitehapelRoad == 4)
                {
                    MessageBox.Show("This square is owned by player 4! Pay £60 to Player 4!");

                    player1Cash = player1Cash - 60;
                    Player1MoneyValue.Text = player1Cash.ToString();

                    player4Cash = player4Cash + 60;
                    Player4MoneyValue.Text = player4Cash.ToString();

                }
            } 

            if (player1Position == 4)        //income tax
            {
                player1GamePiece.Location = new Point(439, 594);
                MessageBox.Show("Income Tax! Pay £200");
                player1Cash = player1Cash - 200;
                Player1MoneyValue.Text = player1Cash.ToString();
            }   

            if (player1Position == 5)    //kings cross
            {
                player1GamePiece.Location = new Point(378, 594);

                if (kingsCrossStation == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Kings Cross Station?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        kingsCrossStation = 1;
                        player1Cash = player1Cash - 200;
                        Player1MoneyValue.Text = player1Cash.ToString();
                        kingsCrossOwnedP1.Visible = true;
                    }
                }

                if (kingsCrossStation == 1) // if Whitechapel road is owned by p1
                {
                    //do nothing as this is p1
                }

                if (kingsCrossStation == 2)
                {
                    MessageBox.Show("This square is owned by Player 2! Pay £200 to Player 2!");

                    player1Cash = player1Cash - 200;
                    Player1MoneyValue.Text = player1Cash.ToString();

                    player2Cash = player2Cash + 200;
                    Player2MoneyValue.Text = player2Cash.ToString();
                }

                if (kingsCrossStation == 3)
                {
                    MessageBox.Show("This square is owned by Player 3! Pay £200 to Player 3!");

                    player1Cash = player1Cash - 200;
                    Player1MoneyValue.Text = player1Cash.ToString();

                    player3Cash = player3Cash + 200;
                    Player3MoneyValue.Text = player3Cash.ToString();
                }

                if (kingsCrossStation == 4)
                {
                    MessageBox.Show("This square is owned by player 4! Pay £200 to Player 4!");

                    player1Cash = player1Cash - 200;
                    Player1MoneyValue.Text = player1Cash.ToString();

                    player4Cash = player4Cash + 200;
                    Player4MoneyValue.Text = player4Cash.ToString();
                }
            }

            if (player1Position == 6)       //angel islington
            {
                player1GamePiece.Location = new Point(319, 596);

                if (theAngelIslington == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy The Angel Islington?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        theAngelIslington = 1;
                        player1Cash = player1Cash - 100;
                        Player1MoneyValue.Text = player1Cash.ToString();
                        angelIslingtonOwnedP1.Visible = true;
                    }
                }

                if (theAngelIslington == 1) // if angel Islington is owned by p1
                {
                    //do nothing as this is p1
                }

                if (theAngelIslington == 2)
                {
                    MessageBox.Show("This square is owned by Player 2! Pay £100 to Player 2!");

                    player1Cash = player1Cash - 100;
                    Player1MoneyValue.Text = player1Cash.ToString();

                    player2Cash = player2Cash + 100;
                    Player2MoneyValue.Text = player2Cash.ToString();
                }

                if (theAngelIslington == 3)
                {
                    MessageBox.Show("This square is owned by Player 3! Pay £100 to Player 3!");

                    player1Cash = player1Cash - 100;
                    Player1MoneyValue.Text = player1Cash.ToString();

                    player3Cash = player3Cash + 100;
                    Player3MoneyValue.Text = player3Cash.ToString();
                }

                if (theAngelIslington == 4)
                {
                    MessageBox.Show("This square is owned by player 4! Pay £100 to Player 4!");

                    player1Cash = player1Cash - 100;
                    Player1MoneyValue.Text = player1Cash.ToString();

                    player4Cash = player4Cash + 100;
                    Player4MoneyValue.Text = player4Cash.ToString();
                }
            }

            if (player1Position == 7)       //chance
            {
                player1GamePiece.Location = new Point(255, 597);
                chancePlayer1();
                Player1MoneyValue.Text = player1Cash.ToString();
            }

            if (player1Position == 8)       //euston
            {
                player1GamePiece.Location = new Point(193, 597);

                if (eustonRoad == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Euston Road?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        eustonRoad = 1;
                        player1Cash = player1Cash - 100;
                        Player1MoneyValue.Text = player1Cash.ToString();
                        eustonRoadOwnedP1.Visible = true;
                    }
                }

                if (eustonRoad == 1) // if euston is owned by p1
                {
                    //do nothing as this is p1
                }

                if (eustonRoad == 2)
                {
                    MessageBox.Show("This square is owned by Player 2! Pay £100 to Player 2!");

                    player1Cash = player1Cash - 100;
                    Player1MoneyValue.Text = player1Cash.ToString();

                    player2Cash = player2Cash + 100;
                    Player2MoneyValue.Text = player2Cash.ToString();
                }

                if (eustonRoad == 3)
                {
                    MessageBox.Show("This square is owned by Player 3! Pay £100 to Player 3!");

                    player1Cash = player1Cash - 100;
                    Player1MoneyValue.Text = player1Cash.ToString();

                    player3Cash = player3Cash + 100;
                    Player3MoneyValue.Text = player3Cash.ToString();
                }

                if (eustonRoad == 4)
                {
                    MessageBox.Show("This square is owned by player 4! Pay £100 to Player 4!");

                    player1Cash = player1Cash - 100;
                    Player1MoneyValue.Text = player1Cash.ToString();

                    player4Cash = player4Cash + 100;
                    Player4MoneyValue.Text = player4Cash.ToString();
                }
            }

            if (player1Position == 9)       //pentonville rd
            {
                player1GamePiece.Location = new Point(131, 597);

                if (pentonvilleRoad == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy PentonVille Road?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        pentonvilleRoad = 1;
                        player1Cash = player1Cash - 120;
                        Player1MoneyValue.Text = player1Cash.ToString();
                        pentonvilleRoadOwnedP1.Visible = true;
                    }
                }

                if (pentonvilleRoad == 1) // if penton is owned by p1
                {
                    //do nothing as this is p1
                }

                if (pentonvilleRoad == 2)
                {
                    MessageBox.Show("This square is owned by Player 2! Pay £120 to Player 2!");

                    player1Cash = player1Cash - 120;
                    Player1MoneyValue.Text = player1Cash.ToString();

                    player2Cash = player2Cash + 120;
                    Player2MoneyValue.Text = player2Cash.ToString();
                }

                if (pentonvilleRoad == 3)
                {
                    MessageBox.Show("This square is owned by Player 3! Pay £120 to Player 3!");

                    player1Cash = player1Cash - 120;
                    Player1MoneyValue.Text = player1Cash.ToString();

                    player3Cash = player3Cash + 120;
                    Player3MoneyValue.Text = player3Cash.ToString();
                }

                if (pentonvilleRoad == 4)
                {
                    MessageBox.Show("This square is owned by player 4! Pay £120 to Player 4!");

                    player1Cash = player1Cash - 120;
                    Player1MoneyValue.Text = player1Cash.ToString();

                    player4Cash = player4Cash + 120;
                    Player4MoneyValue.Text = player4Cash.ToString();
                }
            }

            if (player1Position == 10)      //jv jail       done p1 properties to here
            {
                player1GamePiece.Location = new Point(26, 576);
            }

            if (player1Position == 11)       //pallmall
            {
                player1GamePiece.Location = new Point(39, 519);

                if (pallMall == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Pall Mall?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        pallMall = 1;
                        player1Cash = player1Cash - 140;
                        Player1MoneyValue.Text = player1Cash.ToString();
                        pallMallOwnedP1.Visible = true;
                    }
                }

                if (pallMall == 1) // if penton is owned by p1
                {
                    //do nothing as this is p1
                }

                if (pallMall == 2)
                {
                    MessageBox.Show("This square is owned by Player 2! Pay £140 to Player 2!");

                    player1Cash = player1Cash - 140;
                    Player1MoneyValue.Text = player1Cash.ToString();

                    player2Cash = player2Cash + 140;
                    Player2MoneyValue.Text = player2Cash.ToString();
                }

                if (pallMall == 3)
                {
                    MessageBox.Show("This square is owned by Player 3! Pay £140 to Player 3!");

                    player1Cash = player1Cash - 140;
                    Player1MoneyValue.Text = player1Cash.ToString();

                    player3Cash = player3Cash + 140;
                    Player3MoneyValue.Text = player3Cash.ToString();
                }

                if (pallMall == 4)
                {
                    MessageBox.Show("This square is owned by player 4! Pay £140 to Player 4!");

                    player1Cash = player1Cash - 140;
                    Player1MoneyValue.Text = player1Cash.ToString();

                    player4Cash = player4Cash + 140;
                    Player4MoneyValue.Text = player4Cash.ToString();
                }
            }

            if (player1Position == 12)      //electric
            {
                player1GamePiece.Location = new Point(40, 467);

                if (electricCompany == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy The Electric Company?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        electricCompany = 1;
                        player1Cash = player1Cash - 150;
                        Player1MoneyValue.Text = player1Cash.ToString();
                        electricCompanyOwnedP1.Visible = true;
                    }
                }

                if (electricCompany == 1) // if elec is owned by p1
                {
                    //do nothing as this is p1
                }

                if (electricCompany == 2)
                {
                    MessageBox.Show("This square is owned by Player 2! Pay £150 to Player 2!");

                    player1Cash = player1Cash - 150;
                    Player1MoneyValue.Text = player1Cash.ToString();

                    player2Cash = player2Cash + 150;
                    Player2MoneyValue.Text = player2Cash.ToString();
                }

                if (electricCompany == 3)
                {
                    MessageBox.Show("This square is owned by Player 3! Pay £150 to Player 3!");

                    player1Cash = player1Cash - 150;
                    Player1MoneyValue.Text = player1Cash.ToString();

                    player3Cash = player3Cash + 150;
                    Player3MoneyValue.Text = player3Cash.ToString();
                }

                if (electricCompany == 4)
                {
                    MessageBox.Show("This square is owned by player 4! Pay £150 to Player 4!");

                    player1Cash = player1Cash - 150;
                    Player1MoneyValue.Text = player1Cash.ToString();

                    player4Cash = player4Cash + 150;
                    Player4MoneyValue.Text = player4Cash.ToString();
                }
            }

            if (player1Position == 13)      //whitehall
            {
                player1GamePiece.Location = new Point(35, 412);

                if (whiteHall == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Whitehall?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        whiteHall = 1;
                        player1Cash = player1Cash - 140;
                        Player1MoneyValue.Text = player1Cash.ToString();
                        whitehallOwnedP1.Visible = true;
                    }
                }

                if (whiteHall == 1) // if penton is owned by p1
                {
                    //do nothing as this is p1
                }

                if (whiteHall == 2)
                {
                    MessageBox.Show("This square is owned by Player 2! Pay £140 to Player 2!");

                    player1Cash = player1Cash - 140;
                    Player1MoneyValue.Text = player1Cash.ToString();

                    player2Cash = player2Cash + 140;
                    Player2MoneyValue.Text = player2Cash.ToString();
                }

                if (whiteHall == 3)
                {
                    MessageBox.Show("This square is owned by Player 3! Pay £140 to Player 3!");

                    player1Cash = player1Cash - 140;
                    Player1MoneyValue.Text = player1Cash.ToString();

                    player3Cash = player3Cash + 140;
                    Player3MoneyValue.Text = player3Cash.ToString();
                }

                if (whiteHall == 4)
                {
                    MessageBox.Show("This square is owned by player 4! Pay £140 to Player 4!");

                    player1Cash = player1Cash - 140;
                    Player1MoneyValue.Text = player1Cash.ToString();

                    player4Cash = player4Cash + 140;
                    Player4MoneyValue.Text = player4Cash.ToString();
                }
            }

            if (player1Position == 14)      //northumberland
            {
                player1GamePiece.Location = new Point(37, 359);

                if (northumberlandAvenue == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Northumberland Avenue?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        northumberlandAvenue = 1;
                        player1Cash = player1Cash - 160;
                        Player1MoneyValue.Text = player1Cash.ToString();
                        northumberlandOwnedP1.Visible = true;
                    }
                }

                if (northumberlandAvenue == 1) // if northum is owned by p1
                {
                    //do nothing as this is p1
                }

                if (northumberlandAvenue == 2)
                {
                    MessageBox.Show("This square is owned by Player 2! Pay £160 to Player 2!");

                    player1Cash = player1Cash - 160;
                    Player1MoneyValue.Text = player1Cash.ToString();

                    player2Cash = player2Cash + 160;
                    Player2MoneyValue.Text = player2Cash.ToString();
                }

                if (northumberlandAvenue == 3)
                {
                    MessageBox.Show("This square is owned by Player 3! Pay £160 to Player 3!");

                    player1Cash = player1Cash - 160;
                    Player1MoneyValue.Text = player1Cash.ToString();

                    player3Cash = player3Cash + 160;
                    Player3MoneyValue.Text = player3Cash.ToString();
                }

                if (northumberlandAvenue == 4)
                {
                    MessageBox.Show("This square is owned by player 4! Pay £160 to Player 4!");

                    player1Cash = player1Cash - 160;
                    Player1MoneyValue.Text = player1Cash.ToString();

                    player4Cash = player4Cash + 160;
                    Player4MoneyValue.Text = player4Cash.ToString();
                }
            }

            if (player1Position == 15)      //marylebone
            {
                player1GamePiece.Location = new Point(39, 307);

                if (maryleboneStation == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Marylebone Station?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        maryleboneStation = 1;
                        player1Cash = player1Cash - 200;
                        Player1MoneyValue.Text = player1Cash.ToString();
                        maryleboneStationOwnedP1.Visible = true;
                    }
                }

                if (maryleboneStation == 1) // if penton is owned by p1
                {
                    //do nothing as this is p1
                }

                if (maryleboneStation == 2)
                {
                    MessageBox.Show("This square is owned by Player 2! Pay £200 to Player 2!");

                    player1Cash = player1Cash - 200;
                    Player1MoneyValue.Text = player1Cash.ToString();

                    player2Cash = player2Cash + 200;
                    Player2MoneyValue.Text = player2Cash.ToString();
                }

                if (maryleboneStation == 3)
                {
                    MessageBox.Show("This square is owned by Player 3! Pay £200 to Player 3!");

                    player1Cash = player1Cash - 200;
                    Player1MoneyValue.Text = player1Cash.ToString();

                    player3Cash = player3Cash + 200;
                    Player3MoneyValue.Text = player3Cash.ToString();
                }

                if (maryleboneStation == 4)
                {
                    MessageBox.Show("This square is owned by player 4! Pay £200 to Player 4!");

                    player1Cash = player1Cash - 200;
                    Player1MoneyValue.Text = player1Cash.ToString();

                    player4Cash = player4Cash + 200;
                    Player4MoneyValue.Text = player4Cash.ToString();
                }
            }

            if (player1Position == 16)      //bow street
            {
                player1GamePiece.Location = new Point(39, 254);

                if (bowStreet == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Bow Street?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        bowStreet = 1;
                        player1Cash = player1Cash - 180;
                        Player1MoneyValue.Text = player1Cash.ToString();
                        bowStreetOwnedP1.Visible = true;
                    }
                }

                if (bowStreet == 1) // if bow st is owned by p1
                {
                    //do nothing as this is p1
                }

                if (bowStreet == 2)
                {
                    MessageBox.Show("This square is owned by Player 2! Pay £180 to Player 2!");

                    player1Cash = player1Cash - 180;
                    Player1MoneyValue.Text = player1Cash.ToString();

                    player2Cash = player2Cash + 180;
                    Player2MoneyValue.Text = player2Cash.ToString();
                }

                if (bowStreet == 3)
                {
                    MessageBox.Show("This square is owned by Player 3! Pay £180 to Player 3!");

                    player1Cash = player1Cash - 180;
                    Player1MoneyValue.Text = player1Cash.ToString();

                    player3Cash = player3Cash + 180;
                    Player3MoneyValue.Text = player3Cash.ToString();
                }

                if (bowStreet == 4)
                {
                    MessageBox.Show("This square is owned by player 4! Pay £180 to Player 4!");

                    player1Cash = player1Cash - 180;
                    Player1MoneyValue.Text = player1Cash.ToString();

                    player4Cash = player4Cash + 180;
                    Player4MoneyValue.Text = player4Cash.ToString();
                }
            }

            if (player1Position == 17)      //com ch
            {
                player1GamePiece.Location = new Point(39, 200);
                communityChestP1();
            }

            if (player1Position == 18)      //marlegrough strett
            {
                player1GamePiece.Location = new Point(35, 148);

                if (marlboroughStreet == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Marlborough Street?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        marlboroughStreet = 1;
                        player1Cash = player1Cash - 180;
                        Player1MoneyValue.Text = player1Cash.ToString();
                        marlboroughStreetOwnedP1.Visible = true;
                    }
                }

                if (marlboroughStreet == 1) // if penton is owned by p1
                {
                    //do nothing as this is p1
                }

                if (marlboroughStreet == 2)
                {
                    MessageBox.Show("This square is owned by Player 2! Pay £180 to Player 2!");

                    player1Cash = player1Cash - 180;
                    Player1MoneyValue.Text = player1Cash.ToString();

                    player2Cash = player2Cash + 180;
                    Player2MoneyValue.Text = player2Cash.ToString();
                }

                if (marlboroughStreet == 3)
                {
                    MessageBox.Show("This square is owned by Player 3! Pay £180 to Player 3!");

                    player1Cash = player1Cash - 180;
                    Player1MoneyValue.Text = player1Cash.ToString();

                    player3Cash = player3Cash + 180;
                    Player3MoneyValue.Text = player3Cash.ToString();
                }

                if (marlboroughStreet == 4)
                {
                    MessageBox.Show("This square is owned by player 4! Pay £180 to Player 4!");

                    player1Cash = player1Cash - 180;
                    Player1MoneyValue.Text = player1Cash.ToString();

                    player4Cash = player4Cash + 180;
                    Player4MoneyValue.Text = player4Cash.ToString();
                }
            }

            if (player1Position == 19)      //vine st
            {
                player1GamePiece.Location = new Point(37, 94);

                if (vineStreet == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Vine Street?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        vineStreet = 1;
                        player1Cash = player1Cash - 200;
                        Player1MoneyValue.Text = player1Cash.ToString();
                        vineStreetOwnedP1.Visible = true;
                    }
                }

                if (vineStreet == 1) // if penton is owned by p1
                {
                    //do nothing as this is p1
                }

                if (vineStreet == 2)
                {
                    MessageBox.Show("This square is owned by Player 2! Pay £200 to Player 2!");

                    player1Cash = player1Cash - 200;
                    Player1MoneyValue.Text = player1Cash.ToString();

                    player2Cash = player2Cash + 200;
                    Player2MoneyValue.Text = player2Cash.ToString();
                }

                if (vineStreet == 3)
                {
                    MessageBox.Show("This square is owned by Player 3! Pay £200 to Player 3!");

                    player1Cash = player1Cash - 200;
                    Player1MoneyValue.Text = player1Cash.ToString();

                    player3Cash = player3Cash + 200;
                    Player3MoneyValue.Text = player3Cash.ToString();
                }

                if (vineStreet == 4)
                {
                    MessageBox.Show("This square is owned by player 4! Pay £200 to Player 4!");

                    player1Cash = player1Cash - 200;
                    Player1MoneyValue.Text = player1Cash.ToString();

                    player4Cash = player4Cash + 200;
                    Player4MoneyValue.Text = player4Cash.ToString();
                }
            }

            if (player1Position == 20)//free parking
            {
                player1GamePiece.Location = new Point(31, 8);
            }

            if (player1Position == 21)      //strand
            {
                player1GamePiece.Location = new Point(131, 11);

                if (strand == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Strand?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        strand = 1;
                        player1Cash = player1Cash - 220;
                        Player1MoneyValue.Text = player1Cash.ToString();
                        strandOwnedP1.Visible = true;
                    }
                }

                if (strand == 1) 
                {
                    //do nothing as this is p1
                }

                if (strand == 2)
                {
                    MessageBox.Show("This square is owned by Player 2! Pay £220 to Player 2!");

                    player1Cash = player1Cash - 220;
                    Player1MoneyValue.Text = player1Cash.ToString();

                    player2Cash = player2Cash + 220;
                    Player2MoneyValue.Text = player2Cash.ToString();
                }

                if (strand == 3)
                {
                    MessageBox.Show("This square is owned by Player 3! Pay £220 to Player 3!");

                    player1Cash = player1Cash - 220;
                    Player1MoneyValue.Text = player1Cash.ToString();

                    player3Cash = player3Cash + 220;
                    Player3MoneyValue.Text = player3Cash.ToString();
                }

                if (strand == 4)
                {
                    MessageBox.Show("This square is owned by player 4! Pay £220 to Player 4!");

                    player1Cash = player1Cash - 220;
                    Player1MoneyValue.Text = player1Cash.ToString();

                    player4Cash = player4Cash + 220;
                    Player4MoneyValue.Text = player4Cash.ToString();
                }
            }

            if (player1Position == 22)      //chance
            {
                player1GamePiece.Location = new Point(191, 11);
                chancePlayer1();
                Player1MoneyValue.Text = player1Cash.ToString();
            }

            if (player1Position == 23)      //fleet street
            {
                player1GamePiece.Location = new Point(257, 11);

                if (fleetStreet == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Fleet Street?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        fleetStreet = 1;
                        player1Cash = player1Cash - 220;
                        Player1MoneyValue.Text = player1Cash.ToString();
                        FleetStreetOwnedP1.Visible = true;
                    }
                }

                if (fleetStreet == 1)
                {
                    //do nothing as this is p1
                }

                if (fleetStreet == 2)
                {
                    MessageBox.Show("This square is owned by Player 2! Pay £220 to Player 2!");

                    player1Cash = player1Cash - 220;
                    Player1MoneyValue.Text = player1Cash.ToString();

                    player2Cash = player2Cash + 220;
                    Player2MoneyValue.Text = player2Cash.ToString();
                }

                if (fleetStreet == 3)
                {
                    MessageBox.Show("This square is owned by Player 3! Pay £220 to Player 3!");

                    player1Cash = player1Cash - 220;
                    Player1MoneyValue.Text = player1Cash.ToString();

                    player3Cash = player3Cash + 220;
                    Player3MoneyValue.Text = player3Cash.ToString();
                }

                if (fleetStreet == 4)
                {
                    MessageBox.Show("This square is owned by player 4! Pay £220 to Player 4!");

                    player1Cash = player1Cash - 220;
                    Player1MoneyValue.Text = player1Cash.ToString();

                    player4Cash = player4Cash + 220;
                    Player4MoneyValue.Text = player4Cash.ToString();
                }
            }

            if (player1Position == 24)      //trafalger
            {
                player1GamePiece.Location = new Point(316, 11);

                if (trafalgerSquare == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Trafalgar Square?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        trafalgerSquare = 1;
                        player1Cash = player1Cash - 240;
                        Player1MoneyValue.Text = player1Cash.ToString();
                        trafalgarSquareOwnedP1.Visible = true;
                    }
                }

                if (trafalgerSquare == 1)
                {
                    //do nothing as this is p1
                }

                if (trafalgerSquare == 2)
                {
                    MessageBox.Show("This square is owned by Player 2! Pay £240 to Player 2!");

                    player1Cash = player1Cash - 240;
                    Player1MoneyValue.Text = player1Cash.ToString();

                    player2Cash = player2Cash + 240;
                    Player2MoneyValue.Text = player2Cash.ToString();
                }

                if (trafalgerSquare == 3)
                {
                    MessageBox.Show("This square is owned by Player 3! Pay £240 to Player 3!");

                    player1Cash = player1Cash - 240;
                    Player1MoneyValue.Text = player1Cash.ToString();

                    player3Cash = player3Cash + 240;
                    Player3MoneyValue.Text = player3Cash.ToString();
                }

                if (trafalgerSquare == 4)
                {
                    MessageBox.Show("This square is owned by player 4! Pay £240 to Player 4!");

                    player1Cash = player1Cash - 240;
                    Player1MoneyValue.Text = player1Cash.ToString();

                    player4Cash = player4Cash + 240;
                    Player4MoneyValue.Text = player4Cash.ToString();
                }
            }

            if (player1Position == 25)      //fenchurch st station
            {
                player1GamePiece.Location = new Point(379, 18);

                if (fenchurchStreetStation == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Fenchurch Street Station?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        fenchurchStreetStation = 1;
                        player1Cash = player1Cash - 200;
                        Player1MoneyValue.Text = player1Cash.ToString();
                        fenchurchStationOwnedP1.Visible = true;
                    }
                }

                if (fenchurchStreetStation == 1) // if penton is owned by p1
                {
                    //do nothing as this is p1
                }

                if (fenchurchStreetStation == 2)
                {
                    MessageBox.Show("This square is owned by Player 2! Pay £200 to Player 2!");

                    player1Cash = player1Cash - 200;
                    Player1MoneyValue.Text = player1Cash.ToString();

                    player2Cash = player2Cash + 200;
                    Player2MoneyValue.Text = player2Cash.ToString();
                }

                if (fenchurchStreetStation == 3)
                {
                    MessageBox.Show("This square is owned by Player 3! Pay £200 to Player 3!");

                    player1Cash = player1Cash - 200;
                    Player1MoneyValue.Text = player1Cash.ToString();

                    player3Cash = player3Cash + 200;
                    Player3MoneyValue.Text = player3Cash.ToString();
                }

                if (fenchurchStreetStation == 4)
                {
                    MessageBox.Show("This square is owned by player 4! Pay £200 to Player 4!");

                    player1Cash = player1Cash - 200;
                    Player1MoneyValue.Text = player1Cash.ToString();

                    player4Cash = player4Cash + 200;
                    Player4MoneyValue.Text = player4Cash.ToString();
                }
            }

            if (player1Position == 26)      //leicester sq
            {
                player1GamePiece.Location = new Point(442, 11);

                if (leicesterSquare == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Leicester Square?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        leicesterSquare = 1;
                        player1Cash = player1Cash - 260;
                        Player1MoneyValue.Text = player1Cash.ToString();
                        leicesterSquareOwnedP1.Visible = true;
                    }
                }

                if (leicesterSquare == 1) // if penton is owned by p1
                {
                    //do nothing as this is p1
                }

                if (leicesterSquare == 2)
                {
                    MessageBox.Show("This square is owned by Player 2! Pay £260 to Player 2!");

                    player1Cash = player1Cash - 260;
                    Player1MoneyValue.Text = player1Cash.ToString();

                    player2Cash = player2Cash + 260;
                    Player2MoneyValue.Text = player2Cash.ToString();
                }

                if (leicesterSquare == 3)
                {
                    MessageBox.Show("This square is owned by Player 3! Pay £260 to Player 3!");

                    player1Cash = player1Cash - 260;
                    Player1MoneyValue.Text = player1Cash.ToString();

                    player3Cash = player3Cash + 260;
                    Player3MoneyValue.Text = player3Cash.ToString();
                }

                if (leicesterSquare == 4)
                {
                    MessageBox.Show("This square is owned by player 4! Pay £260 to Player 4!");

                    player1Cash = player1Cash - 260;
                    Player1MoneyValue.Text = player1Cash.ToString();

                    player4Cash = player4Cash + 260;
                    Player4MoneyValue.Text = player4Cash.ToString();
                }
            }

            if (player1Position == 27)      //cov stret
            {
                player1GamePiece.Location = new Point(503, 11);

                if (coventryStreet == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Covenrty Street?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        coventryStreet = 1;
                        player1Cash = player1Cash - 260;
                        Player1MoneyValue.Text = player1Cash.ToString();
                        coventryStreetOwnedP1.Visible = true;
                    }
                }

                if (coventryStreet == 1) // if penton is owned by p1
                {
                    //do nothing as this is p1
                }

                if (coventryStreet == 2)
                {
                    MessageBox.Show("This square is owned by Player 2! Pay £260 to Player 2!");

                    player1Cash = player1Cash - 260;
                    Player1MoneyValue.Text = player1Cash.ToString();

                    player2Cash = player2Cash + 260;
                    Player2MoneyValue.Text = player2Cash.ToString();
                }

                if (coventryStreet == 3)
                {
                    MessageBox.Show("This square is owned by Player 3! Pay £260 to Player 3!");

                    player1Cash = player1Cash - 260;
                    Player1MoneyValue.Text = player1Cash.ToString();

                    player3Cash = player3Cash + 260;
                    Player3MoneyValue.Text = player3Cash.ToString();
                }

                if (coventryStreet == 4)
                {
                    MessageBox.Show("This square is owned by player 4! Pay £260 to Player 4!");

                    player1Cash = player1Cash - 260;
                    Player1MoneyValue.Text = player1Cash.ToString();

                    player4Cash = player4Cash + 260;
                    Player4MoneyValue.Text = player4Cash.ToString();
                }
            }

            if (player1Position == 28)      //water works
            {
                player1GamePiece.Location = new Point(567, 11);

                if (waterWorks == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy The Water Works?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        waterWorks = 1;
                        player1Cash = player1Cash - 150;
                        Player1MoneyValue.Text = player1Cash.ToString();
                        waterworksOwnedP1.Visible = true;
                    }
                }

                if (waterWorks == 1) // if penton is owned by p1
                {
                    //do nothing as this is p1
                }

                if (waterWorks == 2)
                {
                    MessageBox.Show("This square is owned by Player 2! Pay £150 to Player 2!");

                    player1Cash = player1Cash - 150;
                    Player1MoneyValue.Text = player1Cash.ToString();

                    player2Cash = player2Cash + 150;
                    Player2MoneyValue.Text = player2Cash.ToString();
                }

                if (waterWorks == 3)
                {
                    MessageBox.Show("This square is owned by Player 3! Pay £150 to Player 3!");

                    player1Cash = player1Cash - 150;
                    Player1MoneyValue.Text = player1Cash.ToString();

                    player3Cash = player3Cash + 150;
                    Player3MoneyValue.Text = player3Cash.ToString();
                }

                if (waterWorks == 4)
                {
                    MessageBox.Show("This square is owned by player 4! Pay £150 to Player 4!");

                    player1Cash = player1Cash - 150;
                    Player1MoneyValue.Text = player1Cash.ToString();

                    player4Cash = player4Cash + 150;
                    Player4MoneyValue.Text = player4Cash.ToString();
                }
            }

            if (player1Position == 29)      //piccadilly
            {
                player1GamePiece.Location = new Point(629, 11);

                if (piccadilly == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Piccadilly?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        piccadilly = 1;
                        player1Cash = player1Cash - 280;
                        Player1MoneyValue.Text = player1Cash.ToString();
                        piccadillyOwnedP1.Visible = true;
                    }
                }

                if (piccadilly == 1) // if penton is owned by p1
                {
                    //do nothing as this is p1
                }

                if (piccadilly == 2)
                {
                    MessageBox.Show("This square is owned by Player 2! Pay £280 to Player 2!");

                    player1Cash = player1Cash - 280;
                    Player1MoneyValue.Text = player1Cash.ToString();

                    player2Cash = player2Cash + 280;
                    Player2MoneyValue.Text = player2Cash.ToString();
                }

                if (piccadilly == 3)
                {
                    MessageBox.Show("This square is owned by Player 3! Pay £280 to Player 3!");

                    player1Cash = player1Cash - 280;
                    Player1MoneyValue.Text = player1Cash.ToString();

                    player3Cash = player3Cash + 280;
                    Player3MoneyValue.Text = player3Cash.ToString();
                }

                if (piccadilly == 4)
                {
                    MessageBox.Show("This square is owned by player 4! Pay £280 to Player 4!");

                    player1Cash = player1Cash - 280;
                    Player1MoneyValue.Text = player1Cash.ToString();

                    player4Cash = player4Cash + 280;
                    Player4MoneyValue.Text = player4Cash.ToString();
                }
            }

            if (player1Position == 30) //go jail            
            {
                player1GamePiece.Location = new Point(686, 11);
                MessageBox.Show("Go to Jail! Do not pass GO!");
                player1GamePiece.Location = new Point(61, 574);
                player1Position = 600;
            }

            if (player1Position == 31)      //regent st
            {
                player1GamePiece.Location = new Point(715, 92);

                if (regentStreet == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Regent Street?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        regentStreet = 1;
                        player1Cash = player1Cash - 300;
                        Player1MoneyValue.Text = player1Cash.ToString();
                        regentStreetOwnedP1.Visible = true;
                    }
                }

                if (regentStreet == 1) // if penton is owned by p1
                {
                    //do nothing as this is p1
                }

                if (regentStreet == 2)
                {
                    MessageBox.Show("This square is owned by Player 2! Pay £300 to Player 2!");

                    player1Cash = player1Cash - 300;
                    Player1MoneyValue.Text = player1Cash.ToString();

                    player2Cash = player2Cash + 300;
                    Player2MoneyValue.Text = player2Cash.ToString();
                }

                if (regentStreet == 3)
                {
                    MessageBox.Show("This square is owned by Player 3! Pay £300 to Player 3!");

                    player1Cash = player1Cash - 300;
                    Player1MoneyValue.Text = player1Cash.ToString();

                    player3Cash = player3Cash + 300;
                    Player3MoneyValue.Text = player3Cash.ToString();
                }

                if (regentStreet == 4)
                {
                    MessageBox.Show("This square is owned by player 4! Pay £300 to Player 4!");

                    player1Cash = player1Cash - 300;
                    Player1MoneyValue.Text = player1Cash.ToString();

                    player4Cash = player4Cash + 300;
                    Player4MoneyValue.Text = player4Cash.ToString();
                }
            }

            if (player1Position == 32)      //ox street
            {
                player1GamePiece.Location = new Point(717, 148);

                if (oxfordStreet == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Oxford Street?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        oxfordStreet = 1;
                        player1Cash = player1Cash - 300;
                        Player1MoneyValue.Text = player1Cash.ToString();
                        oxfordStreetOwnedP1.Visible = true;
                    }
                }

                if (oxfordStreet == 1) // if penton is owned by p1
                {
                    //do nothing as this is p1
                }

                if (oxfordStreet == 2)
                {
                    MessageBox.Show("This square is owned by Player 2! Pay £300 to Player 2!");

                    player1Cash = player1Cash - 300;
                    Player1MoneyValue.Text = player1Cash.ToString();

                    player2Cash = player2Cash + 300;
                    Player2MoneyValue.Text = player2Cash.ToString();
                }

                if (oxfordStreet == 3)
                {
                    MessageBox.Show("This square is owned by Player 3! Pay £300 to Player 3!");

                    player1Cash = player1Cash - 300;
                    Player1MoneyValue.Text = player1Cash.ToString();

                    player3Cash = player3Cash + 300;
                    Player3MoneyValue.Text = player3Cash.ToString();
                }

                if (oxfordStreet == 4)
                {
                    MessageBox.Show("This square is owned by player 4! Pay £300 to Player 4!");

                    player1Cash = player1Cash - 300;
                    Player1MoneyValue.Text = player1Cash.ToString();

                    player4Cash = player4Cash + 300;
                    Player4MoneyValue.Text = player4Cash.ToString();
                }
            }

            if (player1Position == 33)      //com chest
            {
                player1GamePiece.Location = new Point(715, 200);
                communityChestP1();
            }

            if (player1Position == 34)      //bond st
            {
                player1GamePiece.Location = new Point(717, 253);

                if (bondStreet == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Bond Street?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        bondStreet = 1;
                        player1Cash = player1Cash - 320;
                        Player1MoneyValue.Text = player1Cash.ToString();
                        bondStreetOwnedP1.Visible = true;
                    }
                }

                if (bondStreet == 1) 
                {
                    //do nothing as this is p1
                }

                if (bondStreet == 2)
                {
                    MessageBox.Show("This square is owned by Player 2! Pay £320 to Player 2!");

                    player1Cash = player1Cash - 320;
                    Player1MoneyValue.Text = player1Cash.ToString();

                    player2Cash = player2Cash + 320;
                    Player2MoneyValue.Text = player2Cash.ToString();
                }

                if (bondStreet == 3)
                {
                    MessageBox.Show("This square is owned by Player 3! Pay £320 to Player 3!");

                    player1Cash = player1Cash - 320;
                    Player1MoneyValue.Text = player1Cash.ToString();

                    player3Cash = player3Cash + 320;
                    Player3MoneyValue.Text = player3Cash.ToString();
                }

                if (bondStreet == 4)
                {
                    MessageBox.Show("This square is owned by player 4! Pay £320 to Player 4!");

                    player1Cash = player1Cash - 320;
                    Player1MoneyValue.Text = player1Cash.ToString();

                    player4Cash = player4Cash + 320;
                    Player4MoneyValue.Text = player4Cash.ToString();
                }
            }

            if (player1Position == 35)      //liverpool st station
            {
                player1GamePiece.Location = new Point(714, 305);

                if (liverpoolStreetStation == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Liverpool Street Station?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        liverpoolStreetStation = 1;
                        player1Cash = player1Cash - 200;
                        Player1MoneyValue.Text = player1Cash.ToString();
                        livStreetStationOwnedP1.Visible = true;
                    }
                }

                if (liverpoolStreetStation == 1) 
                {
                    //do nothing as this is p1
                }

                if (liverpoolStreetStation == 2)
                {
                    MessageBox.Show("This square is owned by Player 2! Pay £200 to Player 2!");

                    player1Cash = player1Cash - 200;
                    Player1MoneyValue.Text = player1Cash.ToString();

                    player2Cash = player2Cash + 200;
                    Player2MoneyValue.Text = player2Cash.ToString();
                }

                if (liverpoolStreetStation == 3)
                {
                    MessageBox.Show("This square is owned by Player 3! Pay £200 to Player 3!");

                    player1Cash = player1Cash - 200;
                    Player1MoneyValue.Text = player1Cash.ToString();

                    player3Cash = player3Cash + 200;
                    Player3MoneyValue.Text = player3Cash.ToString();
                }

                if (liverpoolStreetStation == 4)
                {
                    MessageBox.Show("This square is owned by player 4! Pay £200 to Player 4!");

                    player1Cash = player1Cash - 200;
                    Player1MoneyValue.Text = player1Cash.ToString();

                    player4Cash = player4Cash + 200;
                    Player4MoneyValue.Text = player4Cash.ToString();
                }
            }

            if (player1Position == 36)      //chance
            {
                player1GamePiece.Location = new Point(716, 360);
                chancePlayer1();
                Player1MoneyValue.Text = player1Cash.ToString();
            }

            if (player1Position == 37)      //park ln
            {
                player1GamePiece.Location = new Point(719, 412);

                if (parkLane == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Park Lane?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        parkLane = 1;
                        player1Cash = player1Cash - 350;
                        Player1MoneyValue.Text = player1Cash.ToString();
                        parkLaneOwnedP1.Visible = true;
                    }
                }

                if (parkLane == 1) // if penton is owned by p1
                {
                    //do nothing as this is p1
                }

                if (parkLane == 2)
                {
                    MessageBox.Show("This square is owned by Player 2! Pay £350 to Player 2!");

                    player1Cash = player1Cash - 350;
                    Player1MoneyValue.Text = player1Cash.ToString();

                    player2Cash = player2Cash + 350;
                    Player2MoneyValue.Text = player2Cash.ToString();
                }

                if (parkLane == 3)
                {
                    MessageBox.Show("This square is owned by Player 3! Pay £350 to Player 3!");

                    player1Cash = player1Cash - 350;
                    Player1MoneyValue.Text = player1Cash.ToString();

                    player3Cash = player3Cash + 350;
                    Player3MoneyValue.Text = player3Cash.ToString();
                }

                if (parkLane == 4)
                {
                    MessageBox.Show("This square is owned by player 4! Pay £350 to Player 4!");

                    player1Cash = player1Cash - 350;
                    Player1MoneyValue.Text = player1Cash.ToString();

                    player4Cash = player4Cash + 350;
                    Player4MoneyValue.Text = player4Cash.ToString();
                }
            }

            if (player1Position == 38)      //super tax
            {
                player1GamePiece.Location = new Point(713, 467);
                MessageBox.Show("Super Tax! Pay £100");
                player1Cash = player1Cash - 100;
                Player1MoneyValue.Text = player1Cash.ToString();
            }

            if (player1Position == 39)      //mayfair
            {
                player1GamePiece.Location = new Point(719, 521);

                if (mayfair == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Mayfair?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        mayfair = 1;
                        player1Cash = player1Cash - 400;
                        Player1MoneyValue.Text = player1Cash.ToString();
                        mayfairOwnedP1.Visible = true;
                    }
                }

                if (mayfair == 1) // if penton is owned by p1
                {
                    //do nothing as this is p1
                }

                if (mayfair == 2)
                {
                    MessageBox.Show("This square is owned by Player 2! Pay £400 to Player 2!");

                    player1Cash = player1Cash - 400;
                    Player1MoneyValue.Text = player1Cash.ToString();

                    player2Cash = player2Cash + 400;
                    Player2MoneyValue.Text = player2Cash.ToString();
                }

                if (mayfair == 3)
                {
                    MessageBox.Show("This square is owned by Player 3! Pay £400 to Player 3!");

                    player1Cash = player1Cash - 400;
                    Player1MoneyValue.Text = player1Cash.ToString();

                    player3Cash = player3Cash + 400;
                    Player3MoneyValue.Text = player3Cash.ToString();
                }

                if (mayfair == 4)
                {
                    MessageBox.Show("This square is owned by player 4! Pay £400 to Player 4!");

                    player1Cash = player1Cash - 400;
                    Player1MoneyValue.Text = player1Cash.ToString();

                    player4Cash = player4Cash + 400;
                    Player4MoneyValue.Text = player4Cash.ToString();
                }
            }

            if (player1Position == 600)      //in jail
            {
                player1GamePiece.Location = new Point(61, 574);
                MessageBox.Show("Welcome to Jail! Don't drop the soap! Roll a 6, 10 or 12 to leave!");

                player1InJail = true;
            }
        }

        void player2Move()
        {
            player2Position += totalvalue;

            if(player2Position >= 40)
            {
                player2Position = player2Position - 40;
            }

            if (player2Position == 100) //start pos on scoreboard
            {
                player2GamePiece.Location = new Point(797, 93);
            }

            if (player2Position == 0) //go
            {
                player2GamePiece.Location = new Point(729, 593);
            }

            if (player2Position == 1) //okr
            {
                player2GamePiece.Location = new Point(652, 599);

                if (oldKentRoad == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Old Kent Road?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        oldKentRoad = 2;
                        player2Cash = player2Cash - 60;
                        Player2MoneyValue.Text = player2Cash.ToString();
                        oldKentRoadOwnedP2.Visible = true;
                    }
                }

                if (oldKentRoad == 1) // if old kent road is owned by p1
                {
                    MessageBox.Show("This square is owned by Player 1! Pay £60 to Player 1!");

                    player2Cash = player2Cash - 60;
                    Player2MoneyValue.Text = player2Cash.ToString();

                    player1Cash = player1Cash + 60;
                    Player1MoneyValue.Text = player1Cash.ToString();
                }

                if (oldKentRoad == 2)
                {
                    //nothing 
                }

                if (oldKentRoad == 3)
                {
                    MessageBox.Show("This square is owned by Player 3! Pay £60 to Player 3!");

                    player2Cash = player2Cash - 60;
                    Player2MoneyValue.Text = player2Cash.ToString();

                    player3Cash = player3Cash + 60;
                    Player3MoneyValue.Text = player3Cash.ToString();
                }

                if (oldKentRoad == 4)
                {
                    MessageBox.Show("This square is owned by player 4! Pay £60 to Player 4!");

                    player2Cash = player2Cash - 60;
                    Player2MoneyValue.Text = player2Cash.ToString();

                    player4Cash = player4Cash + 60;
                    Player4MoneyValue.Text = player4Cash.ToString();

                }

            }

            if (player2Position == 2) //comm chest
            {
                player2GamePiece.Location = new Point(591, 599);
                communityChestP2();
            }

            if (player2Position == 3) //whitechapel
            {
                player2GamePiece.Location = new Point(527, 600);

                if (whitehapelRoad == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Whitechapel road?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        whitehapelRoad = 2;
                        player2Cash = player2Cash - 60;
                        Player2MoneyValue.Text = player2Cash.ToString();
                        whitechapelRoadOwnedP2.Visible = true;
                    }
                }

                if (whitehapelRoad == 1) // if whitehapel road is owned by p1
                {
                    MessageBox.Show("This square is owned by Player 1! Pay £60 to Player 1!");

                    player2Cash = player2Cash - 60;
                    Player2MoneyValue.Text = player2Cash.ToString();

                    player1Cash = player1Cash + 60;
                    Player1MoneyValue.Text = player1Cash.ToString();
                }

                if (whitehapelRoad == 2)
                {
                    //nothing 
                }

                if (whitehapelRoad == 3)
                {
                    MessageBox.Show("This square is owned by Player 3! Pay £60 to Player 3!");

                    player2Cash = player2Cash - 60;
                    Player2MoneyValue.Text = player2Cash.ToString();

                    player3Cash = player3Cash + 60;
                    Player3MoneyValue.Text = player3Cash.ToString();
                }

                if (whitehapelRoad == 4)
                {
                    MessageBox.Show("This square is owned by player 4! Pay £60 to Player 4!");

                    player2Cash = player2Cash - 60;
                    Player2MoneyValue.Text = player2Cash.ToString();

                    player4Cash = player4Cash + 60;
                    Player4MoneyValue.Text = player4Cash.ToString();
                }
            }

            if (player2Position == 4)   //income tax
            {
                player2GamePiece.Location = new Point(463, 594);
                MessageBox.Show("Income Tax! Pay £200");
                player2Cash = player2Cash - 200;
                Player2MoneyValue.Text = player2Cash.ToString();

            }

            if (player2Position == 5) //kings cross station
            {
                player2GamePiece.Location = new Point(402, 594);

                if (kingsCrossStation == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Kings Cross Station?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        kingsCrossStation = 2;
                        player2Cash = player2Cash - 200;
                        Player2MoneyValue.Text = player2Cash.ToString();
                        kingsCrossOwnedP2.Visible = true;
                    }
                }

                if (kingsCrossStation == 1) // if whitehapel road is owned by p1
                {
                    MessageBox.Show("This square is owned by Player 1! Pay £200 to Player 1!");

                    player2Cash = player2Cash - 200;
                    Player2MoneyValue.Text = player2Cash.ToString();

                    player1Cash = player1Cash + 200;
                    Player1MoneyValue.Text = player1Cash.ToString();
                }

                if (kingsCrossStation == 2)
                {
                    //nothing 
                }

                if (kingsCrossStation == 3)
                {
                    MessageBox.Show("This square is owned by Player 3! Pay £200 to Player 3!");

                    player2Cash = player2Cash - 200;
                    Player2MoneyValue.Text = player2Cash.ToString();

                    player3Cash = player3Cash + 200;
                    Player3MoneyValue.Text = player3Cash.ToString();
                }

                if (kingsCrossStation == 4)
                {
                    MessageBox.Show("This square is owned by player 4! Pay £200 to Player 4!");

                    player2Cash = player2Cash - 200;
                    Player2MoneyValue.Text = player2Cash.ToString();

                    player4Cash = player4Cash + 200;
                    Player4MoneyValue.Text = player4Cash.ToString();
                }
            }

            if (player2Position == 6) //angel islington
            {
                player2GamePiece.Location = new Point(343, 596);

                if (theAngelIslington == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy The Angel Islington?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        theAngelIslington = 2;
                        player2Cash = player2Cash - 100;
                        Player2MoneyValue.Text = player2Cash.ToString();
                        angelIslingtonOwnedP2.Visible = true;
                    }
                }

                if (theAngelIslington == 1) // if whitehapel road is owned by p1
                {
                    MessageBox.Show("This square is owned by Player 1! Pay £100 to Player 1!");

                    player2Cash = player2Cash - 100;
                    Player2MoneyValue.Text = player2Cash.ToString();

                    player1Cash = player1Cash + 100;
                    Player1MoneyValue.Text = player1Cash.ToString();
                }

                if (theAngelIslington == 2)
                {
                    //nothing 
                }

                if (theAngelIslington == 3)
                {
                    MessageBox.Show("This square is owned by Player 3! Pay £100 to Player 3!");

                    player2Cash = player2Cash - 100;
                    Player2MoneyValue.Text = player2Cash.ToString();

                    player3Cash = player3Cash + 100;
                    Player3MoneyValue.Text = player3Cash.ToString();
                }

                if (theAngelIslington == 4)
                {
                    MessageBox.Show("This square is owned by player 4! Pay £100 to Player 4!");

                    player2Cash = player2Cash - 100;
                    Player2MoneyValue.Text = player2Cash.ToString();

                    player4Cash = player4Cash + 100;
                    Player4MoneyValue.Text = player4Cash.ToString();
                }
            }

            if (player2Position == 7) //chance
            {
                player2GamePiece.Location = new Point(279, 597);
                chancePlayer2();
            }

            if (player2Position == 8)   //euston road
            {
                player2GamePiece.Location = new Point(217, 597);

                if (eustonRoad == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Euston Road?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        eustonRoad = 2;
                        player2Cash = player2Cash - 100;
                        Player2MoneyValue.Text = player2Cash.ToString();
                        eustonRoadOwnedP2.Visible = true;
                    }
                }

                if (eustonRoad == 1) // if whitehapel road is owned by p1
                {
                    MessageBox.Show("This square is owned by Player 1! Pay £100 to Player 1!");

                    player2Cash = player2Cash - 100;
                    Player2MoneyValue.Text = player2Cash.ToString();

                    player1Cash = player1Cash + 100;
                    Player1MoneyValue.Text = player1Cash.ToString();
                }

                if (eustonRoad == 2)
                {
                    //nothing 
                }

                if (eustonRoad == 3)
                {
                    MessageBox.Show("This square is owned by Player 3! Pay £100 to Player 3!");

                    player2Cash = player2Cash - 100;
                    Player2MoneyValue.Text = player2Cash.ToString();

                    player3Cash = player3Cash + 100;
                    Player3MoneyValue.Text = player3Cash.ToString();
                }

                if (eustonRoad == 4)
                {
                    MessageBox.Show("This square is owned by player 4! Pay £100 to Player 4!");

                    player2Cash = player2Cash - 100;
                    Player2MoneyValue.Text = player2Cash.ToString();

                    player4Cash = player4Cash + 100;
                    Player4MoneyValue.Text = player4Cash.ToString();
                }
            }

            if (player2Position == 9) //pentonville road
            {
                player2GamePiece.Location = new Point(155, 597);

                if (pentonvilleRoad == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Pentonville Road?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        pentonvilleRoad = 2;
                        player2Cash = player2Cash - 120;
                        Player2MoneyValue.Text = player2Cash.ToString();
                        pentonvilleRoadOwnedP2.Visible = true;
                    }
                }

                if (pentonvilleRoad == 1) // if penton road is owned by p1
                {
                    MessageBox.Show("This square is owned by Player 1! Pay £120 to Player 1!");

                    player2Cash = player2Cash - 120;
                    Player2MoneyValue.Text = player2Cash.ToString();

                    player1Cash = player1Cash + 120;
                    Player1MoneyValue.Text = player1Cash.ToString();
                }

                if (pentonvilleRoad == 2)
                {
                    //nothing 
                }

                if (pentonvilleRoad == 3)
                {
                    MessageBox.Show("This square is owned by Player 3! Pay £100 to Player 3!");

                    player2Cash = player2Cash - 120;
                    Player2MoneyValue.Text = player2Cash.ToString();

                    player3Cash = player3Cash + 120;
                    Player3MoneyValue.Text = player3Cash.ToString();
                }

                if (pentonvilleRoad == 4)
                {
                    MessageBox.Show("This square is owned by player 4! Pay £100 to Player 4!");

                    player2Cash = player2Cash - 120;
                    Player2MoneyValue.Text = player2Cash.ToString();

                    player4Cash = player4Cash + 120;
                    Player4MoneyValue.Text = player4Cash.ToString();
                }
            }

            if (player2Position == 10) //jv jail         
            {
                player2GamePiece.Location = new Point(26, 607);
            }

            if (player2Position == 11) //pall mall
            {
                player2GamePiece.Location = new Point(63, 519);

                if (pallMall == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Pall Mall?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        pallMall = 2;
                        player2Cash = player2Cash - 140;
                        Player2MoneyValue.Text = player2Cash.ToString();
                        pallMallOwnedP2.Visible = true;
                    }
                }

                if (pallMall == 1) // if penton road is owned by p1
                {
                    MessageBox.Show("This square is owned by Player 1! Pay £140 to Player 1!");

                    player2Cash = player2Cash - 140;
                    Player2MoneyValue.Text = player2Cash.ToString();

                    player1Cash = player1Cash + 140;
                    Player1MoneyValue.Text = player1Cash.ToString();
                }

                if (pallMall == 2)
                {
                    //nothing 
                }

                if (pallMall == 3)
                {
                    MessageBox.Show("This square is owned by Player 3! Pay £140 to Player 3!");

                    player2Cash = player2Cash - 140;
                    Player2MoneyValue.Text = player2Cash.ToString();

                    player3Cash = player3Cash + 140;
                    Player3MoneyValue.Text = player3Cash.ToString();
                }

                if (pallMall == 4)
                {
                    MessageBox.Show("This square is owned by player 4! Pay £140 to Player 4!");

                    player2Cash = player2Cash - 140;
                    Player2MoneyValue.Text = player2Cash.ToString();

                    player4Cash = player4Cash + 140;
                    Player4MoneyValue.Text = player4Cash.ToString();
                }
            }

            if (player2Position == 12) //electric company
            {
                player2GamePiece.Location = new Point(64, 467);

                if (electricCompany == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy The Electric Company?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        electricCompany = 2;
                        player2Cash = player2Cash - 150;
                        Player2MoneyValue.Text = player2Cash.ToString();
                        electricCompanyOwnedP2.Visible = true;
                    }
                }

                if (electricCompany == 1) // if elec is owned by p1
                {
                    MessageBox.Show("This square is owned by Player 1! Pay £150 to Player 1!");

                    player2Cash = player2Cash - 150;
                    Player2MoneyValue.Text = player2Cash.ToString();

                    player1Cash = player1Cash + 150;
                    Player1MoneyValue.Text = player1Cash.ToString();
                }

                if (electricCompany == 2)
                {
                    //nothing 
                }

                if (electricCompany == 3)
                {
                    MessageBox.Show("This square is owned by Player 3! Pay £150 to Player 3!");

                    player2Cash = player2Cash - 150;
                    Player2MoneyValue.Text = player2Cash.ToString();

                    player3Cash = player3Cash + 150;
                    Player3MoneyValue.Text = player3Cash.ToString();
                }

                if (electricCompany == 4)
                {
                    MessageBox.Show("This square is owned by player 4! Pay £150 to Player 4!");

                    player2Cash = player2Cash - 150;
                    Player2MoneyValue.Text = player2Cash.ToString();

                    player4Cash = player4Cash + 150;
                    Player4MoneyValue.Text = player4Cash.ToString();
                }
            }

            if (player2Position == 13) //whitehall
            {
                player2GamePiece.Location = new Point(59, 412);

                if (whiteHall == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Whitehall?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        whiteHall = 2;
                        player2Cash = player2Cash - 140;
                        Player2MoneyValue.Text = player2Cash.ToString();
                        whitehallOwnedP2.Visible = true;
                    }
                }

                if (whiteHall == 1) // if whitehall road is owned by p1
                {
                    MessageBox.Show("This square is owned by Player 1! Pay £140 to Player 1!");

                    player2Cash = player2Cash - 140;
                    Player2MoneyValue.Text = player2Cash.ToString();

                    player1Cash = player1Cash + 140;
                    Player1MoneyValue.Text = player1Cash.ToString();
                }

                if (whiteHall == 2)
                {
                    //nothing 
                }

                if (whiteHall == 3)
                {
                    MessageBox.Show("This square is owned by Player 3! Pay £140 to Player 3!");

                    player2Cash = player2Cash - 140;
                    Player2MoneyValue.Text = player2Cash.ToString();

                    player3Cash = player3Cash + 140;
                    Player3MoneyValue.Text = player3Cash.ToString();
                }

                if (whiteHall == 4)
                {
                    MessageBox.Show("This square is owned by player 4! Pay £140 to Player 4!");

                    player2Cash = player2Cash - 140;
                    Player2MoneyValue.Text = player2Cash.ToString();

                    player4Cash = player4Cash + 140;
                    Player4MoneyValue.Text = player4Cash.ToString();
                }
            }

            if (player2Position == 14) //northum
            {
                player2GamePiece.Location = new Point(61, 359);

                if (northumberlandAvenue == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Northumberland Avenue?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        northumberlandAvenue = 2;
                        player2Cash = player2Cash - 160;
                        Player2MoneyValue.Text = player2Cash.ToString();
                        northumberlandOwnedP2.Visible = true;
                    }
                }

                if (northumberlandAvenue == 1) // if northum is owned by p1
                {
                    MessageBox.Show("This square is owned by Player 1! Pay £160 to Player 1!");

                    player2Cash = player2Cash - 160;
                    Player2MoneyValue.Text = player2Cash.ToString();

                    player1Cash = player1Cash + 160;
                    Player1MoneyValue.Text = player1Cash.ToString();
                }

                if (northumberlandAvenue == 2)
                {
                    //nothing 
                }

                if (northumberlandAvenue == 3)
                {
                    MessageBox.Show("This square is owned by Player 3! Pay £160 to Player 3!");

                    player2Cash = player2Cash - 160;
                    Player2MoneyValue.Text = player2Cash.ToString();

                    player3Cash = player3Cash + 160;
                    Player3MoneyValue.Text = player3Cash.ToString();
                }

                if (northumberlandAvenue == 4)
                {
                    MessageBox.Show("This square is owned by player 4! Pay £160 to Player 4!");

                    player2Cash = player2Cash - 160;
                    Player2MoneyValue.Text = player2Cash.ToString();

                    player4Cash = player4Cash + 160;
                    Player4MoneyValue.Text = player4Cash.ToString();
                }
            }

            if (player2Position == 15) //marylebone station
            {
                player2GamePiece.Location = new Point(63, 307);

                if (maryleboneStation == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Marylebone Station?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        maryleboneStation = 2;
                        player2Cash = player2Cash - 200;
                        Player2MoneyValue.Text = player2Cash.ToString();
                        maryleboneStationOwnedP2.Visible = true;
                    }
                }

                if (maryleboneStation == 1) // if m station is owned by p1
                {
                    MessageBox.Show("This square is owned by Player 1! Pay £200 to Player 1!");

                    player2Cash = player2Cash - 200;
                    Player2MoneyValue.Text = player2Cash.ToString();

                    player1Cash = player1Cash + 200;
                    Player1MoneyValue.Text = player1Cash.ToString();
                }

                if (maryleboneStation == 2)
                {
                    //nothing 
                }

                if (maryleboneStation == 3)
                {
                    MessageBox.Show("This square is owned by Player 3! Pay £200 to Player 3!");

                    player2Cash = player2Cash - 200;
                    Player2MoneyValue.Text = player2Cash.ToString();

                    player3Cash = player3Cash + 200;
                    Player3MoneyValue.Text = player3Cash.ToString();
                }

                if (maryleboneStation == 4)
                {
                    MessageBox.Show("This square is owned by player 4! Pay £200 to Player 4!");

                    player2Cash = player2Cash - 200;
                    Player2MoneyValue.Text = player2Cash.ToString();

                    player4Cash = player4Cash + 200;
                    Player4MoneyValue.Text = player4Cash.ToString();
                }
            }

            if (player2Position == 16) //bow st
            {
                player2GamePiece.Location = new Point(63, 254);

                if (bowStreet == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Bow Street?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        bowStreet = 2;
                        player2Cash = player2Cash - 180;
                        Player2MoneyValue.Text = player2Cash.ToString();
                        bowStreetOwnedP2.Visible = true;
                    }
                }

                if (bowStreet == 1) // if bow st is owned by p1
                {
                    MessageBox.Show("This square is owned by Player 1! Pay £180 to Player 1!");

                    player2Cash = player2Cash - 180;
                    Player2MoneyValue.Text = player2Cash.ToString();

                    player1Cash = player1Cash + 180;
                    Player1MoneyValue.Text = player1Cash.ToString();
                }

                if (bowStreet == 2)
                {
                    //nothing 
                }

                if (bowStreet == 3)
                {
                    MessageBox.Show("This square is owned by Player 3! Pay £180 to Player 3!");

                    player2Cash = player2Cash - 180;
                    Player2MoneyValue.Text = player2Cash.ToString();

                    player3Cash = player3Cash + 180;
                    Player3MoneyValue.Text = player3Cash.ToString();
                }

                if (bowStreet == 4)
                {
                    MessageBox.Show("This square is owned by player 4! Pay £180 to Player 4!");

                    player2Cash = player2Cash - 180;
                    Player2MoneyValue.Text = player2Cash.ToString();

                    player4Cash = player4Cash + 180;
                    Player4MoneyValue.Text = player4Cash.ToString();
                }
            }

            if (player2Position == 17) //com chest
            {
                player2GamePiece.Location = new Point(63, 200);
                communityChestP2();
            }

            if (player2Position == 18) //marlborugh stret
            {
                player2GamePiece.Location = new Point(59, 148);

                if (marlboroughStreet == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Marlborough Street?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        marlboroughStreet = 2;
                        player2Cash = player2Cash - 180;
                        Player2MoneyValue.Text = player2Cash.ToString();
                        marlboroughStreetOwnedP2.Visible = true;
                    }
                }

                if (marlboroughStreet == 1) // if penton road is owned by p1
                {
                    MessageBox.Show("This square is owned by Player 1! Pay £180 to Player 1!");

                    player2Cash = player2Cash - 180;
                    Player2MoneyValue.Text = player2Cash.ToString();

                    player1Cash = player1Cash + 180;
                    Player1MoneyValue.Text = player1Cash.ToString();
                }

                if (marlboroughStreet == 2)
                {
                    //nothing 
                }

                if (marlboroughStreet == 3)
                {
                    MessageBox.Show("This square is owned by Player 3! Pay £180 to Player 3!");

                    player2Cash = player2Cash - 180;
                    Player2MoneyValue.Text = player2Cash.ToString();

                    player3Cash = player3Cash + 180;
                    Player3MoneyValue.Text = player3Cash.ToString();
                }

                if (marlboroughStreet == 4)
                {
                    MessageBox.Show("This square is owned by player 4! Pay £180 to Player 4!");

                    player2Cash = player2Cash - 180;
                    Player2MoneyValue.Text = player2Cash.ToString();

                    player4Cash = player4Cash + 180;
                    Player4MoneyValue.Text = player4Cash.ToString();
                }
            }

            if (player2Position == 19) //vine st
            {
                player2GamePiece.Location = new Point(61, 94);

                if (vineStreet == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Vine Street?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        vineStreet = 2;
                        player2Cash = player2Cash - 200;
                        Player2MoneyValue.Text = player2Cash.ToString();
                        vineStreetOwnedP2.Visible = true;
                    }
                }

                if (vineStreet == 1) // if penton road is owned by p1
                {
                    MessageBox.Show("This square is owned by Player 1! Pay £200 to Player 1!");

                    player2Cash = player2Cash - 200;
                    Player2MoneyValue.Text = player2Cash.ToString();

                    player1Cash = player1Cash + 200;
                    Player1MoneyValue.Text = player1Cash.ToString();
                }

                if (vineStreet == 2)
                {
                    //nothing 
                }

                if (vineStreet == 3)
                {
                    MessageBox.Show("This square is owned by Player 3! Pay £200 to Player 3!");

                    player2Cash = player2Cash - 200;
                    Player2MoneyValue.Text = player2Cash.ToString();

                    player3Cash = player3Cash + 200;
                    Player3MoneyValue.Text = player3Cash.ToString();
                }

                if (vineStreet == 4)
                {
                    MessageBox.Show("This square is owned by player 4! Pay £200 to Player 4!");

                    player2Cash = player2Cash - 200;
                    Player2MoneyValue.Text = player2Cash.ToString();

                    player4Cash = player4Cash + 200;
                    Player4MoneyValue.Text = player4Cash.ToString();
                }
            }

            if (player2Position == 20) //free parking      
            {
                player2GamePiece.Location = new Point(92, 8);
            }

            if (player2Position == 21) // strand
            {
                player2GamePiece.Location = new Point(155, 11);

                if (strand == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Strand?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        strand = 2;
                        player2Cash = player2Cash - 220;
                        Player2MoneyValue.Text = player2Cash.ToString();
                        strandOwnedP2.Visible = true;
                    }
                }

                if (strand == 1) 
                {
                    MessageBox.Show("This square is owned by Player 1! Pay £220 to Player 1!");

                    player2Cash = player2Cash - 220;
                    Player2MoneyValue.Text = player2Cash.ToString();

                    player1Cash = player1Cash + 220;
                    Player1MoneyValue.Text = player1Cash.ToString();
                }

                if (strand == 2)
                {
                    //nothing 
                }

                if (strand == 3)
                {
                    MessageBox.Show("This square is owned by Player 3! Pay £220 to Player 3!");

                    player2Cash = player2Cash - 220;
                    Player2MoneyValue.Text = player2Cash.ToString();

                    player3Cash = player3Cash + 220;
                    Player3MoneyValue.Text = player3Cash.ToString();
                }

                if (strand == 4)
                {
                    MessageBox.Show("This square is owned by player 4! Pay £220 to Player 4!");

                    player2Cash = player2Cash - 220;
                    Player2MoneyValue.Text = player2Cash.ToString();

                    player4Cash = player4Cash + 220;
                    Player4MoneyValue.Text = player4Cash.ToString();
                }
            }

            if (player2Position == 22) // chance
            {
                player2GamePiece.Location = new Point(215, 11);
                chancePlayer2();
            }

            if (player2Position == 23) //fleet stret
            {
                player2GamePiece.Location = new Point(281, 11);

                if (fleetStreet == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Fleet Street?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        fleetStreet = 2;
                        player2Cash = player2Cash - 220;
                        Player2MoneyValue.Text = player2Cash.ToString();
                        FleetStreetOwnedP2.Visible = true;
                    }
                }

                if (fleetStreet == 1) 
                {
                    MessageBox.Show("This square is owned by Player 1! Pay £220 to Player 1!");

                    player2Cash = player2Cash - 220;
                    Player2MoneyValue.Text = player2Cash.ToString();

                    player1Cash = player1Cash + 220;
                    Player1MoneyValue.Text = player1Cash.ToString();
                }

                if (fleetStreet == 2)
                {
                    //nothing 
                }

                if (fleetStreet == 3)
                {
                    MessageBox.Show("This square is owned by Player 3! Pay £220 to Player 3!");

                    player2Cash = player2Cash - 220;
                    Player2MoneyValue.Text = player2Cash.ToString();

                    player3Cash = player3Cash + 220;
                    Player3MoneyValue.Text = player3Cash.ToString();
                }

                if (fleetStreet == 4)
                {
                    MessageBox.Show("This square is owned by player 4! Pay £220 to Player 4!");

                    player2Cash = player2Cash - 220;
                    Player2MoneyValue.Text = player2Cash.ToString();

                    player4Cash = player4Cash + 220;
                    Player4MoneyValue.Text = player4Cash.ToString();
                }
            }

            if (player2Position == 24) //trafalgar square
            {
                player2GamePiece.Location = new Point(340, 11);

                if (trafalgerSquare == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Trafalgar Square?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        trafalgerSquare = 2;
                        player2Cash = player2Cash - 240;
                        Player2MoneyValue.Text = player2Cash.ToString();
                        trafalgarSquareOwnedP2.Visible = true;
                    }
                }

                if (trafalgerSquare == 1)
                {
                    MessageBox.Show("This square is owned by Player 1! Pay £240 to Player 1!");

                    player2Cash = player2Cash - 240;
                    Player2MoneyValue.Text = player2Cash.ToString();

                    player1Cash = player1Cash + 240;
                    Player1MoneyValue.Text = player1Cash.ToString();
                }

                if (trafalgerSquare == 2)
                {
                    //nothing 
                }

                if (trafalgerSquare == 3)
                {
                    MessageBox.Show("This square is owned by Player 3! Pay £240 to Player 3!");

                    player2Cash = player2Cash - 240;
                    Player2MoneyValue.Text = player2Cash.ToString();

                    player3Cash = player3Cash + 240;
                    Player3MoneyValue.Text = player3Cash.ToString();
                }

                if (trafalgerSquare == 4)
                {
                    MessageBox.Show("This square is owned by player 4! Pay £240 to Player 4!");

                    player2Cash = player2Cash - 240;
                    Player2MoneyValue.Text = player2Cash.ToString();

                    player4Cash = player4Cash + 240;
                    Player4MoneyValue.Text = player4Cash.ToString();
                }
            }

            if (player2Position == 25) //fenchurch street st
            {
                player2GamePiece.Location = new Point(403, 18);

                if (fenchurchStreetStation == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Fenchurch Street Station?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        fenchurchStreetStation = 2;
                        player2Cash = player2Cash - 200;
                        Player2MoneyValue.Text = player2Cash.ToString();
                        fenchurchStationOwnedP2.Visible = true;
                    }
                }

                if (fenchurchStreetStation == 1) // if fen station is owned by p1
                {
                    MessageBox.Show("This square is owned by Player 1! Pay £200 to Player 1!");

                    player2Cash = player2Cash - 200;
                    Player2MoneyValue.Text = player2Cash.ToString();

                    player1Cash = player1Cash + 200;
                    Player1MoneyValue.Text = player1Cash.ToString();
                }

                if (fenchurchStreetStation == 2)
                {
                    //nothing 
                }

                if (fenchurchStreetStation == 3)
                {
                    MessageBox.Show("This square is owned by Player 3! Pay £200 to Player 3!");

                    player2Cash = player2Cash - 200;
                    Player2MoneyValue.Text = player2Cash.ToString();

                    player3Cash = player3Cash + 200;
                    Player3MoneyValue.Text = player3Cash.ToString();
                }

                if (fenchurchStreetStation == 4)
                {
                    MessageBox.Show("This square is owned by player 4! Pay £200 to Player 4!");

                    player2Cash = player2Cash - 200;
                    Player2MoneyValue.Text = player2Cash.ToString();

                    player4Cash = player4Cash + 200;
                    Player4MoneyValue.Text = player4Cash.ToString();
                }
            }

            if (player2Position == 26) //leicester sq
            {
                player2GamePiece.Location = new Point(466, 11);

                if (leicesterSquare == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Leicester Square?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        leicesterSquare = 2;
                        player2Cash = player2Cash - 260;
                        Player2MoneyValue.Text = player2Cash.ToString();
                        leicesterSquareOwnedP2.Visible = true;
                    }
                }

                if (leicesterSquare == 1)
                {
                    MessageBox.Show("This square is owned by Player 1! Pay £260 to Player 1!");

                    player2Cash = player2Cash - 260;
                    Player2MoneyValue.Text = player2Cash.ToString();

                    player1Cash = player1Cash + 260;
                    Player1MoneyValue.Text = player1Cash.ToString();
                }

                if (leicesterSquare == 2)
                {
                    //nothing 
                }

                if (leicesterSquare == 3)
                {
                    MessageBox.Show("This square is owned by Player 3! Pay £260 to Player 3!");

                    player2Cash = player2Cash - 260;
                    Player2MoneyValue.Text = player2Cash.ToString();

                    player3Cash = player3Cash + 260;
                    Player3MoneyValue.Text = player3Cash.ToString();
                }

                if (leicesterSquare == 4)
                {
                    MessageBox.Show("This square is owned by player 4! Pay £260 to Player 4!");

                    player2Cash = player2Cash - 260;
                    Player2MoneyValue.Text = player2Cash.ToString();

                    player4Cash = player4Cash + 260;
                    Player4MoneyValue.Text = player4Cash.ToString();
                }
            }

            if (player2Position == 27) //cov st
            {
                player2GamePiece.Location = new Point(527, 11);

                if (coventryStreet == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Coventry Street?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        coventryStreet = 2;
                        player2Cash = player2Cash - 260;
                        Player2MoneyValue.Text = player2Cash.ToString();
                        coventryStreetOwnedP2.Visible = true;
                    }
                }

                if (coventryStreet == 1)
                {
                    MessageBox.Show("This square is owned by Player 1! Pay £260 to Player 1!");

                    player2Cash = player2Cash - 260;
                    Player2MoneyValue.Text = player2Cash.ToString();

                    player1Cash = player1Cash + 260;
                    Player1MoneyValue.Text = player1Cash.ToString();
                }

                if (coventryStreet == 2)
                {
                    //nothing 
                }

                if (coventryStreet == 3)
                {
                    MessageBox.Show("This square is owned by Player 3! Pay £260 to Player 3!");

                    player2Cash = player2Cash - 260;
                    Player2MoneyValue.Text = player2Cash.ToString();

                    player3Cash = player3Cash + 260;
                    Player3MoneyValue.Text = player3Cash.ToString();
                }

                if (coventryStreet == 4)
                {
                    MessageBox.Show("This square is owned by player 4! Pay £260 to Player 4!");

                    player2Cash = player2Cash - 260;
                    Player2MoneyValue.Text = player2Cash.ToString();

                    player4Cash = player4Cash + 260;
                    Player4MoneyValue.Text = player4Cash.ToString();
                }
            }

            if (player2Position == 28) //ww
            {
                player2GamePiece.Location = new Point(591, 11);


                if (waterWorks == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy The Water Works?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        waterWorks = 2;
                        player2Cash = player2Cash - 150;
                        Player2MoneyValue.Text = player2Cash.ToString();
                        waterworksOwnedP2.Visible = true;
                    }
                }

                if (waterWorks == 1) // if elec is owned by p1
                {
                    MessageBox.Show("This square is owned by Player 1! Pay £150 to Player 1!");

                    player2Cash = player2Cash - 150;
                    Player2MoneyValue.Text = player2Cash.ToString();

                    player1Cash = player1Cash + 150;
                    Player1MoneyValue.Text = player1Cash.ToString();
                }

                if (waterWorks == 2)
                {
                    //nothing 
                }

                if (waterWorks == 3)
                {
                    MessageBox.Show("This square is owned by Player 3! Pay £150 to Player 3!");

                    player2Cash = player2Cash - 150;
                    Player2MoneyValue.Text = player2Cash.ToString();

                    player3Cash = player3Cash + 150;
                    Player3MoneyValue.Text = player3Cash.ToString();
                }

                if (waterWorks == 4)
                {
                    MessageBox.Show("This square is owned by player 4! Pay £150 to Player 4!");

                    player2Cash = player2Cash - 150;
                    Player2MoneyValue.Text = player2Cash.ToString();

                    player4Cash = player4Cash + 150;
                    Player4MoneyValue.Text = player4Cash.ToString();
                }
            }

            if (player2Position == 29) //picca
            {
                player2GamePiece.Location = new Point(653, 11);

                if (piccadilly == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Piccadilly?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        piccadilly = 2;
                        player2Cash = player2Cash - 280;
                        Player2MoneyValue.Text = player2Cash.ToString();
                        piccadillyOwnedP2.Visible = true;
                    }
                }

                if (piccadilly == 1)
                {
                    MessageBox.Show("This square is owned by Player 1! Pay £280 to Player 1!");

                    player2Cash = player2Cash - 280;
                    Player2MoneyValue.Text = player2Cash.ToString();

                    player1Cash = player1Cash + 280;
                    Player1MoneyValue.Text = player1Cash.ToString();
                }

                if (piccadilly == 2)
                {
                    //nothing 
                }

                if (piccadilly == 3)
                {
                    MessageBox.Show("This square is owned by Player 3! Pay £280 to Player 3!");

                    player2Cash = player2Cash - 280;
                    Player2MoneyValue.Text = player2Cash.ToString();

                    player3Cash = player3Cash + 280;
                    Player3MoneyValue.Text = player3Cash.ToString();
                }

                if (piccadilly == 4)
                {
                    MessageBox.Show("This square is owned by player 4! Pay £280 to Player 4!");

                    player2Cash = player2Cash - 280;
                    Player2MoneyValue.Text = player2Cash.ToString();

                    player4Cash = player4Cash + 280;
                    Player4MoneyValue.Text = player4Cash.ToString();
                }
            }

            if (player2Position == 30) //go jail         
            {
                player2GamePiece.Location = new Point(749, 11);
                MessageBox.Show("Go to Jail! Do not pass GO!");
                player2GamePiece.Location = new Point(93, 574);
                player2Position = 600;
            }

            if (player2Position == 31) //regent street
            {
                player2GamePiece.Location = new Point(739, 92);
                if (regentStreet == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Regent Street?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        regentStreet = 2;
                        player2Cash = player2Cash - 300;
                        Player2MoneyValue.Text = player2Cash.ToString();
                        regentStreetOwnedP2.Visible = true;
                    }
                }

                if (regentStreet == 1)
                {
                    MessageBox.Show("This square is owned by Player 1! Pay £300 to Player 1!");

                    player2Cash = player2Cash - 300;
                    Player2MoneyValue.Text = player2Cash.ToString();

                    player1Cash = player1Cash + 300;
                    Player1MoneyValue.Text = player1Cash.ToString();
                }

                if (regentStreet == 2)
                {
                    //nothing 
                }

                if (regentStreet == 3)
                {
                    MessageBox.Show("This square is owned by Player 3! Pay £300 to Player 3!");

                    player2Cash = player2Cash - 300;
                    Player2MoneyValue.Text = player2Cash.ToString();

                    player3Cash = player3Cash + 300;
                    Player3MoneyValue.Text = player3Cash.ToString();
                }

                if (regentStreet == 4)
                {
                    MessageBox.Show("This square is owned by player 4! Pay £300 to Player 4!");

                    player2Cash = player2Cash - 300;
                    Player2MoneyValue.Text = player2Cash.ToString();

                    player4Cash = player4Cash + 300;
                    Player4MoneyValue.Text = player4Cash.ToString();
                }
            }

            if (player2Position == 32) //oxford street
            {
                player2GamePiece.Location = new Point(741, 148);

                if (oxfordStreet == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Oxford Street?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        oxfordStreet = 2;
                        player2Cash = player2Cash - 300;
                        Player2MoneyValue.Text = player2Cash.ToString();
                        oxfordStreetOwnedP2.Visible = true;
                    }
                }

                if (oxfordStreet == 1)
                {
                    MessageBox.Show("This square is owned by Player 1! Pay £300 to Player 1!");

                    player2Cash = player2Cash - 300;
                    Player2MoneyValue.Text = player2Cash.ToString();

                    player1Cash = player1Cash + 300;
                    Player1MoneyValue.Text = player1Cash.ToString();
                }

                if (oxfordStreet == 2)
                {
                    //nothing 
                }

                if (oxfordStreet == 3)
                {
                    MessageBox.Show("This square is owned by Player 3! Pay £300 to Player 3!");

                    player2Cash = player2Cash - 300;
                    Player2MoneyValue.Text = player2Cash.ToString();

                    player3Cash = player3Cash + 300;
                    Player3MoneyValue.Text = player3Cash.ToString();
                }

                if (oxfordStreet == 4)
                {
                    MessageBox.Show("This square is owned by player 4! Pay £300 to Player 4!");

                    player2Cash = player2Cash - 300;
                    Player2MoneyValue.Text = player2Cash.ToString();

                    player4Cash = player4Cash + 300;
                    Player4MoneyValue.Text = player4Cash.ToString();
                }
            }

            if (player2Position == 33) //com chest
            {
                player2GamePiece.Location = new Point(739, 200);
                communityChestP2();
            }

            if (player2Position == 34)//bond
            {
                player2GamePiece.Location = new Point(741, 253);

                if (bondStreet == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Bond Street?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        bondStreet = 2;
                        player2Cash = player2Cash - 320;
                        Player2MoneyValue.Text = player2Cash.ToString();
                        bondStreetOwnedP2.Visible = true;
                    }
                }

                if (bondStreet == 1)
                {
                    MessageBox.Show("This square is owned by Player 1! Pay £320 to Player 1!");

                    player2Cash = player2Cash - 320;
                    Player2MoneyValue.Text = player2Cash.ToString();

                    player1Cash = player1Cash + 320;
                    Player1MoneyValue.Text = player1Cash.ToString();
                }

                if (bondStreet == 2)
                {
                    //nothing 
                }

                if (bondStreet == 3)
                {
                    MessageBox.Show("This square is owned by Player 3! Pay £320 to Player 3!");

                    player2Cash = player2Cash - 320;
                    Player2MoneyValue.Text = player2Cash.ToString();

                    player3Cash = player3Cash + 320;
                    Player3MoneyValue.Text = player3Cash.ToString();
                }

                if (bondStreet == 4)
                {
                    MessageBox.Show("This square is owned by player 4! Pay £320 to Player 4!");

                    player2Cash = player2Cash - 320;
                    Player2MoneyValue.Text = player2Cash.ToString();

                    player4Cash = player4Cash + 320;
                    Player4MoneyValue.Text = player4Cash.ToString();
                }
            }

            if (player2Position == 35) //liv st
            {
                player2GamePiece.Location = new Point(738, 305);

                if (liverpoolStreetStation == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Liverpool Street Station?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        liverpoolStreetStation = 2;
                        player2Cash = player2Cash - 200;
                        Player2MoneyValue.Text = player2Cash.ToString();
                        livStreetStationOwnedP2.Visible = true;
                    }
                }

                if (liverpoolStreetStation == 1) // if fen station is owned by p1
                {
                    MessageBox.Show("This square is owned by Player 1! Pay £200 to Player 1!");

                    player2Cash = player2Cash - 200;
                    Player2MoneyValue.Text = player2Cash.ToString();

                    player1Cash = player1Cash + 200;
                    Player1MoneyValue.Text = player1Cash.ToString();
                }

                if (liverpoolStreetStation == 2)
                {
                    //nothing 
                }

                if (liverpoolStreetStation == 3)
                {
                    MessageBox.Show("This square is owned by Player 3! Pay £200 to Player 3!");

                    player2Cash = player2Cash - 200;
                    Player2MoneyValue.Text = player2Cash.ToString();

                    player3Cash = player3Cash + 200;
                    Player3MoneyValue.Text = player3Cash.ToString();
                }

                if (liverpoolStreetStation == 4)
                {
                    MessageBox.Show("This square is owned by player 4! Pay £200 to Player 4!");

                    player2Cash = player2Cash - 200;
                    Player2MoneyValue.Text = player2Cash.ToString();

                    player4Cash = player4Cash + 200;
                    Player4MoneyValue.Text = player4Cash.ToString();
                }
            }

            if (player2Position == 36) //chance
            {
                player2GamePiece.Location = new Point(740, 360);
                chancePlayer2();
            }

            if (player2Position == 37) //park ln
            {
                player2GamePiece.Location = new Point(743, 412);

                if (parkLane == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Park Lane?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        parkLane = 2;
                        player2Cash = player2Cash - 350;
                        Player2MoneyValue.Text = player2Cash.ToString();
                        parkLaneOwnedP2.Visible = true;
                    }
                }

                if (parkLane == 1) 
                {
                    MessageBox.Show("This square is owned by Player 1! Pay £350 to Player 1!");

                    player2Cash = player2Cash - 350;
                    Player2MoneyValue.Text = player2Cash.ToString();

                    player1Cash = player1Cash + 350;
                    Player1MoneyValue.Text = player1Cash.ToString();
                }

                if (parkLane == 2)
                {
                    //nothing 
                }

                if (parkLane == 3)
                {
                    MessageBox.Show("This square is owned by Player 3! Pay £350 to Player 3!");

                    player2Cash = player2Cash - 350;
                    Player2MoneyValue.Text = player2Cash.ToString();

                    player3Cash = player3Cash + 350;
                    Player3MoneyValue.Text = player3Cash.ToString();
                }

                if (parkLane == 4)
                {
                    MessageBox.Show("This square is owned by player 4! Pay £350 to Player 4!");

                    player2Cash = player2Cash - 350;
                    Player2MoneyValue.Text = player2Cash.ToString();

                    player4Cash = player4Cash + 350;
                    Player4MoneyValue.Text = player4Cash.ToString();
                }
            }

            if (player2Position == 38) //super tx
            {
                player2GamePiece.Location = new Point(737, 467);
                MessageBox.Show("Super Tax! Pay £100");
                player2Cash = player2Cash - 100;
                Player2MoneyValue.Text = player2Cash.ToString();
            }

            if (player2Position == 39) //mayfair
            {
                player2GamePiece.Location = new Point(743, 521);
                if (mayfair == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Mayfair?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        mayfair = 2;
                        player2Cash = player2Cash - 400;
                        Player2MoneyValue.Text = player2Cash.ToString();
                        mayfairOwnedP2.Visible = true;
                    }
                }

                if (mayfair == 1) 
                {
                    MessageBox.Show("This square is owned by Player 1! Pay £400 to Player 1!");

                    player2Cash = player2Cash - 400;
                    Player2MoneyValue.Text = player2Cash.ToString();

                    player1Cash = player1Cash + 400;
                    Player1MoneyValue.Text = player1Cash.ToString();
                }

                if (mayfair == 2)
                {
                    //nothing 
                }

                if (mayfair == 3)
                {
                    MessageBox.Show("This square is owned by Player 3! Pay £400 to Player 3!");

                    player2Cash = player2Cash - 400;
                    Player2MoneyValue.Text = player2Cash.ToString();

                    player3Cash = player3Cash + 400;
                    Player3MoneyValue.Text = player3Cash.ToString();
                }

                if (mayfair == 4)
                {
                    MessageBox.Show("This square is owned by player 4! Pay £400 to Player 4!");

                    player2Cash = player2Cash - 400;
                    Player2MoneyValue.Text = player2Cash.ToString();

                    player4Cash = player4Cash + 400;
                    Player4MoneyValue.Text = player4Cash.ToString();
                }
            }

            if (player2Position == 600) //in jail
            {
                player2GamePiece.Location = new Point(93, 574);

                MessageBox.Show("Welcome to Jail! Don't drop the soap! Roll a 6, 10 or 12 to leave!");

                player2InJail = true;
            }

        }   //player 2 move function with location

        void player3Move()
        {
            player3Position += totalvalue;

            if (player3Position >= 40)
            {
                player3Position = player3Position - 40;
            }

            if (player3Position == 100)
            {
                player3GamePiece.Location = new Point(797, 125);
            }

            if (player3Position == 0) //go
            {
                player3GamePiece.Location = new Point(705, 617);
            }

            if (player3Position == 1)
            {
                player3GamePiece.Location = new Point(628, 622);

                if (oldKentRoad == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy old kent road?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        oldKentRoad = 3;
                        player3Cash = player3Cash - 60;
                        Player3MoneyValue.Text = player3Cash.ToString();
                        oldKentRoadOwnedP3.Visible = true;
                    }
                }

                if (oldKentRoad == 1) // if old kent road is owned by p1
                {
                    MessageBox.Show("This square is owned by Player 1! Pay £60 to Player 1!");

                    player3Cash = player3Cash - 60;
                    Player3MoneyValue.Text = player3Cash.ToString();

                    player1Cash = player1Cash + 60;
                    Player1MoneyValue.Text = player1Cash.ToString();
                }

                if (oldKentRoad == 2)
                {
                    MessageBox.Show("This square is owned by Player 2! Pay £60 to Player 2!");
                    
                    player3Cash = player3Cash - 60;
                    Player3MoneyValue.Text = player3Cash.ToString();

                    player2Cash = player2Cash + 60;
                    Player2MoneyValue.Text = player2Cash.ToString();
                }

                if (oldKentRoad == 3)
                {
                    //nothing
                }

                if (oldKentRoad == 4)
                {
                    MessageBox.Show("This square is owned by player 4! Pay £60 to Player 4!");

                    player3Cash = player3Cash - 60;
                    Player3MoneyValue.Text = player3Cash.ToString();

                    player4Cash = player4Cash + 60;
                    Player4MoneyValue.Text = player4Cash.ToString();

                }
            }

            if (player3Position == 2) //com chest
            {
                player3GamePiece.Location = new Point(567, 623);
                communityChestP3();
            }

            if (player3Position == 3) //whitechapel
            {
                player3GamePiece.Location = new Point(503, 623);

                if (whitehapelRoad == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Whitechapel Road?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        whitehapelRoad = 3;
                        player3Cash = player3Cash - 60;
                        Player3MoneyValue.Text = player3Cash.ToString();
                        whitechapelRoadOwnedP3.Visible = true;
                    }
                }

                if (whitehapelRoad == 1) // if whitehapel road is owned by p1
                {
                    MessageBox.Show("This square is owned by Player 1! Pay £60 to Player 1!");

                    player3Cash = player3Cash - 60;
                    Player3MoneyValue.Text = player3Cash.ToString();

                    player1Cash = player1Cash + 60;
                    Player1MoneyValue.Text = player1Cash.ToString();
                }

                if (whitehapelRoad == 2)
                {
                    MessageBox.Show("This square is owned by Player 2! Pay £60 to Player 2!");
                    player3Cash = player3Cash - 60;
                    Player3MoneyValue.Text = player3Cash.ToString();

                    player2Cash = player2Cash + 60;
                    Player2MoneyValue.Text = player2Cash.ToString();
                }

                if (whitehapelRoad == 3)
                {
                    //nothing
                }

                if (whitehapelRoad == 4)
                {
                    MessageBox.Show("This square is owned by player 4! Pay £60 to Player 4!");

                    player3Cash = player3Cash - 60;
                    Player3MoneyValue.Text = player3Cash.ToString();

                    player4Cash = player4Cash + 60;
                    Player4MoneyValue.Text = player4Cash.ToString();
                }
            }

            if (player3Position == 4) //income tax
            {
                player3GamePiece.Location = new Point(439, 617);
                MessageBox.Show("Income Tax! Pay £200");
                player3Cash = player3Cash - 200;
                Player3MoneyValue.Text = player3Cash.ToString();
            }

            if (player3Position == 5) //kk station
            {
                player3GamePiece.Location = new Point(378, 617);

                if (kingsCrossStation == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Kings Cross Station?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        kingsCrossStation = 3;
                        player3Cash = player3Cash - 200;
                        Player3MoneyValue.Text = player3Cash.ToString();
                        kingsCrossOwnedP3.Visible = true;
                    }
                }

                if (kingsCrossStation == 1) // if kk station is owned by p1
                {
                    MessageBox.Show("This square is owned by Player 1! Pay £200 to Player 1!");

                    player3Cash = player3Cash - 200;
                    Player3MoneyValue.Text = player3Cash.ToString();

                    player1Cash = player1Cash + 200;
                    Player1MoneyValue.Text = player1Cash.ToString();
                }

                if (kingsCrossStation == 2)
                {
                    MessageBox.Show("This square is owned by Player 2! Pay £200 to Player 2!");
                    player3Cash = player3Cash - 200;
                    Player3MoneyValue.Text = player3Cash.ToString();

                    player2Cash = player2Cash + 200;
                    Player2MoneyValue.Text = player2Cash.ToString();
                }

                if (kingsCrossStation == 3)
                {
                    //nothing
                }

                if (kingsCrossStation == 4)
                {
                    MessageBox.Show("This square is owned by player 4! Pay £200 to Player 4!");

                    player3Cash = player3Cash - 200;
                    Player3MoneyValue.Text = player3Cash.ToString();

                    player4Cash = player4Cash + 200;
                    Player4MoneyValue.Text = player4Cash.ToString();
                }
            }

            if (player3Position == 6) //angel is
            {
                player3GamePiece.Location = new Point(319, 619);

                if (theAngelIslington == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy The Angel Islington?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        theAngelIslington = 3;
                        player3Cash = player3Cash - 100;
                        Player3MoneyValue.Text = player3Cash.ToString();
                        angelIslingtonOwnedP3.Visible = true;
                    }
                }

                if (theAngelIslington == 1) // if angel is owned by p1
                {
                    MessageBox.Show("This square is owned by Player 1! Pay £100 to Player 1!");

                    player3Cash = player3Cash - 100;
                    Player3MoneyValue.Text = player3Cash.ToString();

                    player1Cash = player1Cash + 100;
                    Player1MoneyValue.Text = player1Cash.ToString();
                }

                if (theAngelIslington == 2)
                {
                    MessageBox.Show("This square is owned by Player 2! Pay £100 to Player 2!");
                    player3Cash = player3Cash - 100;
                    Player3MoneyValue.Text = player3Cash.ToString();

                    player2Cash = player2Cash + 100;
                    Player2MoneyValue.Text = player2Cash.ToString();
                }

                if (theAngelIslington == 3)
                {
                    //nothing
                }

                if (theAngelIslington == 4)
                {
                    MessageBox.Show("This square is owned by player 4! Pay £100 to Player 4!");

                    player3Cash = player3Cash - 100;
                    Player3MoneyValue.Text = player3Cash.ToString();

                    player4Cash = player4Cash + 100;
                    Player4MoneyValue.Text = player4Cash.ToString();
                }
            }

            if (player3Position == 7) //chance
            {
                player3GamePiece.Location = new Point(255, 620);
                chancePlayer3();
            }

            if (player3Position == 8) //euston
            {
                player3GamePiece.Location = new Point(193, 621);

                if (eustonRoad == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Euston Road?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        eustonRoad = 3;
                        player3Cash = player3Cash - 100;
                        Player3MoneyValue.Text = player3Cash.ToString();
                        eustonRoadOwnedP3.Visible = true;
                    }
                }

                if (eustonRoad == 1) // if Euston is owned by p1
                {
                    MessageBox.Show("This square is owned by Player 1! Pay £100 to Player 1!");

                    player3Cash = player3Cash - 100;
                    Player3MoneyValue.Text = player3Cash.ToString();

                    player1Cash = player1Cash + 100;
                    Player1MoneyValue.Text = player1Cash.ToString();
                }

                if (eustonRoad == 2)
                {
                    MessageBox.Show("This square is owned by Player 2! Pay £100 to Player 2!");
                    player3Cash = player3Cash - 100;
                    Player3MoneyValue.Text = player3Cash.ToString();

                    player2Cash = player2Cash + 100;
                    Player2MoneyValue.Text = player2Cash.ToString();
                }

                if (eustonRoad == 3)
                {
                    //nothing
                }

                if (eustonRoad == 4)
                {
                    MessageBox.Show("This square is owned by player 4! Pay £100 to Player 4!");

                    player3Cash = player3Cash - 100;
                    Player3MoneyValue.Text = player3Cash.ToString();

                    player4Cash = player4Cash + 100;
                    Player4MoneyValue.Text = player4Cash.ToString();
                }
            }

            if (player3Position == 9) //pentonvile
            {
                player3GamePiece.Location = new Point(131, 621);

                if (pentonvilleRoad == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Pentonville Road?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        pentonvilleRoad = 3;
                        player3Cash = player3Cash - 120;
                        Player3MoneyValue.Text = player3Cash.ToString();
                        pentonvilleRoadOwnedP3.Visible = true;
                    }
                }

                if (pentonvilleRoad == 1) // if penton is owned by p1
                {
                    MessageBox.Show("This square is owned by Player 1! Pay £120 to Player 1!");

                    player3Cash = player3Cash - 120;
                    Player3MoneyValue.Text = player3Cash.ToString();

                    player1Cash = player1Cash + 120;
                    Player1MoneyValue.Text = player1Cash.ToString();
                }

                if (pentonvilleRoad == 2)
                {
                    MessageBox.Show("This square is owned by Player 2! Pay £120 to Player 2!");
                    player3Cash = player3Cash - 120;
                    Player3MoneyValue.Text = player3Cash.ToString();

                    player2Cash = player2Cash + 120;
                    Player2MoneyValue.Text = player2Cash.ToString();
                }

                if (pentonvilleRoad == 3)
                {
                    //nothing
                }

                if (pentonvilleRoad == 4)
                {
                    MessageBox.Show("This square is owned by player 4! Pay £120 to Player 4!");

                    player3Cash = player3Cash - 120;
                    Player3MoneyValue.Text = player3Cash.ToString();

                    player4Cash = player4Cash + 120;
                    Player4MoneyValue.Text = player4Cash.ToString();
                }
            }

            if (player3Position == 10) //jv jail
            {
                player3GamePiece.Location = new Point(50, 631);
            }

            if (player3Position == 11) //pall mall
            {
                player3GamePiece.Location = new Point(39, 543);

                if (pallMall == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Pall Mall?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        pallMall = 3;
                        player3Cash = player3Cash - 140;
                        Player3MoneyValue.Text = player3Cash.ToString();
                        pallMallOwnedP3.Visible = true;
                    }
                }

                if (pallMall == 1) // if pallmall is owned by p1
                {
                    MessageBox.Show("This square is owned by Player 1! Pay £140 to Player 1!");

                    player3Cash = player3Cash - 140;
                    Player3MoneyValue.Text = player3Cash.ToString();

                    player1Cash = player1Cash + 140;
                    Player1MoneyValue.Text = player1Cash.ToString();
                }

                if (pallMall == 2)
                {
                    MessageBox.Show("This square is owned by Player 2! Pay £140 to Player 2!");

                    player3Cash = player3Cash - 140;
                    Player3MoneyValue.Text = player3Cash.ToString();

                    player2Cash = player2Cash + 140;
                    Player2MoneyValue.Text = player2Cash.ToString();
                }

                if (pallMall == 3)
                {
                    //nothing
                }

                if (pallMall == 4)
                {
                    MessageBox.Show("This square is owned by player 4! Pay £140 to Player 4!");

                    player3Cash = player3Cash - 140;
                    Player3MoneyValue.Text = player3Cash.ToString();

                    player4Cash = player4Cash + 140;
                    Player4MoneyValue.Text = player4Cash.ToString();
                }
            }

            if (player3Position == 12) //elec
            {
                player3GamePiece.Location = new Point(40, 490);

                if (electricCompany == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy The Electric Company?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        electricCompany = 3;
                        player3Cash = player3Cash - 150;
                        Player3MoneyValue.Text = player3Cash.ToString();
                        electricCompanyOwnedP3.Visible = true;
                    }
                }

                if (electricCompany == 1) // if elec is owned by p1
                {
                    MessageBox.Show("This square is owned by Player 1! Pay £150 to Player 1!");

                    player3Cash = player3Cash - 150;
                    Player3MoneyValue.Text = player3Cash.ToString();

                    player1Cash = player1Cash + 150;
                    Player1MoneyValue.Text = player1Cash.ToString();
                }

                if (electricCompany == 2)
                {
                    MessageBox.Show("This square is owned by Player 2! Pay £150 to Player 2!");

                    player3Cash = player3Cash - 150;
                    Player3MoneyValue.Text = player3Cash.ToString();

                    player2Cash = player2Cash + 150;
                    Player2MoneyValue.Text = player2Cash.ToString();
                }

                if (electricCompany == 3)
                {
                    //nothing
                }

                if (electricCompany == 4)
                {
                    MessageBox.Show("This square is owned by player 4! Pay £150 to Player 4!");

                    player3Cash = player3Cash - 150;
                    Player3MoneyValue.Text = player3Cash.ToString();

                    player4Cash = player4Cash + 150;
                    Player4MoneyValue.Text = player4Cash.ToString();
                }
            }

            if (player3Position == 13) //whiteh
            {
                player3GamePiece.Location = new Point(35, 435);

                if (whiteHall == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Whitehall?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        whiteHall = 3;
                        player3Cash = player3Cash - 140;
                        Player3MoneyValue.Text = player3Cash.ToString();
                        whitehallOwnedP3.Visible = true;
                    }
                }

                if (whiteHall == 1) // if Whitehall is owned by p1
                {
                    MessageBox.Show("This square is owned by Player 1! Pay £140 to Player 1!");

                    player3Cash = player3Cash - 140;
                    Player3MoneyValue.Text = player3Cash.ToString();

                    player1Cash = player1Cash + 140;
                    Player1MoneyValue.Text = player1Cash.ToString();
                }

                if (whiteHall == 2)
                {
                    MessageBox.Show("This square is owned by Player 2! Pay £140 to Player 2!");

                    player3Cash = player3Cash - 140;
                    Player3MoneyValue.Text = player3Cash.ToString();

                    player2Cash = player2Cash + 140;
                    Player2MoneyValue.Text = player2Cash.ToString();
                }

                if (whiteHall == 3)
                {
                    //nothing
                }

                if (whiteHall == 4)
                {
                    MessageBox.Show("This square is owned by player 4! Pay £140 to Player 4!");

                    player3Cash = player3Cash - 140;
                    Player3MoneyValue.Text = player3Cash.ToString();

                    player4Cash = player4Cash + 140;
                    Player4MoneyValue.Text = player4Cash.ToString();
                }
            }

            if (player3Position == 14) //northumb
            {
                player3GamePiece.Location = new Point(37, 383);

                if (northumberlandAvenue == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Northumberland Avenue?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        northumberlandAvenue = 3;
                        player3Cash = player3Cash - 160;
                        Player3MoneyValue.Text = player3Cash.ToString();
                        northumberlandOwnedP3.Visible = true;
                    }
                }

                if (northumberlandAvenue == 1) // if pallmall is owned by p1
                {
                    MessageBox.Show("This square is owned by Player 1! Pay £160 to Player 1!");

                    player3Cash = player3Cash - 160;
                    Player3MoneyValue.Text = player3Cash.ToString();

                    player1Cash = player1Cash + 160;
                    Player1MoneyValue.Text = player1Cash.ToString();
                }

                if (northumberlandAvenue == 2)
                {
                    MessageBox.Show("This square is owned by Player 2! Pay £160 to Player 2!");

                    player3Cash = player3Cash - 160;
                    Player3MoneyValue.Text = player3Cash.ToString();

                    player2Cash = player2Cash + 160;
                    Player2MoneyValue.Text = player2Cash.ToString();
                }

                if (northumberlandAvenue == 3)
                {
                    //nothing
                }

                if (northumberlandAvenue == 4)
                {
                    MessageBox.Show("This square is owned by player 4! Pay £160 to Player 4!");

                    player3Cash = player3Cash - 160;
                    Player3MoneyValue.Text = player3Cash.ToString();

                    player4Cash = player4Cash + 160;
                    Player4MoneyValue.Text = player4Cash.ToString();
                }
            }

            if (player3Position == 15) //merylebo stat
            {
                player3GamePiece.Location = new Point(39, 331);

                if (maryleboneStation == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Marylebone Station?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        maryleboneStation = 3;
                        player3Cash = player3Cash - 200;
                        Player3MoneyValue.Text = player3Cash.ToString();
                        maryleboneStationOwnedP3.Visible = true;
                    }
                }

                if (maryleboneStation == 1) // if maryle station is owned by p1
                {
                    MessageBox.Show("This square is owned by Player 1! Pay £200 to Player 1!");

                    player3Cash = player3Cash - 200;
                    Player3MoneyValue.Text = player3Cash.ToString();

                    player1Cash = player1Cash + 200;
                    Player1MoneyValue.Text = player1Cash.ToString();
                }

                if (maryleboneStation == 2)
                {
                    MessageBox.Show("This square is owned by Player 2! Pay £200 to Player 2!");
                    player3Cash = player3Cash - 200;
                    Player3MoneyValue.Text = player3Cash.ToString();

                    player2Cash = player2Cash + 200;
                    Player2MoneyValue.Text = player2Cash.ToString();
                }

                if (maryleboneStation == 3)
                {
                    //nothing
                }

                if (maryleboneStation == 4)
                {
                    MessageBox.Show("This square is owned by player 4! Pay £200 to Player 4!");

                    player3Cash = player3Cash - 200;
                    Player3MoneyValue.Text = player3Cash.ToString();

                    player4Cash = player4Cash + 200;
                    Player4MoneyValue.Text = player4Cash.ToString();
                }
            }

            if (player3Position == 16) //bow st
            {
                player3GamePiece.Location = new Point(39, 278);

                if (bowStreet == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Bow Street?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        bowStreet = 3;
                        player3Cash = player3Cash - 180;
                        Player3MoneyValue.Text = player3Cash.ToString();
                        bowStreetOwnedP3.Visible = true;
                    }
                }

                if (bowStreet == 1) // if bs is owned by p1
                {
                    MessageBox.Show("This square is owned by Player 1! Pay £180 to Player 1!");

                    player3Cash = player3Cash - 180;
                    Player3MoneyValue.Text = player3Cash.ToString();

                    player1Cash = player1Cash + 180;
                    Player1MoneyValue.Text = player1Cash.ToString();
                }

                if (bowStreet == 2)
                {
                    MessageBox.Show("This square is owned by Player 2! Pay £180 to Player 2!");
                    player3Cash = player3Cash - 180;
                    Player3MoneyValue.Text = player3Cash.ToString();

                    player2Cash = player2Cash + 180;
                    Player2MoneyValue.Text = player2Cash.ToString();
                }

                if (bowStreet == 3)
                {
                    //nothing
                }

                if (bowStreet == 4)
                {
                    MessageBox.Show("This square is owned by player 4! Pay £180 to Player 4!");

                    player3Cash = player3Cash - 180;
                    Player3MoneyValue.Text = player3Cash.ToString();

                    player4Cash = player4Cash + 180;
                    Player4MoneyValue.Text = player4Cash.ToString();
                }
            }

            if (player3Position == 17) //com ch
            {
                player3GamePiece.Location = new Point(39, 224);
                communityChestP3();
            }

            if (player3Position == 18) //maryleb
            {
                player3GamePiece.Location = new Point(35, 172);

                if (marlboroughStreet == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Marlborough Street?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        marlboroughStreet = 3;
                        player3Cash = player3Cash - 180;
                        Player3MoneyValue.Text = player3Cash.ToString();
                        marlboroughStreetOwnedP3.Visible = true;
                    }
                }

                if (marlboroughStreet == 1) // if bs is owned by p1
                {
                    MessageBox.Show("This square is owned by Player 1! Pay £180 to Player 1!");

                    player3Cash = player3Cash - 180;
                    Player3MoneyValue.Text = player3Cash.ToString();

                    player1Cash = player1Cash + 180;
                    Player1MoneyValue.Text = player1Cash.ToString();
                }

                if (marlboroughStreet == 2)
                {
                    MessageBox.Show("This square is owned by Player 2! Pay £180 to Player 2!");
                    player3Cash = player3Cash - 180;
                    Player3MoneyValue.Text = player3Cash.ToString();

                    player2Cash = player2Cash + 180;
                    Player2MoneyValue.Text = player2Cash.ToString();
                }

                if (marlboroughStreet == 3)
                {
                    //nothing
                }

                if (marlboroughStreet == 4)
                {
                    MessageBox.Show("This square is owned by player 4! Pay £180 to Player 4!");

                    player3Cash = player3Cash - 180;
                    Player3MoneyValue.Text = player3Cash.ToString();

                    player4Cash = player4Cash + 180;
                    Player4MoneyValue.Text = player4Cash.ToString();
                }
            }

            if (player3Position == 19) //vine
            {
                player3GamePiece.Location = new Point(37, 117);

                if (vineStreet == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Vine Street?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        vineStreet = 3;
                        player3Cash = player3Cash - 200;
                        Player3MoneyValue.Text = player3Cash.ToString();
                        vineStreetOwnedP3.Visible = true;
                    }
                }

                if (vineStreet == 1) // if bs is owned by p1
                {
                    MessageBox.Show("This square is owned by Player 1! Pay £200 to Player 1!");

                    player3Cash = player3Cash - 200;
                    Player3MoneyValue.Text = player3Cash.ToString();

                    player1Cash = player1Cash + 200;
                    Player1MoneyValue.Text = player1Cash.ToString();
                }

                if (vineStreet == 2)
                {
                    MessageBox.Show("This square is owned by Player 2! Pay £200 to Player 2!");
                    player3Cash = player3Cash - 200;
                    Player3MoneyValue.Text = player3Cash.ToString();

                    player2Cash = player2Cash + 200;
                    Player2MoneyValue.Text = player2Cash.ToString();
                }

                if (vineStreet == 3)
                {
                    //nothing
                }

                if (vineStreet == 4)
                {
                    MessageBox.Show("This square is owned by player 4! Pay £200 to Player 4!");

                    player3Cash = player3Cash - 200;
                    Player3MoneyValue.Text = player3Cash.ToString();

                    player4Cash = player4Cash + 200;
                    Player4MoneyValue.Text = player4Cash.ToString();
                }
            }

            if (player3Position == 20) //free parking
            {
                player3GamePiece.Location = new Point(31, 60);
            }

            if (player3Position == 21) //strand
            {
                player3GamePiece.Location = new Point(131,34);

                if (strand == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Strand?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        strand = 3;
                        player3Cash = player3Cash - 220;
                        Player3MoneyValue.Text = player3Cash.ToString();
                        strandOwnedP3.Visible = true;
                    }
                }

                if (strand == 1) 
                {
                    MessageBox.Show("This square is owned by Player 1! Pay £220 to Player 1!");

                    player3Cash = player3Cash - 220;
                    Player3MoneyValue.Text = player3Cash.ToString();

                    player1Cash = player1Cash + 220;
                    Player1MoneyValue.Text = player1Cash.ToString();
                }

                if (strand == 2)
                {
                    MessageBox.Show("This square is owned by Player 2! Pay £220 to Player 2!");
                    player3Cash = player3Cash - 220;
                    Player3MoneyValue.Text = player3Cash.ToString();

                    player2Cash = player2Cash + 220;
                    Player2MoneyValue.Text = player2Cash.ToString();
                }

                if (strand == 3)
                {
                    //nothing
                }

                if (strand == 4)
                {
                    MessageBox.Show("This square is owned by player 4! Pay £220 to Player 4!");

                    player3Cash = player3Cash - 220;
                    Player3MoneyValue.Text = player3Cash.ToString();

                    player4Cash = player4Cash + 220;
                    Player4MoneyValue.Text = player4Cash.ToString();
                }
            }

            if (player3Position == 22) //chance
            {
                player3GamePiece.Location = new Point(191, 34);
                chancePlayer3();
            }

            if (player3Position == 23) //fleet
            {
                player3GamePiece.Location = new Point(257, 34);

                if (fleetStreet == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Fleet Steet?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        fleetStreet = 3;
                        player3Cash = player3Cash - 220;
                        Player3MoneyValue.Text = player3Cash.ToString();
                        FleetStreetOwnedP3.Visible = true;
                    }
                }

                if (fleetStreet == 1)
                {
                    MessageBox.Show("This square is owned by Player 1! Pay £220 to Player 1!");

                    player3Cash = player3Cash - 220;
                    Player3MoneyValue.Text = player3Cash.ToString();

                    player1Cash = player1Cash + 220;
                    Player1MoneyValue.Text = player1Cash.ToString();
                }

                if (fleetStreet == 2)
                {
                    MessageBox.Show("This square is owned by Player 2! Pay £220 to Player 2!");
                    player3Cash = player3Cash - 220;
                    Player3MoneyValue.Text = player3Cash.ToString();

                    player2Cash = player2Cash + 220;
                    Player2MoneyValue.Text = player2Cash.ToString();
                }

                if (fleetStreet == 3)
                {
                    //nothing
                }

                if (fleetStreet == 4)
                {
                    MessageBox.Show("This square is owned by player 4! Pay £220 to Player 4!");

                    player3Cash = player3Cash - 220;
                    Player3MoneyValue.Text = player3Cash.ToString();

                    player4Cash = player4Cash + 220;
                    Player4MoneyValue.Text = player4Cash.ToString();
                }
            }

            if (player3Position == 24) //traf
            {
                player3GamePiece.Location = new Point(316, 34);

                if (trafalgerSquare == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Trafalgar Square?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        trafalgerSquare = 3;
                        player3Cash = player3Cash - 240;
                        Player3MoneyValue.Text = player3Cash.ToString();
                        trafalgarSquareOwnedP3.Visible = true;
                    }
                }

                if (trafalgerSquare == 1)
                {
                    MessageBox.Show("This square is owned by Player 1! Pay £240 to Player 1!");

                    player3Cash = player3Cash - 240;
                    Player3MoneyValue.Text = player3Cash.ToString();

                    player1Cash = player1Cash + 240;
                    Player1MoneyValue.Text = player1Cash.ToString();
                }

                if (trafalgerSquare == 2)
                {
                    MessageBox.Show("This square is owned by Player 2! Pay £240 to Player 2!");
                    player3Cash = player3Cash - 240;
                    Player3MoneyValue.Text = player3Cash.ToString();

                    player2Cash = player2Cash + 240;
                    Player2MoneyValue.Text = player2Cash.ToString();
                }

                if (trafalgerSquare == 3)
                {
                    //nothing
                }

                if (trafalgerSquare == 4)
                {
                    MessageBox.Show("This square is owned by player 4! Pay £240 to Player 4!");

                    player3Cash = player3Cash - 240;
                    Player3MoneyValue.Text = player3Cash.ToString();

                    player4Cash = player4Cash + 240;
                    Player4MoneyValue.Text = player4Cash.ToString();
                }
            }

            if (player3Position == 25) //fench
            {
                player3GamePiece.Location = new Point(379, 42);

                if (fenchurchStreetStation == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Fenchurch Street Station?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        fenchurchStreetStation = 3;
                        player3Cash = player3Cash - 200;
                        Player3MoneyValue.Text = player3Cash.ToString();
                        fenchurchStationOwnedP3.Visible = true;
                    }
                }

                if (fenchurchStreetStation == 1) 
                {
                    MessageBox.Show("This square is owned by Player 1! Pay £200 to Player 1!");

                    player3Cash = player3Cash - 200;
                    Player3MoneyValue.Text = player3Cash.ToString();

                    player1Cash = player1Cash + 200;
                    Player1MoneyValue.Text = player1Cash.ToString();
                }

                if (fenchurchStreetStation == 2)
                {
                    MessageBox.Show("This square is owned by Player 2! Pay £200 to Player 2!");
                    player3Cash = player3Cash - 200;
                    Player3MoneyValue.Text = player3Cash.ToString();

                    player2Cash = player2Cash + 200;
                    Player2MoneyValue.Text = player2Cash.ToString();
                }

                if (fenchurchStreetStation == 3)
                {
                    //nothing
                }

                if (fenchurchStreetStation == 4)
                {
                    MessageBox.Show("This square is owned by player 4! Pay £200 to Player 4!");

                    player3Cash = player3Cash - 200;
                    Player3MoneyValue.Text = player3Cash.ToString();

                    player4Cash = player4Cash + 200;
                    Player4MoneyValue.Text = player4Cash.ToString();
                }
            }

            if (player3Position == 26) //leichester
            {
                player3GamePiece.Location = new Point(442, 34);

                if (leicesterSquare == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Leicester Square?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        leicesterSquare = 3;
                        player3Cash = player3Cash - 260;
                        Player3MoneyValue.Text = player3Cash.ToString();
                        leicesterSquareOwnedP3.Visible = true;
                    }
                }

                if (leicesterSquare == 1)
                {
                    MessageBox.Show("This square is owned by Player 1! Pay £260 to Player 1!");

                    player3Cash = player3Cash - 260;
                    Player3MoneyValue.Text = player3Cash.ToString();

                    player1Cash = player1Cash + 260;
                    Player1MoneyValue.Text = player1Cash.ToString();
                }

                if (leicesterSquare == 2)
                {
                    MessageBox.Show("This square is owned by Player 2! Pay £260 to Player 2!");
                    player3Cash = player3Cash - 260;
                    Player3MoneyValue.Text = player3Cash.ToString();

                    player2Cash = player2Cash + 260;
                    Player2MoneyValue.Text = player2Cash.ToString();
                }

                if (leicesterSquare == 3)
                {
                    //nothing
                }

                if (leicesterSquare == 4)
                {
                    MessageBox.Show("This square is owned by player 4! Pay £260 to Player 4!");

                    player3Cash = player3Cash - 260;
                    Player3MoneyValue.Text = player3Cash.ToString();

                    player4Cash = player4Cash + 260;
                    Player4MoneyValue.Text = player4Cash.ToString();
                }
            }

            if (player3Position == 27) //cov st
            {
                player3GamePiece.Location = new Point(503, 34);

                if (coventryStreet == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Coventry Street?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        coventryStreet = 3;
                        player3Cash = player3Cash - 260;
                        Player3MoneyValue.Text = player3Cash.ToString();
                        coventryStreetOwnedP3.Visible = true;
                    }
                }

                if (coventryStreet == 1)
                {
                    MessageBox.Show("This square is owned by Player 1! Pay £260 to Player 1!");

                    player3Cash = player3Cash - 260;
                    Player3MoneyValue.Text = player3Cash.ToString();

                    player1Cash = player1Cash + 260;
                    Player1MoneyValue.Text = player1Cash.ToString();
                }

                if (coventryStreet == 2)
                {
                    MessageBox.Show("This square is owned by Player 2! Pay £260 to Player 2!");
                    player3Cash = player3Cash - 260;
                    Player3MoneyValue.Text = player3Cash.ToString();

                    player2Cash = player2Cash + 260;
                    Player2MoneyValue.Text = player2Cash.ToString();
                }

                if (coventryStreet == 3)
                {
                    //nothing
                }

                if (coventryStreet == 4)
                {
                    MessageBox.Show("This square is owned by player 4! Pay £260 to Player 4!");

                    player3Cash = player3Cash - 260;
                    Player3MoneyValue.Text = player3Cash.ToString();

                    player4Cash = player4Cash + 260;
                    Player4MoneyValue.Text = player4Cash.ToString();
                }
            }

            if (player3Position == 28) //ww
            {
                player3GamePiece.Location = new Point(567, 34);
                if (waterWorks == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy The Water Works?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        waterWorks = 3;
                        player3Cash = player3Cash - 150;
                        Player3MoneyValue.Text = player3Cash.ToString();
                        waterworksOwnedP3.Visible = true;
                    }
                }

                if (waterWorks == 1) // if elec is owned by p1
                {
                    MessageBox.Show("This square is owned by Player 1! Pay £150 to Player 1!");

                    player3Cash = player3Cash - 150;
                    Player3MoneyValue.Text = player3Cash.ToString();

                    player1Cash = player1Cash + 150;
                    Player1MoneyValue.Text = player1Cash.ToString();
                }

                if (waterWorks == 2)
                {
                    MessageBox.Show("This square is owned by Player 2! Pay £150 to Player 2!");

                    player3Cash = player3Cash - 150;
                    Player3MoneyValue.Text = player3Cash.ToString();

                    player2Cash = player2Cash + 150;
                    Player2MoneyValue.Text = player2Cash.ToString();
                }

                if (waterWorks == 3)
                {
                    //nothing
                }

                if (waterWorks == 4)
                {
                    MessageBox.Show("This square is owned by player 4! Pay £150 to Player 4!");

                    player3Cash = player3Cash - 150;
                    Player3MoneyValue.Text = player3Cash.ToString();

                    player4Cash = player4Cash + 150;
                    Player4MoneyValue.Text = player4Cash.ToString();
                }
            }

            if (player3Position == 29) //picca
            {
                player3GamePiece.Location = new Point(629, 34);

                if (piccadilly == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Piccadilly?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        piccadilly = 3;
                        player3Cash = player3Cash - 280;
                        Player3MoneyValue.Text = player3Cash.ToString();
                        piccadillyOwnedP3.Visible = true;
                    }
                }

                if (piccadilly == 1)
                {
                    MessageBox.Show("This square is owned by Player 1! Pay £280 to Player 1!");

                    player3Cash = player3Cash - 280;
                    Player3MoneyValue.Text = player3Cash.ToString();

                    player1Cash = player1Cash + 280;
                    Player1MoneyValue.Text = player1Cash.ToString();
                }

                if (piccadilly == 2)
                {
                    MessageBox.Show("This square is owned by Player 2! Pay £280 to Player 2!");
                    player3Cash = player3Cash - 280;
                    Player3MoneyValue.Text = player3Cash.ToString();

                    player2Cash = player2Cash + 280;
                    Player2MoneyValue.Text = player2Cash.ToString();
                }

                if (piccadilly == 3)
                {
                    //nothing
                }

                if (piccadilly == 4)
                {
                    MessageBox.Show("This square is owned by player 4! Pay £280 to Player 4!");

                    player3Cash = player3Cash - 280;
                    Player3MoneyValue.Text = player3Cash.ToString();

                    player4Cash = player4Cash + 280;
                    Player4MoneyValue.Text = player4Cash.ToString();
                }
            }

            if (player3Position == 30) //go jail        
            {
                player3GamePiece.Location = new Point(686, 60);
                MessageBox.Show("Go to Jail! Do not pas GO!");
                player3GamePiece.Location = new Point(61, 604);
                player3Position = 600;
            }

            if (player3Position == 31) //regent
            {
                player3GamePiece.Location = new Point(715, 115);

                if (regentStreet == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Regent Street?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        regentStreet = 3;
                        player3Cash = player3Cash - 300;
                        Player3MoneyValue.Text = player3Cash.ToString();
                        regentStreetOwnedP3.Visible = true;
                    }
                }

                if (regentStreet == 1)
                {
                    MessageBox.Show("This square is owned by Player 1! Pay £300 to Player 1!");

                    player3Cash = player3Cash - 300;
                    Player3MoneyValue.Text = player3Cash.ToString();

                    player1Cash = player1Cash + 300;
                    Player1MoneyValue.Text = player1Cash.ToString();
                }

                if (regentStreet == 2)
                {
                    MessageBox.Show("This square is owned by Player 2! Pay £300 to Player 2!");
                    player3Cash = player3Cash - 300;
                    Player3MoneyValue.Text = player3Cash.ToString();

                    player2Cash = player2Cash + 300;
                    Player2MoneyValue.Text = player2Cash.ToString();
                }

                if (regentStreet == 3)
                {
                    //nothing
                }

                if (regentStreet == 4)
                {
                    MessageBox.Show("This square is owned by player 4! Pay £300 to Player 4!");

                    player3Cash = player3Cash - 300;
                    Player3MoneyValue.Text = player3Cash.ToString();

                    player4Cash = player4Cash + 300;
                    Player4MoneyValue.Text = player4Cash.ToString();
                }
            }

            if (player3Position == 32)//oxford
            {
                player3GamePiece.Location = new Point(717, 172);

                if (oxfordStreet == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Oxford Street?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        oxfordStreet = 3;
                        player3Cash = player3Cash - 300;
                        Player3MoneyValue.Text = player3Cash.ToString();
                        oxfordStreetOwnedP3.Visible = true;
                    }
                }

                if (oxfordStreet == 1)
                {
                    MessageBox.Show("This square is owned by Player 1! Pay £300 to Player 1!");

                    player3Cash = player3Cash - 300;
                    Player3MoneyValue.Text = player3Cash.ToString();

                    player1Cash = player1Cash + 300;
                    Player1MoneyValue.Text = player1Cash.ToString();
                }

                if (oxfordStreet == 2)
                {
                    MessageBox.Show("This square is owned by Player 2! Pay £300 to Player 2!");
                    player3Cash = player3Cash - 300;
                    Player3MoneyValue.Text = player3Cash.ToString();

                    player2Cash = player2Cash + 300;
                    Player2MoneyValue.Text = player2Cash.ToString();
                }

                if (oxfordStreet == 3)
                {
                    //nothing
                }

                if (oxfordStreet == 4)
                {
                    MessageBox.Show("This square is owned by player 4! Pay £300 to Player 4!");

                    player3Cash = player3Cash - 300;
                    Player3MoneyValue.Text = player3Cash.ToString();

                    player4Cash = player4Cash + 300;
                    Player4MoneyValue.Text = player4Cash.ToString();
                }
            }

            if (player3Position == 33) //com ch
            {
                player3GamePiece.Location = new Point(715, 224);
                communityChestP3();
            }

            if (player3Position == 34)//bond
            {
                player3GamePiece.Location = new Point(717, 277);

                if (bondStreet == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Bond Street?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        bondStreet = 3;
                        player3Cash = player3Cash - 320;
                        Player3MoneyValue.Text = player3Cash.ToString();
                        bondStreetOwnedP3.Visible = true;
                    }
                }

                if (bondStreet == 1)
                {
                    MessageBox.Show("This square is owned by Player 1! Pay £320 to Player 1!");

                    player3Cash = player3Cash - 320;
                    Player3MoneyValue.Text = player3Cash.ToString();

                    player1Cash = player1Cash + 320;
                    Player1MoneyValue.Text = player1Cash.ToString();
                }

                if (bondStreet == 2)
                {
                    MessageBox.Show("This square is owned by Player 2! Pay £320 to Player 2!");
                    player3Cash = player3Cash - 320;
                    Player3MoneyValue.Text = player3Cash.ToString();

                    player2Cash = player2Cash + 320;
                    Player2MoneyValue.Text = player2Cash.ToString();
                }

                if (bondStreet == 3)
                {
                    //nothing
                }

                if (bondStreet == 4)
                {
                    MessageBox.Show("This square is owned by player 4! Pay £320 to Player 4!");

                    player3Cash = player3Cash - 320;
                    Player3MoneyValue.Text = player3Cash.ToString();

                    player4Cash = player4Cash + 320;
                    Player4MoneyValue.Text = player4Cash.ToString();
                }
            }

            if (player3Position == 35)//liv st
            {
                player3GamePiece.Location = new Point(714, 329);

                if (liverpoolStreetStation == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Liverpool Street Station?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        liverpoolStreetStation = 3;
                        player3Cash = player3Cash - 200;
                        Player3MoneyValue.Text = player3Cash.ToString();
                        livStreetStationOwnedP3.Visible = true;
                    }
                }

                if (liverpoolStreetStation == 1)
                {
                    MessageBox.Show("This square is owned by Player 1! Pay £200 to Player 1!");

                    player3Cash = player3Cash - 200;
                    Player3MoneyValue.Text = player3Cash.ToString();

                    player1Cash = player1Cash + 200;
                    Player1MoneyValue.Text = player1Cash.ToString();
                }

                if (liverpoolStreetStation == 2)
                {
                    MessageBox.Show("This square is owned by Player 2! Pay £200 to Player 2!");
                    player3Cash = player3Cash - 200;
                    Player3MoneyValue.Text = player3Cash.ToString();

                    player2Cash = player2Cash + 200;
                    Player2MoneyValue.Text = player2Cash.ToString();
                }

                if (liverpoolStreetStation == 3)
                {
                    //nothing
                }

                if (liverpoolStreetStation == 4)
                {
                    MessageBox.Show("This square is owned by player 4! Pay £200 to Player 4!");

                    player3Cash = player3Cash - 200;
                    Player3MoneyValue.Text = player3Cash.ToString();

                    player4Cash = player4Cash + 200;
                    Player4MoneyValue.Text = player4Cash.ToString();
                }
            }

            if (player3Position == 36) //chance
            {
                player3GamePiece.Location = new Point(716, 385);
                chancePlayer3();
            }

            if (player3Position == 37)//park ln
            {
                player3GamePiece.Location = new Point(719, 435);

                if (parkLane == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Park Lane?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        parkLane = 3;
                        player3Cash = player3Cash - 350;
                        Player3MoneyValue.Text = player3Cash.ToString();
                        parkLaneOwnedP3.Visible = true;
                    }
                }

                if (parkLane == 1)
                {
                    MessageBox.Show("This square is owned by Player 1! Pay £350 to Player 1!");

                    player3Cash = player3Cash - 350;
                    Player3MoneyValue.Text = player3Cash.ToString();

                    player1Cash = player1Cash + 350;
                    Player1MoneyValue.Text = player1Cash.ToString();
                }

                if (parkLane == 2)
                {
                    MessageBox.Show("This square is owned by Player 2! Pay £350 to Player 2!");
                    player3Cash = player3Cash - 350;
                    Player3MoneyValue.Text = player3Cash.ToString();

                    player2Cash = player2Cash + 350;
                    Player2MoneyValue.Text = player2Cash.ToString();
                }

                if (parkLane == 3)
                {
                    //nothing
                }

                if (parkLane == 4)
                {
                    MessageBox.Show("This square is owned by player 4! Pay £350 to Player 4!");

                    player3Cash = player3Cash - 350;
                    Player3MoneyValue.Text = player3Cash.ToString();

                    player4Cash = player4Cash + 350;
                    Player4MoneyValue.Text = player4Cash.ToString();
                }
            }

            if (player3Position == 38) //super tax
            {
                player3GamePiece.Location = new Point(713, 490);
                MessageBox.Show("Super Tax! Pay £100!");
                player3Cash = player3Cash - 100;
                Player3MoneyValue.Text = player3Cash.ToString();
            }

            if (player3Position == 39) //mayfair
            {
                player3GamePiece.Location = new Point(719, 544);

                if (mayfair == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Mayfair?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        mayfair = 3;
                        player3Cash = player3Cash - 400;
                        Player3MoneyValue.Text = player3Cash.ToString();
                        mayfairOwnedP3.Visible = true;
                    }
                }

                if (mayfair == 1)
                {
                    MessageBox.Show("This square is owned by Player 1! Pay £400 to Player 1!");

                    player3Cash = player3Cash - 400;
                    Player3MoneyValue.Text = player3Cash.ToString();

                    player1Cash = player1Cash + 400;
                    Player1MoneyValue.Text = player1Cash.ToString();
                }

                if (mayfair == 2)
                {
                    MessageBox.Show("This square is owned by Player 2! Pay £400 to Player 2!");
                    player3Cash = player3Cash - 400;
                    Player3MoneyValue.Text = player3Cash.ToString();

                    player2Cash = player2Cash + 400;
                    Player2MoneyValue.Text = player2Cash.ToString();
                }

                if (mayfair == 3)
                {
                    //nothing
                }

                if (mayfair == 4)
                {
                    MessageBox.Show("This square is owned by player 4! Pay £400 to Player 4!");

                    player3Cash = player3Cash - 400;
                    Player3MoneyValue.Text = player3Cash.ToString();

                    player4Cash = player4Cash + 400;
                    Player4MoneyValue.Text = player4Cash.ToString();
                }
            }

            if (player3Position == 600) //in jail
            {
                player3GamePiece.Location = new Point(61, 604);

                MessageBox.Show("Welcome to Jail! Don't drop the soap! Roll a 6, 10 or 12 to leave!");

                player3InJail = true;
            }
        }   //player 3 move function with location

        void player4Move()
        {
            player4Position += totalvalue;

            if (player4Position >= 40)
            {
                player4Position = player4Position - 40;
            }

            if(player4Position == 100)
            {
                player4GamePiece.Location = new Point(797, 158);
            }

            if (player4Position == 0) //go
            {
                player4GamePiece.Location = new Point (729, 617);
            }

            if (player4Position == 1)
            {
                player4GamePiece.Location = new Point(652, 622);

                if (oldKentRoad == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy old kent road?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        oldKentRoad = 4;
                        player4Cash = player4Cash - 60;
                        Player4MoneyValue.Text = player4Cash.ToString();
                        oldKentRoadOwnedP4.Visible = true;
                    }
                }

                if (oldKentRoad == 1) // if old kent road is owned by p1
                {
                    MessageBox.Show("This square is owned by Player 1! Pay £60 to Player 1!");

                    player4Cash = player4Cash - 60;
                    Player4MoneyValue.Text = player4Cash.ToString();

                    player1Cash = player1Cash + 60;
                    Player1MoneyValue.Text = player1Cash.ToString();
                }

                if (oldKentRoad == 2)
                {
                    MessageBox.Show("This square is owned by Player 2! Pay £60 to Player 2!");

                    player4Cash = player4Cash - 60;
                    Player4MoneyValue.Text = player4Cash.ToString();

                    player2Cash = player2Cash + 60;
                    Player2MoneyValue.Text = player2Cash.ToString();
                }

                if (oldKentRoad == 3)
                {
                    MessageBox.Show("This square is owned by player 3! Pay £60 to Player 3!");

                    player4Cash = player4Cash - 60;
                    Player4MoneyValue.Text = player4Cash.ToString();

                    player3Cash = player3Cash + 60;
                    Player3MoneyValue.Text = player3Cash.ToString();
                }

                if (oldKentRoad == 4)
                {
                    //nothing
                }
            }

            if (player4Position == 2) //com chest
            {
                player4GamePiece.Location = new Point(591, 623);
                communityChestP4();
            }

            if (player4Position == 3) //whitechapel
            {
                player4GamePiece.Location = new Point(527, 623);

                if (whitehapelRoad == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Whitechapel road?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        whitehapelRoad = 4;
                        player4Cash = player4Cash - 60;
                        Player4MoneyValue.Text = player4Cash.ToString();
                        whitechapelRoadOwnedP4.Visible = true;
                    }
                }

                if (whitehapelRoad == 1) // if whitech road is owned by p1
                {
                    MessageBox.Show("This square is owned by Player 1! Pay £60 to Player 1!");

                    player4Cash = player4Cash - 60;
                    Player4MoneyValue.Text = player4Cash.ToString();

                    player1Cash = player1Cash + 60;
                    Player1MoneyValue.Text = player1Cash.ToString();
                }

                if (whitehapelRoad == 2)
                {
                    MessageBox.Show("This square is owned by Player 2! Pay £60 to Player 2!");

                    player4Cash = player4Cash - 60;
                    Player4MoneyValue.Text = player4Cash.ToString();

                    player2Cash = player2Cash + 60;
                    Player2MoneyValue.Text = player2Cash.ToString();
                }

                if (whitehapelRoad == 3)
                {
                    MessageBox.Show("This square is owned by player 3! Pay £60 to Player 3!");

                    player4Cash = player4Cash - 60;
                    Player4MoneyValue.Text = player4Cash.ToString();

                    player3Cash = player3Cash + 60;
                    Player3MoneyValue.Text = player3Cash.ToString();
                }

                if (oldKentRoad == 4)
                {
                    //nothing
                }
            }

            if (player4Position == 4)
            {
                player4GamePiece.Location = new Point(463, 617);
                MessageBox.Show("Income Tax! Pay £200");
                player4Cash = player4Cash - 200;
                Player4MoneyValue.Text = player4Cash.ToString();
            }

            if (player4Position == 5) //kings cross
            {
                player4GamePiece.Location = new Point(402, 617);

                if (kingsCrossStation == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Kings Cross Station?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        kingsCrossStation = 4;
                        player4Cash = player4Cash - 200;
                        Player4MoneyValue.Text = player4Cash.ToString();
                        kingsCrossOwnedP4.Visible = true;
                    }
                }

                if (kingsCrossStation == 1) // if kk stat is owned by p1
                {
                    MessageBox.Show("This square is owned by Player 1! Pay £200 to Player 1!");

                    player4Cash = player4Cash - 200;
                    Player4MoneyValue.Text = player4Cash.ToString();

                    player1Cash = player1Cash + 200;
                    Player1MoneyValue.Text = player1Cash.ToString();
                }

                if (kingsCrossStation == 2)
                {
                    MessageBox.Show("This square is owned by Player 2! Pay £200 to Player 2!");

                    player4Cash = player4Cash - 200;
                    Player4MoneyValue.Text = player4Cash.ToString();

                    player2Cash = player2Cash + 200;
                    Player2MoneyValue.Text = player2Cash.ToString();
                }

                if (kingsCrossStation == 3)
                {
                    MessageBox.Show("This square is owned by player 3! Pay £200 to Player 3!");

                    player4Cash = player4Cash - 200;
                    Player4MoneyValue.Text = player4Cash.ToString();

                    player3Cash = player3Cash + 200;
                    Player3MoneyValue.Text = player3Cash.ToString();
                }

                if (kingsCrossStation == 4)
                {
                    //nothing
                }
            }

            if (player4Position == 6) //angel
            {
                player4GamePiece.Location = new Point(343, 619);

                if (theAngelIslington == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy The Angel Islington?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        theAngelIslington = 4;
                        player4Cash = player4Cash - 100;
                        Player4MoneyValue.Text = player4Cash.ToString();
                        angelIslingtonOwnedP4.Visible = true;
                    }
                }

                if (theAngelIslington == 1) // if angel is owned by p1
                {
                    MessageBox.Show("This square is owned by Player 1! Pay £100 to Player 1!");

                    player4Cash = player4Cash - 100;
                    Player4MoneyValue.Text = player4Cash.ToString();

                    player1Cash = player1Cash + 100;
                    Player1MoneyValue.Text = player1Cash.ToString();
                }

                if (theAngelIslington == 2)
                {
                    MessageBox.Show("This square is owned by Player 2! Pay £100 to Player 2!");

                    player4Cash = player4Cash - 100;
                    Player4MoneyValue.Text = player4Cash.ToString();

                    player2Cash = player2Cash + 100;
                    Player2MoneyValue.Text = player2Cash.ToString();
                }

                if (theAngelIslington == 3)
                {
                    MessageBox.Show("This square is owned by player 3! Pay £100 to Player 3!");

                    player4Cash = player4Cash - 100;
                    Player4MoneyValue.Text = player4Cash.ToString();

                    player3Cash = player3Cash + 100;
                    Player3MoneyValue.Text = player3Cash.ToString();
                }

                if (theAngelIslington == 4)
                {
                    //nothing
                }
            }

            if (player4Position == 7) //chance
            {
                player4GamePiece.Location = new Point(279, 620);
                chancePlayer4();
            }

            if (player4Position == 8) //euston
            {
                player4GamePiece.Location = new Point(217, 621);


                if (eustonRoad == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Euston Road?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        eustonRoad = 4;
                        player4Cash = player4Cash - 100;
                        Player4MoneyValue.Text = player4Cash.ToString();
                        eustonRoadOwnedP4.Visible = true;
                    }
                }

                if (eustonRoad == 1) // if angel is owned by p1
                {
                    MessageBox.Show("This square is owned by Player 1! Pay £100 to Player 1!");

                    player4Cash = player4Cash - 100;
                    Player4MoneyValue.Text = player4Cash.ToString();

                    player1Cash = player1Cash + 100;
                    Player1MoneyValue.Text = player1Cash.ToString();
                }

                if (eustonRoad == 2)
                {
                    MessageBox.Show("This square is owned by Player 2! Pay £100 to Player 2!");

                    player4Cash = player4Cash - 100;
                    Player4MoneyValue.Text = player4Cash.ToString();

                    player2Cash = player2Cash + 100;
                    Player2MoneyValue.Text = player2Cash.ToString();
                }

                if (eustonRoad == 3)
                {
                    MessageBox.Show("This square is owned by player 3! Pay £100 to Player 3!");

                    player4Cash = player4Cash - 100;
                    Player4MoneyValue.Text = player4Cash.ToString();

                    player3Cash = player3Cash + 100;
                    Player3MoneyValue.Text = player3Cash.ToString();
                }

                if (eustonRoad == 4)
                {
                    //nothing
                }
            }

            if (player4Position == 9) //penton
            {
                player4GamePiece.Location = new Point(155, 621);

                if (pentonvilleRoad == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Pentonville Road?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        pentonvilleRoad = 4;
                        player4Cash = player4Cash - 120;
                        Player4MoneyValue.Text = player4Cash.ToString();
                        pentonvilleRoadOwnedP4.Visible = true;
                    }
                }

                if (pentonvilleRoad == 1) // if penton is owned by p1
                {
                    MessageBox.Show("This square is owned by Player 1! Pay £120 to Player 1!");

                    player4Cash = player4Cash - 120;
                    Player4MoneyValue.Text = player4Cash.ToString();

                    player1Cash = player1Cash + 120;
                    Player1MoneyValue.Text = player1Cash.ToString();
                }

                if (pentonvilleRoad == 2)
                {
                    MessageBox.Show("This square is owned by Player 2! Pay £120 to Player 2!");

                    player4Cash = player4Cash - 120;
                    Player4MoneyValue.Text = player4Cash.ToString();

                    player2Cash = player2Cash + 120;
                    Player2MoneyValue.Text = player2Cash.ToString();
                }

                if (pentonvilleRoad == 3)
                {
                    MessageBox.Show("This square is owned by player 3! Pay £120 to Player 3!");

                    player4Cash = player4Cash - 120;
                    Player4MoneyValue.Text = player4Cash.ToString();

                    player3Cash = player3Cash + 120;
                    Player3MoneyValue.Text = player3Cash.ToString();
                }

                if (pentonvilleRoad == 4)
                {
                    //nothing
                }
            }

            if (player4Position == 10) //jv jail
            {
                player4GamePiece.Location = new Point(81, 631);
            }

            if (player4Position == 11) //pall mall
            {
                player4GamePiece.Location = new Point(63, 543);

                if (pallMall == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Pall Mall?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        pallMall = 4;
                        player4Cash = player4Cash - 140;
                        Player4MoneyValue.Text = player4Cash.ToString();
                        pallMallOwnedP4.Visible = true;
                    }
                }

                if (pallMall == 1) // if penton is owned by p1
                {
                    MessageBox.Show("This square is owned by Player 1! Pay £140 to Player 1!");

                    player4Cash = player4Cash - 140;
                    Player4MoneyValue.Text = player4Cash.ToString();

                    player1Cash = player1Cash + 140;
                    Player1MoneyValue.Text = player1Cash.ToString();
                }

                if (pallMall == 2)
                {
                    MessageBox.Show("This square is owned by Player 2! Pay £140 to Player 2!");

                    player4Cash = player4Cash - 140;
                    Player4MoneyValue.Text = player4Cash.ToString();

                    player2Cash = player2Cash + 140;
                    Player2MoneyValue.Text = player2Cash.ToString();
                }

                if (pallMall == 3)
                {
                    MessageBox.Show("This square is owned by player 3! Pay £140 to Player 3!");

                    player4Cash = player4Cash - 140;
                    Player4MoneyValue.Text = player4Cash.ToString();

                    player3Cash = player3Cash + 140;
                    Player3MoneyValue.Text = player3Cash.ToString();
                }

                if (pallMall == 4)
                {
                    //nothing
                }
            }

            if (player4Position == 12) //elec
            {
                player4GamePiece.Location = new Point(64, 490);

                if (electricCompany == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy The Electric Company?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        electricCompany = 4;
                        player4Cash = player4Cash - 150;
                        Player4MoneyValue.Text = player4Cash.ToString();
                        electricCompanyOwnedP4.Visible = true;
                    }
                }

                if (electricCompany == 1) // if penton is owned by p1
                {
                    MessageBox.Show("This square is owned by Player 1! Pay £150 to Player 1!");

                    player4Cash = player4Cash - 150;
                    Player4MoneyValue.Text = player4Cash.ToString();

                    player1Cash = player1Cash + 150;
                    Player1MoneyValue.Text = player1Cash.ToString();
                }

                if (electricCompany == 2)
                {
                    MessageBox.Show("This square is owned by Player 2! Pay £150 to Player 2!");

                    player4Cash = player4Cash - 150;
                    Player4MoneyValue.Text = player4Cash.ToString();

                    player2Cash = player2Cash + 150;
                    Player2MoneyValue.Text = player2Cash.ToString();
                }

                if (electricCompany == 3)
                {
                    MessageBox.Show("This square is owned by player 3! Pay £150 to Player 3!");

                    player4Cash = player4Cash - 150;
                    Player4MoneyValue.Text = player4Cash.ToString();

                    player3Cash = player3Cash + 150;
                    Player3MoneyValue.Text = player3Cash.ToString();
                }

                if (electricCompany == 4)
                {
                    //nothing
                }
            }

            if (player4Position == 13) //whitehall
            {
                player4GamePiece.Location = new Point(59, 435);

                if (whiteHall == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Whitehall?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        whiteHall = 4;
                        player4Cash = player4Cash - 140;
                        Player4MoneyValue.Text = player4Cash.ToString();
                        whitehallOwnedP4.Visible = true;
                    }
                }

                if (whiteHall == 1) // if penton is owned by p1
                {
                    MessageBox.Show("This square is owned by Player 1! Pay £140 to Player 1!");

                    player4Cash = player4Cash - 140;
                    Player4MoneyValue.Text = player4Cash.ToString();

                    player1Cash = player1Cash + 140;
                    Player1MoneyValue.Text = player1Cash.ToString();
                }

                if (whiteHall == 2)
                {
                    MessageBox.Show("This square is owned by Player 2! Pay £140 to Player 2!");

                    player4Cash = player4Cash - 140;
                    Player4MoneyValue.Text = player4Cash.ToString();

                    player2Cash = player2Cash + 140;
                    Player2MoneyValue.Text = player2Cash.ToString();
                }

                if (whiteHall == 3)
                {
                    MessageBox.Show("This square is owned by player 3! Pay £140 to Player 3!");

                    player4Cash = player4Cash - 140;
                    Player4MoneyValue.Text = player4Cash.ToString();

                    player3Cash = player3Cash + 140;
                    Player3MoneyValue.Text = player3Cash.ToString();
                }

                if (whiteHall == 4)
                {
                    //nothing
                }
            }

            if (player4Position == 14) //northumberland
            {
                player4GamePiece.Location = new Point(61, 383);

                if (northumberlandAvenue == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Northumberland Avenue?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        northumberlandAvenue = 4;
                        player4Cash = player4Cash - 160;
                        Player4MoneyValue.Text = player4Cash.ToString();
                        northumberlandOwnedP4.Visible = true;
                    }
                }

                if (northumberlandAvenue == 1) // if penton is owned by p1
                {
                    MessageBox.Show("This square is owned by Player 1! Pay £160 to Player 1!");

                    player4Cash = player4Cash - 160;
                    Player4MoneyValue.Text = player4Cash.ToString();

                    player1Cash = player1Cash + 160;
                    Player1MoneyValue.Text = player1Cash.ToString();
                }

                if (northumberlandAvenue == 2)
                {
                    MessageBox.Show("This square is owned by Player 2! Pay £160 to Player 2!");

                    player4Cash = player4Cash - 160;
                    Player4MoneyValue.Text = player4Cash.ToString();

                    player2Cash = player2Cash + 160;
                    Player2MoneyValue.Text = player2Cash.ToString();
                }

                if (northumberlandAvenue == 3)
                {
                    MessageBox.Show("This square is owned by player 3! Pay £160 to Player 3!");

                    player4Cash = player4Cash - 160;
                    Player4MoneyValue.Text = player4Cash.ToString();

                    player3Cash = player3Cash + 160;
                    Player3MoneyValue.Text = player3Cash.ToString();
                }

                if (northumberlandAvenue == 4)
                {
                    //nothing
                }
            }

            if (player4Position == 15) //maryle st
            {
                player4GamePiece.Location = new Point(63, 331);

                if (maryleboneStation == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Marylebone Station?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        maryleboneStation = 4;
                        player4Cash = player4Cash - 200;
                        Player4MoneyValue.Text = player4Cash.ToString();
                        maryleboneStationOwnedP4.Visible = true;
                    }
                }

                if (maryleboneStation == 1) // if kk stat is owned by p1
                {
                    MessageBox.Show("This square is owned by Player 1! Pay £200 to Player 1!");

                    player4Cash = player4Cash - 200;
                    Player4MoneyValue.Text = player4Cash.ToString();

                    player1Cash = player1Cash + 200;
                    Player1MoneyValue.Text = player1Cash.ToString();
                }

                if (maryleboneStation == 2)
                {
                    MessageBox.Show("This square is owned by Player 2! Pay £200 to Player 2!");

                    player4Cash = player4Cash - 200;
                    Player4MoneyValue.Text = player4Cash.ToString();

                    player2Cash = player2Cash + 200;
                    Player2MoneyValue.Text = player2Cash.ToString();
                }

                if (maryleboneStation == 3)
                {
                    MessageBox.Show("This square is owned by player 3! Pay £200 to Player 3!");

                    player4Cash = player4Cash - 200;
                    Player4MoneyValue.Text = player4Cash.ToString();

                    player3Cash = player3Cash + 200;
                    Player3MoneyValue.Text = player3Cash.ToString();
                }

                if (maryleboneStation == 4)
                {
                    //nothing
                }
            }

            if (player4Position == 16) //bow st
            {
                player4GamePiece.Location = new Point(63, 278);

                if (bowStreet == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Bow Street?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        bowStreet = 4;
                        player4Cash = player4Cash - 180;
                        Player4MoneyValue.Text = player4Cash.ToString();
                        bowStreetOwnedP4.Visible = true;
                    }
                }

                if (bowStreet == 1) // if penton is owned by p1
                {
                    MessageBox.Show("This square is owned by Player 1! Pay £180 to Player 1!");

                    player4Cash = player4Cash - 180;
                    Player4MoneyValue.Text = player4Cash.ToString();

                    player1Cash = player1Cash + 180;
                    Player1MoneyValue.Text = player1Cash.ToString();
                }

                if (bowStreet == 2)
                {
                    MessageBox.Show("This square is owned by Player 2! Pay £180 to Player 2!");

                    player4Cash = player4Cash - 180;
                    Player4MoneyValue.Text = player4Cash.ToString();

                    player2Cash = player2Cash + 180;
                    Player2MoneyValue.Text = player2Cash.ToString();
                }

                if (bowStreet == 3)
                {
                    MessageBox.Show("This square is owned by player 3! Pay £180 to Player 3!");

                    player4Cash = player4Cash - 180;
                    Player4MoneyValue.Text = player4Cash.ToString();

                    player3Cash = player3Cash + 180;
                    Player3MoneyValue.Text = player3Cash.ToString();
                }

                if (bowStreet == 4)
                {
                    //nothing
                }
            }

            if (player4Position == 17)//comm ch
            {
                player4GamePiece.Location = new Point(63, 224);
                communityChestP4();
            }

            if (player4Position == 18) //marleb str
            {
                player4GamePiece.Location = new Point(59, 172);

                if (marlboroughStreet == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Marlborough Street?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        marlboroughStreet = 4;
                        player4Cash = player4Cash - 180;
                        Player4MoneyValue.Text = player4Cash.ToString();
                        marlboroughStreetOwnedP4.Visible = true;
                    }
                }

                if (marlboroughStreet == 1) // if penton is owned by p1
                {
                    MessageBox.Show("This square is owned by Player 1! Pay £180 to Player 1!");

                    player4Cash = player4Cash - 180;
                    Player4MoneyValue.Text = player4Cash.ToString();

                    player1Cash = player1Cash + 180;
                    Player1MoneyValue.Text = player1Cash.ToString();
                }

                if (marlboroughStreet == 2)
                {
                    MessageBox.Show("This square is owned by Player 2! Pay £180 to Player 2!");

                    player4Cash = player4Cash - 180;
                    Player4MoneyValue.Text = player4Cash.ToString();

                    player2Cash = player2Cash + 180;
                    Player2MoneyValue.Text = player2Cash.ToString();
                }

                if (marlboroughStreet == 3)
                {
                    MessageBox.Show("This square is owned by player 3! Pay £180 to Player 3!");

                    player4Cash = player4Cash - 180;
                    Player4MoneyValue.Text = player4Cash.ToString();

                    player3Cash = player3Cash + 180;
                    Player3MoneyValue.Text = player3Cash.ToString();
                }

                if (marlboroughStreet == 4)
                {
                    //nothing
                }
            }

            if (player4Position == 19) //vine
            {
                player4GamePiece.Location = new Point(61, 117);

                if (vineStreet == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Vine Street?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        vineStreet = 4;
                        player4Cash = player4Cash - 200;
                        Player4MoneyValue.Text = player4Cash.ToString();
                        vineStreetOwnedP4.Visible = true;
                    }
                }

                if (vineStreet == 1) // if vine is owned by p1
                {
                    MessageBox.Show("This square is owned by Player 1! Pay £200 to Player 1!");

                    player4Cash = player4Cash - 200;
                    Player4MoneyValue.Text = player4Cash.ToString();

                    player1Cash = player1Cash + 200;
                    Player1MoneyValue.Text = player1Cash.ToString();
                }

                if (vineStreet == 2)
                {
                    MessageBox.Show("This square is owned by Player 2! Pay £200 to Player 2!");

                    player4Cash = player4Cash - 200;
                    Player4MoneyValue.Text = player4Cash.ToString();

                    player2Cash = player2Cash + 200;
                    Player2MoneyValue.Text = player2Cash.ToString();
                }

                if (vineStreet == 3)
                {
                    MessageBox.Show("This square is owned by player 3! Pay £200 to Player 3!");

                    player4Cash = player4Cash - 200;
                    Player4MoneyValue.Text = player4Cash.ToString();

                    player3Cash = player3Cash + 200;
                    Player3MoneyValue.Text = player3Cash.ToString();
                }

                if (vineStreet == 4)
                {
                    //nothing
                }
            }

            if (player4Position == 20) //free parking       
            {
                player4GamePiece.Location = new Point(92, 60);
            }

            if (player4Position == 21) //strand
            {
                player4GamePiece.Location = new Point(155, 34);

                if (strand == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Strand?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        strand = 4;
                        player4Cash = player4Cash - 220;
                        Player4MoneyValue.Text = player4Cash.ToString();
                        strandOwnedP4.Visible = true;
                    }
                }

                if (strand == 1) 
                {
                    MessageBox.Show("This square is owned by Player 1! Pay £220 to Player 1!");

                    player4Cash = player4Cash - 220;
                    Player4MoneyValue.Text = player4Cash.ToString();

                    player1Cash = player1Cash + 220;
                    Player1MoneyValue.Text = player1Cash.ToString();
                }

                if (strand == 2)
                {
                    MessageBox.Show("This square is owned by Player 2! Pay £220 to Player 2!");

                    player4Cash = player4Cash - 220;
                    Player4MoneyValue.Text = player4Cash.ToString();

                    player2Cash = player2Cash + 220;
                    Player2MoneyValue.Text = player2Cash.ToString();
                }

                if (strand == 3)
                {
                    MessageBox.Show("This square is owned by player 3! Pay £220 to Player 3!");

                    player4Cash = player4Cash - 220;
                    Player4MoneyValue.Text = player4Cash.ToString();

                    player3Cash = player3Cash + 220;
                    Player3MoneyValue.Text = player3Cash.ToString();
                }

                if (strand == 4)
                {
                    //nothing
                }
            }

            if (player4Position == 22) //chance
            {
                player4GamePiece.Location = new Point(215, 34);
                chancePlayer4();
            }

            if (player4Position == 23) //fleet
            {
                player4GamePiece.Location = new Point(281, 34);

                if (fleetStreet == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Fleet Street?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        fleetStreet = 4;
                        player4Cash = player4Cash - 220;
                        Player4MoneyValue.Text = player4Cash.ToString();
                        FleetStreetOwnedP4.Visible = true;
                    }
                }

                if (fleetStreet == 1)
                {
                    MessageBox.Show("This square is owned by Player 1! Pay £220 to Player 1!");

                    player4Cash = player4Cash - 220;
                    Player4MoneyValue.Text = player4Cash.ToString();

                    player1Cash = player1Cash + 220;
                    Player1MoneyValue.Text = player1Cash.ToString();
                }

                if (fleetStreet == 2)
                {
                    MessageBox.Show("This square is owned by Player 2! Pay £220 to Player 2!");

                    player4Cash = player4Cash - 220;
                    Player4MoneyValue.Text = player4Cash.ToString();

                    player2Cash = player2Cash + 220;
                    Player2MoneyValue.Text = player2Cash.ToString();
                }

                if (fleetStreet == 3)
                {
                    MessageBox.Show("This square is owned by player 3! Pay £220 to Player 3!");

                    player4Cash = player4Cash - 220;
                    Player4MoneyValue.Text = player4Cash.ToString();

                    player3Cash = player3Cash + 220;
                    Player3MoneyValue.Text = player3Cash.ToString();
                }

                if (fleetStreet == 4)
                {
                    //nothing
                }
            }

            if (player4Position == 24) //traf
            {
                player4GamePiece.Location = new Point(340, 34);

                if (trafalgerSquare == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Trafalgar Square?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        trafalgerSquare = 4;
                        player4Cash = player4Cash - 240;
                        Player4MoneyValue.Text = player4Cash.ToString();
                        trafalgarSquareOwnedP4.Visible = true;
                    }
                }

                if (trafalgerSquare == 1)
                {
                    MessageBox.Show("This square is owned by Player 1! Pay £240 to Player 1!");

                    player4Cash = player4Cash - 240;
                    Player4MoneyValue.Text = player4Cash.ToString();

                    player1Cash = player1Cash + 240;
                    Player1MoneyValue.Text = player1Cash.ToString();
                }

                if (trafalgerSquare == 2)
                {
                    MessageBox.Show("This square is owned by Player 2! Pay £240 to Player 2!");

                    player4Cash = player4Cash - 240;
                    Player4MoneyValue.Text = player4Cash.ToString();

                    player2Cash = player2Cash + 240;
                    Player2MoneyValue.Text = player2Cash.ToString();
                }

                if (trafalgerSquare == 3)
                {
                    MessageBox.Show("This square is owned by player 3! Pay £240 to Player 3!");

                    player4Cash = player4Cash - 240;
                    Player4MoneyValue.Text = player4Cash.ToString();

                    player3Cash = player3Cash + 240;
                    Player3MoneyValue.Text = player3Cash.ToString();
                }

                if (trafalgerSquare == 4)
                {
                    //nothing
                }
            }

            if (player4Position == 25) //fench
            {
                player4GamePiece.Location = new Point(403, 42);

                if (fenchurchStreetStation == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Fenchurch St Station?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        fenchurchStreetStation = 4;
                        player4Cash = player4Cash - 200;
                        Player4MoneyValue.Text = player4Cash.ToString();
                        fenchurchStationOwnedP4.Visible = true;
                    }
                }

                if (fenchurchStreetStation == 1) 
                {
                    MessageBox.Show("This square is owned by Player 1! Pay £200 to Player 1!");

                    player4Cash = player4Cash - 200;
                    Player4MoneyValue.Text = player4Cash.ToString();

                    player1Cash = player1Cash + 200;
                    Player1MoneyValue.Text = player1Cash.ToString();
                }

                if (fenchurchStreetStation == 2)
                {
                    MessageBox.Show("This square is owned by Player 2! Pay £200 to Player 2!");

                    player4Cash = player4Cash - 200;
                    Player4MoneyValue.Text = player4Cash.ToString();

                    player2Cash = player2Cash + 200;
                    Player2MoneyValue.Text = player2Cash.ToString();
                }

                if (fenchurchStreetStation == 3)
                {
                    MessageBox.Show("This square is owned by player 3! Pay £200 to Player 3!");

                    player4Cash = player4Cash - 200;
                    Player4MoneyValue.Text = player4Cash.ToString();

                    player3Cash = player3Cash + 200;
                    Player3MoneyValue.Text = player3Cash.ToString();
                }

                if (fenchurchStreetStation == 4)
                {
                    //nothing
                }
            }

            if (player4Position == 26) //lei
            {
                player4GamePiece.Location = new Point(466, 34);

                if (leicesterSquare == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Leicester Square?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        leicesterSquare = 4;
                        player4Cash = player4Cash - 260;
                        Player4MoneyValue.Text = player4Cash.ToString();
                        leicesterSquareOwnedP4.Visible = true;
                    }
                }

                if (leicesterSquare == 1)
                {
                    MessageBox.Show("This square is owned by Player 1! Pay £260 to Player 1!");

                    player4Cash = player4Cash - 260;
                    Player4MoneyValue.Text = player4Cash.ToString();

                    player1Cash = player1Cash + 260;
                    Player1MoneyValue.Text = player1Cash.ToString();
                }

                if (leicesterSquare == 2)
                {
                    MessageBox.Show("This square is owned by Player 2! Pay £260 to Player 2!");

                    player4Cash = player4Cash - 260;
                    Player4MoneyValue.Text = player4Cash.ToString();

                    player2Cash = player2Cash + 260;
                    Player2MoneyValue.Text = player2Cash.ToString();
                }

                if (leicesterSquare == 3)
                {
                    MessageBox.Show("This square is owned by player 3! Pay £260 to Player 3!");

                    player4Cash = player4Cash - 260;
                    Player4MoneyValue.Text = player4Cash.ToString();

                    player3Cash = player3Cash + 260;
                    Player3MoneyValue.Text = player3Cash.ToString();
                }

                if (leicesterSquare == 4)
                {
                    //nothing
                }
            }

            if (player4Position == 27) //cov
            {
                player4GamePiece.Location = new Point(527, 34);

                if (coventryStreet == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Coventry Street?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        coventryStreet = 4;
                        player4Cash = player4Cash - 260;
                        Player4MoneyValue.Text = player4Cash.ToString();
                        coventryStreetOwnedP4.Visible = true;
                    }
                }

                if (coventryStreet == 1)
                {
                    MessageBox.Show("This square is owned by Player 1! Pay £260 to Player 1!");

                    player4Cash = player4Cash - 260;
                    Player4MoneyValue.Text = player4Cash.ToString();

                    player1Cash = player1Cash + 260;
                    Player1MoneyValue.Text = player1Cash.ToString();
                }

                if (coventryStreet == 2)
                {
                    MessageBox.Show("This square is owned by Player 2! Pay £260 to Player 2!");

                    player4Cash = player4Cash - 260;
                    Player4MoneyValue.Text = player4Cash.ToString();

                    player2Cash = player2Cash + 260;
                    Player2MoneyValue.Text = player2Cash.ToString();
                }

                if (coventryStreet == 3)
                {
                    MessageBox.Show("This square is owned by player 3! Pay £260 to Player 3!");

                    player4Cash = player4Cash - 260;
                    Player4MoneyValue.Text = player4Cash.ToString();

                    player3Cash = player3Cash + 260;
                    Player3MoneyValue.Text = player3Cash.ToString();
                }

                if (coventryStreet == 4)
                {
                    //nothing
                }
            }

            if (player4Position == 28) //ww
            {
                player4GamePiece.Location = new Point(591, 11);

                if (waterWorks == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy The Water Works?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        waterWorks = 4;
                        player4Cash = player4Cash - 150;
                        Player4MoneyValue.Text = player4Cash.ToString();
                        waterworksOwnedP4.Visible = true;
                    }
                }

                if (waterWorks == 1) // if penton is owned by p1
                {
                    MessageBox.Show("This square is owned by Player 1! Pay £150 to Player 1!");

                    player4Cash = player4Cash - 150;
                    Player4MoneyValue.Text = player4Cash.ToString();

                    player1Cash = player1Cash + 150;
                    Player1MoneyValue.Text = player1Cash.ToString();
                }

                if (waterWorks == 2)
                {
                    MessageBox.Show("This square is owned by Player 2! Pay £150 to Player 2!");

                    player4Cash = player4Cash - 150;
                    Player4MoneyValue.Text = player4Cash.ToString();

                    player2Cash = player2Cash + 150;
                    Player2MoneyValue.Text = player2Cash.ToString();
                }

                if (waterWorks == 3)
                {
                    MessageBox.Show("This square is owned by player 3! Pay £150 to Player 3!");

                    player4Cash = player4Cash - 150;
                    Player4MoneyValue.Text = player4Cash.ToString();

                    player3Cash = player3Cash + 150;
                    Player3MoneyValue.Text = player3Cash.ToString();
                }

                if (waterWorks == 4)
                {
                    //nothing
                }
            }

            if (player4Position == 29) //picca
            {
                player4GamePiece.Location = new Point(653, 34);

                if (piccadilly == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Piccadilly?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        piccadilly = 4;
                        player4Cash = player4Cash - 280;
                        Player4MoneyValue.Text = player4Cash.ToString();
                        piccadillyOwnedP4.Visible = true;
                    }
                }

                if (piccadilly == 1)
                {
                    MessageBox.Show("This square is owned by Player 1! Pay £280 to Player 1!");

                    player4Cash = player4Cash - 280;
                    Player4MoneyValue.Text = player4Cash.ToString();

                    player1Cash = player1Cash + 280;
                    Player1MoneyValue.Text = player1Cash.ToString();
                }

                if (piccadilly == 2)
                {
                    MessageBox.Show("This square is owned by Player 2! Pay £280 to Player 2!");

                    player4Cash = player4Cash - 280;
                    Player4MoneyValue.Text = player4Cash.ToString();

                    player2Cash = player2Cash + 280;
                    Player2MoneyValue.Text = player2Cash.ToString();
                }

                if (piccadilly == 3)
                {
                    MessageBox.Show("This square is owned by player 3! Pay £280 to Player 3!");

                    player4Cash = player4Cash - 280;
                    Player4MoneyValue.Text = player4Cash.ToString();

                    player3Cash = player3Cash + 280;
                    Player3MoneyValue.Text = player3Cash.ToString();
                }

                if (piccadilly == 4)
                {
                    //nothing
                }
            }

            if (player4Position == 30) //go jail        
            {
                player4GamePiece.Location = new Point(749, 60);
                MessageBox.Show("Go to Jail! Do not pass GO!");
                player4GamePiece.Location = new Point(93, 604);
                player4Position = 600;
            }

            if (player4Position == 31) //regent
            {
                player4GamePiece.Location = new Point(739, 115);

                if (regentStreet == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Regent Street?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        regentStreet = 4;
                        player4Cash = player4Cash - 300;
                        Player4MoneyValue.Text = player4Cash.ToString();
                        regentStreetOwnedP4.Visible = true;
                    }
                }

                if (regentStreet == 1)
                {
                    MessageBox.Show("This square is owned by Player 1! Pay £300 to Player 1!");

                    player4Cash = player4Cash - 300;
                    Player4MoneyValue.Text = player4Cash.ToString();

                    player1Cash = player1Cash + 300;
                    Player1MoneyValue.Text = player1Cash.ToString();
                }

                if (regentStreet == 2)
                {
                    MessageBox.Show("This square is owned by Player 2! Pay £300 to Player 2!");

                    player4Cash = player4Cash - 300;
                    Player4MoneyValue.Text = player4Cash.ToString();

                    player2Cash = player2Cash + 300;
                    Player2MoneyValue.Text = player2Cash.ToString();
                }

                if (regentStreet == 3)
                {
                    MessageBox.Show("This square is owned by player 3! Pay £300 to Player 3!");

                    player4Cash = player4Cash - 300;
                    Player4MoneyValue.Text = player4Cash.ToString();

                    player3Cash = player3Cash + 300;
                    Player3MoneyValue.Text = player3Cash.ToString();
                }

                if (regentStreet == 4)
                {
                    //nothing
                }
            }

            if (player4Position == 32) //oxford
            {
                player4GamePiece.Location = new Point(741, 172);

                if (oxfordStreet == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Oxford Street?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        oxfordStreet = 4;
                        player4Cash = player4Cash - 300;
                        Player4MoneyValue.Text = player4Cash.ToString();
                        oxfordStreetOwnedP4.Visible = true;
                    }
                }

                if (oxfordStreet == 1)
                {
                    MessageBox.Show("This square is owned by Player 1! Pay £300 to Player 1!");

                    player4Cash = player4Cash - 300;
                    Player4MoneyValue.Text = player4Cash.ToString();

                    player1Cash = player1Cash + 300;
                    Player1MoneyValue.Text = player1Cash.ToString();
                }

                if (oxfordStreet == 2)
                {
                    MessageBox.Show("This square is owned by Player 2! Pay £300 to Player 2!");

                    player4Cash = player4Cash - 300;
                    Player4MoneyValue.Text = player4Cash.ToString();

                    player2Cash = player2Cash + 300;
                    Player2MoneyValue.Text = player2Cash.ToString();
                }

                if (oxfordStreet == 3)
                {
                    MessageBox.Show("This square is owned by player 3! Pay £300 to Player 3!");

                    player4Cash = player4Cash - 300;
                    Player4MoneyValue.Text = player4Cash.ToString();

                    player3Cash = player3Cash + 300;
                    Player3MoneyValue.Text = player3Cash.ToString();
                }

                if (oxfordStreet == 4)
                {
                    //nothing
                }
            }

            if (player4Position == 33) //com chest
            {
                player4GamePiece.Location = new Point(739, 224);
                communityChestP4();
            }

            if (player4Position == 34) //bond
            {
                player4GamePiece.Location = new Point(741, 277);

                if (bondStreet == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Bond Street?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        bondStreet = 4;
                        player4Cash = player4Cash - 320;
                        Player4MoneyValue.Text = player4Cash.ToString();
                        bondStreetOwnedP4.Visible = true;
                    }
                }

                if (bondStreet == 1)
                {
                    MessageBox.Show("This square is owned by Player 1! Pay £320 to Player 1!");

                    player4Cash = player4Cash - 320;
                    Player4MoneyValue.Text = player4Cash.ToString();

                    player1Cash = player1Cash + 320;
                    Player1MoneyValue.Text = player1Cash.ToString();
                }

                if (bondStreet == 2)
                {
                    MessageBox.Show("This square is owned by Player 2! Pay £320 to Player 2!");

                    player4Cash = player4Cash - 320;
                    Player4MoneyValue.Text = player4Cash.ToString();

                    player2Cash = player2Cash + 320;
                    Player2MoneyValue.Text = player2Cash.ToString();
                }

                if (bondStreet == 3)
                {
                    MessageBox.Show("This square is owned by player 3! Pay £320 to Player 3!");

                    player4Cash = player4Cash - 320;
                    Player4MoneyValue.Text = player4Cash.ToString();

                    player3Cash = player3Cash + 320;
                    Player3MoneyValue.Text = player3Cash.ToString();
                }

                if (bondStreet == 4)
                {
                    //nothing
                }
            }

            if (player4Position == 35) //liv stat
            {
                player4GamePiece.Location = new Point(738, 329);

                if (liverpoolStreetStation == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Liverpool St Station?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        liverpoolStreetStation = 4;
                        player4Cash = player4Cash - 200;
                        Player4MoneyValue.Text = player4Cash.ToString();
                        livStreetStationOwnedP4.Visible = true;
                    }
                }

                if (liverpoolStreetStation == 1)
                {
                    MessageBox.Show("This square is owned by Player 1! Pay £200 to Player 1!");

                    player4Cash = player4Cash - 200;
                    Player4MoneyValue.Text = player4Cash.ToString();

                    player1Cash = player1Cash + 200;
                    Player1MoneyValue.Text = player1Cash.ToString();
                }

                if (liverpoolStreetStation == 2)
                {
                    MessageBox.Show("This square is owned by Player 2! Pay £200 to Player 2!");

                    player4Cash = player4Cash - 200;
                    Player4MoneyValue.Text = player4Cash.ToString();

                    player2Cash = player2Cash + 200;
                    Player2MoneyValue.Text = player2Cash.ToString();
                }

                if (liverpoolStreetStation == 3)
                {
                    MessageBox.Show("This square is owned by player 3! Pay £200 to Player 3!");

                    player4Cash = player4Cash - 200;
                    Player4MoneyValue.Text = player4Cash.ToString();

                    player3Cash = player3Cash + 200;
                    Player3MoneyValue.Text = player3Cash.ToString();
                }

                if (liverpoolStreetStation == 4)
                {
                    //nothing
                }
            }

            if (player4Position == 36) //chance
            {
                player4GamePiece.Location = new Point(740, 383);
                chancePlayer4(); 
            }

            if (player4Position == 37) //parkln
            {
                player4GamePiece.Location = new Point(743, 435);

                if (parkLane == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Park Lane?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        parkLane = 4;
                        player4Cash = player4Cash - 350;
                        Player4MoneyValue.Text = player4Cash.ToString();
                        parkLaneOwnedP4.Visible = true;
                    }
                }

                if (parkLane == 1)
                {
                    MessageBox.Show("This square is owned by Player 1! Pay £350 to Player 1!");

                    player4Cash = player4Cash - 350;
                    Player4MoneyValue.Text = player4Cash.ToString();

                    player1Cash = player1Cash + 350;
                    Player1MoneyValue.Text = player1Cash.ToString();
                }

                if (parkLane == 2)
                {
                    MessageBox.Show("This square is owned by Player 2! Pay £350 to Player 2!");

                    player4Cash = player4Cash - 350;
                    Player4MoneyValue.Text = player4Cash.ToString();

                    player2Cash = player2Cash + 350;
                    Player2MoneyValue.Text = player2Cash.ToString();
                }

                if (parkLane == 3)
                {
                    MessageBox.Show("This square is owned by player 3! Pay £350 to Player 3!");

                    player4Cash = player4Cash - 350;
                    Player4MoneyValue.Text = player4Cash.ToString();

                    player3Cash = player3Cash + 350;
                    Player3MoneyValue.Text = player3Cash.ToString();
                }

                if (parkLane == 4)
                {
                    //nothing
                }
            }

            if (player4Position == 38) //super tx
            {
                player4GamePiece.Location = new Point(737, 490);
                MessageBox.Show("Super Tax! Pay £100!");
                player4Cash = player4Cash - 100;
                Player4MoneyValue.Text = player4Cash.ToString();
            }

            if (player4Position == 39) //mayfair
            {
                player4GamePiece.Location = new Point(743, 544);

                if (mayfair == 0)
                {
                    DialogResult result = MessageBox.Show("Do you want to buy Mayfair?", "Purchase Square", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        mayfair = 4;
                        player4Cash = player4Cash - 400;
                        Player4MoneyValue.Text = player4Cash.ToString();
                        mayfairOwnedP4.Visible = true;
                    }
                }

                if (mayfair == 1)
                {
                    MessageBox.Show("This square is owned by Player 1! Pay £400 to Player 1!");

                    player4Cash = player4Cash - 400;
                    Player4MoneyValue.Text = player4Cash.ToString();

                    player1Cash = player1Cash + 400;
                    Player1MoneyValue.Text = player1Cash.ToString();
                }

                if (mayfair == 2)
                {
                    MessageBox.Show("This square is owned by Player 2! Pay £400 to Player 2!");

                    player4Cash = player4Cash - 400;
                    Player4MoneyValue.Text = player4Cash.ToString();

                    player2Cash = player2Cash + 400;
                    Player2MoneyValue.Text = player2Cash.ToString();
                }

                if (mayfair == 3)
                {
                    MessageBox.Show("This square is owned by player 3! Pay £400 to Player 3!");

                    player4Cash = player4Cash - 400;
                    Player4MoneyValue.Text = player4Cash.ToString();

                    player3Cash = player3Cash + 400;
                    Player3MoneyValue.Text = player3Cash.ToString();
                }

                if (mayfair == 4)
                {
                    //nothing
                }
            }

            if (player4Position == 600)
            {
                player4GamePiece.Location = new Point(93, 604);

                MessageBox.Show("Welcome to Jail! Don't drop the soap! Roll a 6, 10 or 12 to leave!");

                player4InJail = true;
            }
        }   //player 4 move function with location

        private void startPlayer1_Click(object sender, EventArgs e) //start button player 1
       {
            initialisePlayer1();
            player1GamePiece.Visible = true;
            activePlayers++;
            isPlayer1Active = true;
       }

        private void startPlayer2_Click(object sender, EventArgs e) //start button player 2
        {
            initialisePlayer2();
            player2GamePiece.Visible = true;
            activePlayers++;
            isPlayer2Active = true;
        }

        private void startPlayer3_Click(object sender, EventArgs e) //start button player 3
        {
            initialisePlayer3();
            player3GamePiece.Visible = true;
            activePlayers++;
            isPlayer3Active = true;
        }

        private void startPlayer4_Click(object sender, EventArgs e) //start button player 4
        {
            initalisePlayer4();
            player4GamePiece.Visible = true;
            activePlayers++;
            isPlayer4Active = true;
        }


        private void startGameButton_Click(object sender, EventArgs e)
        {
            player1TurnTB.Visible = true;

              switch (activePlayers)
               {
                   case 1:     //if one player is playing
                       howManyPlayersTB.Visible = false;   //how many players are playing textbox

                       startPlayer1.Visible = false;   //start button for players
                       startPlayer2.Visible = false;
                       startPlayer3.Visible = false;
                       startPlayer4.Visible = false;   

                       startGameButton.Visible = false;    //start game big button

                       player2GamePiece.Visible = false;
                       Player2ScoreboardName.Visible = false;  //everything to do with player 2 on scoreboard
                       Player2MoneyValue.Visible = false;


                       player3GamePiece.Visible = false;
                       Player3ScoreboardName.Visible = false;  //everything to do with player 3 on scoreboard
                       Player3MoneyValue.Visible = false;


                       player4GamePiece.Visible = false;
                       Player4ScoreboardName.Visible = false;  //everything to do with player 4 on scoreboard
                       Player4MoneyValue.Visible = false;

                       poundP2.Visible = false;
                       poundP3.Visible = false;
                       poundP4.Visible = false;

                       player1Position = 0; //sets the player1position to go after button click

                       break;

                   case 2: //if 2 players are playing
                       howManyPlayersTB.Visible = false; //how many players are playing textbox

                       startGameButton.Visible = false;

                       startPlayer1.Visible = false;   //start button for players
                       startPlayer2.Visible = false;
                       startPlayer3.Visible = false;
                       startPlayer4.Visible = false;

                       player3GamePiece.Visible = false;
                       Player3ScoreboardName.Visible = false;  //everything to do with player 3 on scoreboard
                       Player3MoneyValue.Visible = false;


                       player4GamePiece.Visible = false;
                       Player4ScoreboardName.Visible = false;  //everything to do with player 4 on scoreboard
                       Player4MoneyValue.Visible = false;

                       player1Position = 0;
                       player2Position = 0;

                       poundP3.Visible = false;
                       poundP4.Visible = false;

                       break;

                   case 3: //if 3 players are playing
                       howManyPlayersTB.Visible = false; //how many players are playing textbox

                       startGameButton.Visible = false; //start game big button

                       startPlayer1.Visible = false;      //start button for players
                       startPlayer2.Visible = false;
                       startPlayer3.Visible = false;
                       startPlayer4.Visible = false;

                       player4GamePiece.Visible = false;
                       Player4ScoreboardName.Visible = false;  //everything to do with player 4 on scoreboard
                       Player4MoneyValue.Visible = false;

                       player1Position = 0;
                       player2Position = 0;
                       player3Position = 0;

                       poundP4.Visible = false;

                       break;

                   case 4: //if 4 players are playing
                       howManyPlayersTB.Visible = false; //how many players are playing button

                       startGameButton.Visible = false; //start game for big button

                       startPlayer1.Visible = false;   //start button for players
                       startPlayer2.Visible = false;
                       startPlayer3.Visible = false;
                       startPlayer4.Visible = false;

                       player1Position = 0;
                       player2Position = 0;
                       player3Position = 0;
                       player4Position = 0;

                       break; 
               }


        }

        void initialisePlayer1()
        {
            player1GamePiece.Location = new Point(705, 593); //go
            player1Cash = 1500;
            Player1MoneyValue.Text = player1Cash.ToString();
        }

        void initialisePlayer2()
        {
            player2GamePiece.Location = new Point(729, 593);
            player2Cash = 1500;
            Player2MoneyValue.Text = player2Cash.ToString();
        }

        void initialisePlayer3()
        {
            player3GamePiece.Location = new Point(705, 617);
            player3Cash = 1500;
            Player3MoneyValue.Text = player3Cash.ToString();
        }

        void initalisePlayer4()
        {
            player4GamePiece.Location = new Point(729, 617); 
            player4Cash = 1500;
            Player4MoneyValue.Text = player4Cash.ToString();
        }

        //-------------------------Chance and Community Chest-------------------------------------------------------

        void chancePlayer1() //chance function for player 1
        {
            int chanceNumber = rollChance();

            if (chanceNumber == 1)
            {
                MessageBox.Show("Advance To Go!");
                player1GamePiece.Location = new Point(705, 593);
                player1Position = 0;
            }

            if (chanceNumber == 2)
            {
                MessageBox.Show("Get Locked up! 3 Turns In Jail.");
                player1GamePiece.Location = new Point(61, 574);
                player1Position = 600;
            }
            
            if (chanceNumber == 3)
            {
                MessageBox.Show("You Entered the wrong location to uber. Go to Pall Mall.");
                player1GamePiece.Location = new Point(39, 519);
                player1Position = 11;
            }

            if (chanceNumber == 4)
            {
                MessageBox.Show("You Caught the Wrong Train! Go to Kings Cross Station.");
                player1GamePiece.Location = new Point(378, 594);
                player1Position = 5;
            }

            if (chanceNumber == 5)
            {
                MessageBox.Show("Advance to Mayfair");
                player1GamePiece.Location = new Point(719, 521);
                player1Position = 39;
            }

            if (chanceNumber == 6)
            {
                MessageBox.Show("You won the world crossword competition! Get £125");
                player1Cash = player1Cash + 125;
                Player1MoneyValue.Text = player1Cash.ToString();
            }

            if (chanceNumber == 7)
            {
                MessageBox.Show("You Bought a Drink and the bar staff charged you for 10. Lose £30");
                player1Cash = player1Cash - 30;
                Player1MoneyValue.Text = player1Cash.ToString();
            }

            if (chanceNumber == 8)
            {
                MessageBox.Show("You won a beauty contest! Recieve £100");
                player1Cash = player1Cash + 100;
                Player1MoneyValue.Text = player1Cash.ToString();
            }

            if (chanceNumber == 9)
            {
                MessageBox.Show("You lost your wallet! Lose £200");
                player1Cash = player1Cash - 200;
                Player1MoneyValue.Text = player1Cash.ToString();
            }

            if (chanceNumber == 10)
            {
                MessageBox.Show("Advance to Old Kent Road");
                player1GamePiece.Location = new Point(628, 599);
                player1Position = 1;
            }

            if (chanceNumber == 11)
            {
                MessageBox.Show("You won a Radio Competition! Win £350!");
                player1Cash = player1Cash + 350;
                Player1MoneyValue.Text = player1Cash.ToString();
            }

            if (chanceNumber == 12)
            {
                MessageBox.Show("You got caught Speeding! Recieve a fine of £100!");
                player1Cash = player1Cash - 100;
                Player1MoneyValue.Text = player1Cash.ToString();

            }
        }

        void chancePlayer2()
        {
            int chanceNumber = rollChance();

            if (chanceNumber == 1)
            {
                MessageBox.Show("Advance To Go!");
                player2GamePiece.Location = new Point(729, 593);
                player2Position = 0;
            }

            if (chanceNumber == 2)
            {
                MessageBox.Show("Get Locked up! 3 Turns In Jail.");
                player2GamePiece.Location = new Point(93, 574);
                player2Position = 60;
            }

            if (chanceNumber == 3)
            {
                MessageBox.Show("You Entered the wrong location to uber. Go to Pall Mall.");
                player2GamePiece.Location = new Point(63, 519);
                player2Position = 11;
            }

            if (chanceNumber == 4)
            {
                MessageBox.Show("You Caught the Wrong Train! Go to Kings Cross Station.");
                player2GamePiece.Location = new Point(402, 594);
                player2Position = 5;
            }

            if (chanceNumber == 5)
            {
                MessageBox.Show("Advance to Mayfair");
                player2GamePiece.Location = new Point(743, 521);
                player2Position = 39;
            }

            if (chanceNumber == 6)
            {
                MessageBox.Show("You won the world crossword competition! Get £125");
                player2Cash = player2Cash + 125;
                Player2MoneyValue.Text = player2Cash.ToString();
            }

            if (chanceNumber == 7)
            {
                MessageBox.Show("You Bought a Drink and the bar staff charged you for 10. Lose £30");
                player2Cash = player2Cash - 30;
                Player2MoneyValue.Text = player2Cash.ToString();
            }

            if (chanceNumber == 8)
            {
                MessageBox.Show("You won a beauty contest! Recieve £100");
                player2Cash = player2Cash + 100;
                Player2MoneyValue.Text = player2Cash.ToString();
            }

            if (chanceNumber == 9)
            {
                MessageBox.Show("You lost your wallet! Lose £200");
                player2Cash = player2Cash - 200;
                Player2MoneyValue.Text = player2Cash.ToString();
            }

            if (chanceNumber == 10)
            {
                MessageBox.Show("Advance to Old Kent Road");
                player2GamePiece.Location = new Point(652, 599);
                player2Position = 1;
            }

            if (chanceNumber == 11)
            {
                MessageBox.Show("You won a Radio Competition! Win £350!");
                player2Cash = player2Cash + 350;
                Player2MoneyValue.Text = player2Cash.ToString();
            }

            if (chanceNumber == 12)
            {
                MessageBox.Show("You got caught Speeding! Recieve a fine of £100!");
                player2Cash = player2Cash - 100;
                Player2MoneyValue.Text = player2Cash.ToString();

            }
        }

        void chancePlayer3()
        {
            int chanceNumber = rollChance();

            if (chanceNumber == 1)
            {
                MessageBox.Show("Advance To Go!");
                player3GamePiece.Location = new Point(705, 617);
                player3Position = 0;
            }

            if (chanceNumber == 2)
            {
                MessageBox.Show("Get Locked up! 3 Turns In Jail.");
                player3GamePiece.Location = new Point(61, 604);
                player3Position = 60;
            }

            if (chanceNumber == 3)
            {
                MessageBox.Show("You Entered the wrong location to uber. Go to Pall Mall.");
                player2GamePiece.Location = new Point(39, 543);
                player2Position = 11;
            }

            if (chanceNumber == 4)
            {
                MessageBox.Show("You Caught the Wrong Train! Go to Kings Cross Station.");
                player2GamePiece.Location = new Point(378, 617);
                player2Position = 5;
            }

            if (chanceNumber == 5)
            {
                MessageBox.Show("Advance to Mayfair");
                player2GamePiece.Location = new Point(719, 544);
                player2Position = 39;
            }

            if (chanceNumber == 6)
            {
                MessageBox.Show("You won the world crossword competition! Get £125");
                player3Cash = player3Cash + 125;
                Player3MoneyValue.Text = player3Cash.ToString();
            }

            if (chanceNumber == 7)
            {
                MessageBox.Show("You Bought a Drink and the bar staff charged you for 10. Lose £30");
                player3Cash = player3Cash - 30;
                Player3MoneyValue.Text = player3Cash.ToString();
            }

            if (chanceNumber == 8)
            {
                MessageBox.Show("You won a beauty contest! Recieve £100");
                player3Cash = player3Cash + 100;
                Player3MoneyValue.Text = player3Cash.ToString();
            }

            if (chanceNumber == 9)
            {
                MessageBox.Show("You lost your wallet! Lose £200");
                player3Cash = player3Cash - 200;
                Player3MoneyValue.Text = player3Cash.ToString();
            }

            if (chanceNumber == 10)
            {
                MessageBox.Show("Advance to Old Kent Road");
                player2GamePiece.Location = new Point(628, 622);
                player2Position = 1;
            }

            if (chanceNumber == 11)
            {
                MessageBox.Show("You won a Radio Competition! Win £350!");
                player3Cash = player3Cash + 350;
                Player3MoneyValue.Text = player3Cash.ToString();
            }

            if (chanceNumber == 12)
            {
                MessageBox.Show("You got caught Speeding! Recieve a fine of £100!");
                player3Cash = player3Cash - 100;
                Player3MoneyValue.Text = player3Cash.ToString();

            }
        }

        void chancePlayer4()
        {
            int chanceNumber = rollChance();

            if (chanceNumber == 1)
            {
                MessageBox.Show("Advance To Go!");
                player4GamePiece.Location = new Point(729, 617);
                player4Position = 0;
            }

            if (chanceNumber == 2)
            {
                MessageBox.Show("Get Locked up! 3 Turns In Jail.");
                player4GamePiece.Location = new Point(93, 604);
                player4Position = 60;
            }

            if (chanceNumber == 3)
            {
                MessageBox.Show("You Entered the wrong location to uber. Go to Pall Mall.");
                player4GamePiece.Location = new Point(63, 543);
                player4Position = 11;
            }

            if (chanceNumber == 4)
            {
                MessageBox.Show("You Caught the Wrong Train! Go to Kings Cross Station.");
                player4GamePiece.Location = new Point(402, 617);
                player4Position = 5;
            }

            if (chanceNumber == 5)
            {
                MessageBox.Show("Advance to Mayfair");
                player4GamePiece.Location = new Point(743, 544);
                player4Position = 39;
            }

            if (chanceNumber == 6)
            {
                MessageBox.Show("You won the world crossword competition! Get £125");
                player4Cash = player4Cash + 125;
                Player4MoneyValue.Text = player4Cash.ToString();
            }

            if (chanceNumber == 7)
            {
                MessageBox.Show("You Bought a Drink and the bar staff charged you for 10. Lose £30");
                player4Cash = player4Cash - 30;
                Player4MoneyValue.Text = player4Cash.ToString();
            }

            if (chanceNumber == 8)
            {
                MessageBox.Show("You won a beauty contest! Recieve £100");
                player4Cash = player4Cash + 100;
                Player4MoneyValue.Text = player4Cash.ToString();
            }

            if (chanceNumber == 9)
            {
                MessageBox.Show("You lost your wallet! Lose £200");
                player4Cash = player4Cash - 200;
                Player4MoneyValue.Text = player4Cash.ToString();
            }

            if (chanceNumber == 10)
            {
                MessageBox.Show("Advance to Old Kent Road");
                player4GamePiece.Location = new Point(652, 622);
                player4Position = 1;
            }

            if (chanceNumber == 11)
            {
                MessageBox.Show("You won a Radio Competition! Win £350!");
                player4Cash = player4Cash + 350;
                Player4MoneyValue.Text = player4Cash.ToString();
            }

            if (chanceNumber == 12)
            {
                MessageBox.Show("You got caught Speeding! Recieve a fine of £100!");
                player4Cash = player4Cash - 100;
                Player4MoneyValue.Text = player4Cash.ToString();

            }
        }

        void communityChestP1()
        {
            int chestNum = rollChest();

            if (chestNum == 1)
            {
                MessageBox.Show("Advance To Go!");
                player1GamePiece.Location = new Point(705, 593);
                player1Position = 0;
            }

            if (chestNum == 2)
            {
                MessageBox.Show("Get Locked up! 3 Turns In Jail.");
                player1GamePiece.Location = new Point(61, 574);
                player1Position = 60;
            }

            if (chestNum == 3)
            {
                MessageBox.Show("You Entered the wrong location to uber. Go to Pall Mall.");
                player1GamePiece.Location = new Point(39, 519);
                player1Position = 11;
            }

            if (chestNum == 4)
            {
                MessageBox.Show("Pay Hospital £100");
                player1Cash = player1Cash - 100;
                Player1MoneyValue.Text = player1Cash.ToString();
            }

            if (chestNum == 5)
            {
                MessageBox.Show("Pay your insurance Premium. £50");
                player1Cash = player1Cash - 50;
                Player1MoneyValue.Text = player1Cash.ToString();
            }

            if(chestNum == 6)
            {
                MessageBox.Show("Bank error in your favour. Recieve £200");
                player1Cash = player1Cash + 200;
                Player1MoneyValue.Text = player1Cash.ToString();
            }

            if (chestNum == 7)
            {
                MessageBox.Show("You inherit £100");
                player1Cash = player1Cash + 100;
                Player1MoneyValue.Text = player1Cash.ToString();
            }

            if (chestNum == 8)
            {
                MessageBox.Show("You get a tax rebate. Recieve £50");
                player1Cash = player1Cash + 50;
                Player1MoneyValue.Text = player1Cash.ToString();
            }

            if (chestNum == 9)
            {
                MessageBox.Show("Receive interest on 7% preference shares: £25");
                player1Cash = player1Cash + 25;
                Player1MoneyValue.Text = player1Cash.ToString();
            }

            if (chestNum == 10)
            {
                MessageBox.Show("You sell your stock and recieve £50");
                player1Cash = player1Cash + 50;
                Player1MoneyValue.Text = player1Cash.ToString();
            }

            if (chestNum == 11)
            {
                MessageBox.Show("You win second prize in a beauty contest. Win £10");
                player1Cash = player1Cash + 10;
                Player1MoneyValue.Text = player1Cash.ToString();
            }

            if (chestNum == 12)
            {
                MessageBox.Show("It's your birthday! Collect £50 from each player");
                player1Cash = player1Cash + 150;
                Player1MoneyValue.Text = player1Cash.ToString();

                player2Cash = player2Cash - 50;
                Player2MoneyValue.Text = player2Cash.ToString();

                player3Cash = player3Cash - 50;
                Player3MoneyValue.Text = player3Cash.ToString();

                player4Cash = player4Cash - 50;
                Player4MoneyValue.Text = player4Cash.ToString();
            }
        }

        void communityChestP2()
        {
            int chestNum = rollChest();

            if (chestNum == 1)
            {
                MessageBox.Show("Advance To Go!");
                player2GamePiece.Location = new Point(729, 593);
                player2Position = 0;
            }

            if (chestNum == 2)
            {
                MessageBox.Show("Get Locked up! 3 Turns In Jail.");
                player2GamePiece.Location = new Point(93, 574);
                player2Position = 60;
            }

            if (chestNum == 3)
            {
                MessageBox.Show("You Entered the wrong location to uber. Go to Pall Mall.");
                player2GamePiece.Location = new Point(63, 519);
                player2Position = 11;
            }

            if (chestNum == 4)
            {
                MessageBox.Show("Pay Hospital £100");
                player2Cash = player2Cash - 100;
                Player2MoneyValue.Text = player2Cash.ToString();
            }

            if (chestNum == 5)
            {
                MessageBox.Show("Pay your insurance Premium. £50");
                player2Cash = player2Cash - 50;
                Player2MoneyValue.Text = player2Cash.ToString();
            }

            if (chestNum == 6)
            {
                MessageBox.Show("Bank error in your favour. Recieve £200");
                player2Cash = player2Cash + 200;
                Player2MoneyValue.Text = player2Cash.ToString();
            }

            if (chestNum == 7)
            {
                MessageBox.Show("You inherit £100");
                player2Cash = player2Cash + 100;
                Player2MoneyValue.Text = player2Cash.ToString();
            }

            if (chestNum == 8)
            {
                MessageBox.Show("You get a tax rebate. Recieve £50");
                player2Cash = player2Cash + 50;
                Player2MoneyValue.Text = player2Cash.ToString();
            }

            if (chestNum == 9)
            {
                MessageBox.Show("Receive interest on 7% preference shares: £25");
                player2Cash = player2Cash + 25;
                Player2MoneyValue.Text = player2Cash.ToString();
            }

            if (chestNum == 10)
            {
                MessageBox.Show("You sell your stock and recieve £50");
                player2Cash = player2Cash + 50;
                Player2MoneyValue.Text = player2Cash.ToString();
            }

            if (chestNum == 11)
            {
                MessageBox.Show("You win second prize in a beauty contest. Win £10");
                player2Cash = player2Cash + 10;
                Player2MoneyValue.Text = player2Cash.ToString();
            }

            if (chestNum == 12)
            {
                MessageBox.Show("It's your birthday! Collect £50 from each player");
                player2Cash = player2Cash + 150;
                Player2MoneyValue.Text = player2Cash.ToString();

                player1Cash = player1Cash - 50;
                Player1MoneyValue.Text = player1Cash.ToString();

                player3Cash = player3Cash - 50;
                Player3MoneyValue.Text = player3Cash.ToString();

                player4Cash = player4Cash - 50;
                Player4MoneyValue.Text = player4Cash.ToString();
            }
        }

        void communityChestP3()
        {
            int chestNum = rollChest();

            if (chestNum == 1)
            {
                MessageBox.Show("Advance To Go!");
                player3GamePiece.Location = new Point(705, 617);
                player3Position = 0;
            }

            if (chestNum == 2)
            {
                MessageBox.Show("Get Locked up! 3 Turns In Jail.");
                player3GamePiece.Location = new Point(61, 604);
                player3Position = 60;
            }

            if (chestNum == 3)
            {
                MessageBox.Show("You Entered the wrong location to uber. Go to Pall Mall.");
                player3GamePiece.Location = new Point(39, 543);
                player3Position = 11;
            }

            if (chestNum == 4)
            {
                MessageBox.Show("Pay Hospital £100");
                player3Cash = player3Cash - 100;
                Player3MoneyValue.Text = player3Cash.ToString();
            }

            if (chestNum == 5)
            {
                MessageBox.Show("Pay your insurance Premium. £50");
                player3Cash = player3Cash - 50;
                Player3MoneyValue.Text = player3Cash.ToString();
            }

            if (chestNum == 6)
            {
                MessageBox.Show("Bank error in your favour. Recieve £200");
                player3Cash = player3Cash + 200;
                Player3MoneyValue.Text = player3Cash.ToString();
            }

            if (chestNum == 7)
            {
                MessageBox.Show("You inherit £100");
                player3Cash = player3Cash + 100;
                Player3MoneyValue.Text = player3Cash.ToString();
            }

            if (chestNum == 8)
            {
                MessageBox.Show("You get a tax rebate. Recieve £50");
                player3Cash = player3Cash + 50;
                Player3MoneyValue.Text = player3Cash.ToString();
            }

            if (chestNum == 9)
            {
                MessageBox.Show("Receive interest on 7% preference shares: £25");
                player3Cash = player3Cash + 25;
                Player3MoneyValue.Text = player3Cash.ToString();
            }

            if (chestNum == 10)
            {
                MessageBox.Show("You sell your stock and recieve £50");
                player3Cash = player3Cash + 50;
                Player3MoneyValue.Text = player3Cash.ToString();
            }

            if (chestNum == 11)
            {
                MessageBox.Show("You win second prize in a beauty contest. Win £10");
                player3Cash = player3Cash + 10;
                Player3MoneyValue.Text = player3Cash.ToString();
            }

            if (chestNum == 12)
            {
                MessageBox.Show("It's your birthday! Collect £50 from each player");
                player3Cash = player3Cash + 150;
                Player3MoneyValue.Text = player3Cash.ToString();

                player1Cash = player1Cash - 50;
                Player1MoneyValue.Text = player1Cash.ToString();

                player2Cash = player2Cash - 50;
                Player2MoneyValue.Text = player2Cash.ToString();

                player4Cash = player4Cash - 50;
                Player4MoneyValue.Text = player4Cash.ToString();
            }
        }

        void communityChestP4()
        {
            int chestNum = rollChest();

            if (chestNum == 1)
            {
                MessageBox.Show("Advance To Go!");
                player4GamePiece.Location = new Point(729, 617);
                player4Position = 0;
            }

            if (chestNum == 2)
            {
                MessageBox.Show("Get Locked up! 3 Turns In Jail.");
                player4GamePiece.Location = new Point(93, 604);
                player4Position = 60;
            }

            if (chestNum == 3)
            {
                MessageBox.Show("You Entered the wrong location to uber. Go to Pall Mall.");
                player4GamePiece.Location = new Point(63, 543);
                player4Position = 11;
            }

            if (chestNum == 4)
            {
                MessageBox.Show("Pay Hospital £100");
                player4Cash = player4Cash - 100;
                Player4MoneyValue.Text = player4Cash.ToString();
            }

            if (chestNum == 5)
            {
                MessageBox.Show("Pay your insurance Premium. £50");
                player4Cash = player4Cash - 50;
                Player4MoneyValue.Text = player4Cash.ToString();
            }

            if (chestNum == 6)
            {
                MessageBox.Show("Bank error in your favour. Recieve £200");
                player4Cash = player4Cash + 200;
                Player4MoneyValue.Text = player4Cash.ToString();
            }

            if (chestNum == 7)
            {
                MessageBox.Show("You inherit £100");
                player4Cash = player4Cash + 100;
                Player4MoneyValue.Text = player4Cash.ToString();
            }

            if (chestNum == 8)
            {
                MessageBox.Show("You get a tax rebate. Recieve £50");
                player4Cash = player4Cash + 50;
                Player4MoneyValue.Text = player4Cash.ToString();
            }

            if (chestNum == 9)
            {
                MessageBox.Show("Receive interest on 7% preference shares: £25");
                player4Cash = player4Cash + 25;
                Player4MoneyValue.Text = player4Cash.ToString();
            }

            if (chestNum == 10)
            {
                MessageBox.Show("You sell your stock and recieve £50");
                player4Cash = player4Cash + 50;
                Player4MoneyValue.Text = player4Cash.ToString();
            }

            if (chestNum == 11)
            {
                MessageBox.Show("You win second prize in a beauty contest. Win £10");
                player4Cash = player4Cash + 10;
                Player4MoneyValue.Text = player4Cash.ToString();
            }

            if (chestNum == 12)
            {
                MessageBox.Show("It's your birthday! Collect £50 from each player");
                player4Cash = player4Cash + 150;
                Player4MoneyValue.Text = player4Cash.ToString();

                player1Cash = player1Cash - 50;
                Player1MoneyValue.Text = player1Cash.ToString();

                player2Cash = player2Cash - 50;
                Player2MoneyValue.Text = player2Cash.ToString();

                player3Cash = player3Cash - 50;
                Player3MoneyValue.Text = player3Cash.ToString();
            }
        }

        int rollChance() //get rand number for chance cards
        {
            return new Random((int)DateTime.Now.Ticks).Next(1, 12);
        }

        int rollChest()
        {
            return new Random((int)DateTime.Now.Ticks).Next(1, 12);
        }
        //-------------------------Chance And Communnity Chest------------------------------------------------------


        //----------------------------Jail--------------------------------------------------------------------------

        //----------------------------Jail--------------------------------------------------------------------------



        //------------------------------debug-----------------------------------------------------------------------
        private void DebugPlayer1Move_Click(object sender, EventArgs e)
        {
           // player1Position++;
            player1Move();
        }

        private void debugPlayer2Move_Click(object sender, EventArgs e)
        {
            //player2Position++;
            player2Move();
        }

        private void debugPlayer3Move_Click(object sender, EventArgs e)
        {
          //  player3Position++;
            player3Move();
        }

        private void debugPlayer4Move_Click(object sender, EventArgs e)
        {
           // player4Position++;
            player4Move();
        }
        //------------------------------debug-----------------------------------------------------------------------


        private void endTurn_Click(object sender, EventArgs e) //end turn button
        {
            if (activePlayers == 1)
            {
                if (currentPlayer == 1)
                {
                    currentPlayer = 1;
                    player1TurnTB.Visible = true;
                    player2TurnTB.Visible = false;
                    player3TurnTB.Visible = false;
                    player4TurnTB.Visible = false;
                }
            }

            else if (activePlayers == 2) //if the active players is 2
            {
                if (currentPlayer == 1)
                {
                    currentPlayer = 2;
                    player2TurnTB.Visible = true;
                    player1TurnTB.Visible = false;
                    player3TurnTB.Visible = false;
                    player4TurnTB.Visible = false;

                }

                else if (currentPlayer == 2)
                {
                    currentPlayer = 1;
                    player1TurnTB.Visible = true;
                    player2TurnTB.Visible = false;
                    player3TurnTB.Visible = false;
                    player4TurnTB.Visible = false;
                }
            }

            else if (activePlayers == 3)
            {
                if (currentPlayer == 1)
                {
                    currentPlayer = 2;
                    player2TurnTB.Visible = true;
                    player1TurnTB.Visible = false;
                    player3TurnTB.Visible = false;
                    player4TurnTB.Visible = false;
                }

                else if (currentPlayer == 2)
                {
                    currentPlayer = 3;
                    player3TurnTB.Visible = true;
                    player1TurnTB.Visible = false;
                    player2TurnTB.Visible = false;
                    player4TurnTB.Visible = false;
                }

                else if (currentPlayer == 3)
                {
                    currentPlayer = 1;
                    player1TurnTB.Visible = true;
                    player2TurnTB.Visible = false;
                    player3TurnTB.Visible = false;
                    player4TurnTB.Visible = false;
                }
            }

            else if (activePlayers == 4)
            {
                if (currentPlayer == 1)
                {
                    currentPlayer = 2;
                    player2TurnTB.Visible = true;
                    player1TurnTB.Visible = false;
                    player3TurnTB.Visible = false;
                    player4TurnTB.Visible = false;
                }

                else if (currentPlayer == 2)
                {
                    currentPlayer = 3;
                    player3TurnTB.Visible = true;
                    player1TurnTB.Visible = false;
                    player2TurnTB.Visible = false;
                    player4TurnTB.Visible = false;
                }

                else if (currentPlayer == 3)
                {
                    currentPlayer = 4;
                    player4TurnTB.Visible = true;
                    player1TurnTB.Visible = false;
                    player2TurnTB.Visible = false;
                    player3TurnTB.Visible = false;
                }

                else if (currentPlayer == 4)
                {
                    currentPlayer = 1;
                    player1TurnTB.Visible = true;
                    player2TurnTB.Visible = false;
                    player3TurnTB.Visible = false;
                    player4TurnTB.Visible = false;
                }
            }



         
        }

    }
}
