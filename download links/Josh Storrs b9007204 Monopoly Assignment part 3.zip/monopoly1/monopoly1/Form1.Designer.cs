﻿namespace monopoly1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.MonopolyBoard = new System.Windows.Forms.PictureBox();
            this.player4GamePiece = new System.Windows.Forms.PictureBox();
            this.player1GamePiece = new System.Windows.Forms.PictureBox();
            this.player2GamePiece = new System.Windows.Forms.PictureBox();
            this.player3GamePiece = new System.Windows.Forms.PictureBox();
            this.ScoreBoardHeader = new System.Windows.Forms.TextBox();
            this.Player1ScoreboardName = new System.Windows.Forms.TextBox();
            this.Player4ScoreboardName = new System.Windows.Forms.TextBox();
            this.Player3ScoreboardName = new System.Windows.Forms.TextBox();
            this.Player2ScoreboardName = new System.Windows.Forms.TextBox();
            this.Player1MoneyValue = new System.Windows.Forms.TextBox();
            this.Player4MoneyValue = new System.Windows.Forms.TextBox();
            this.Player3MoneyValue = new System.Windows.Forms.TextBox();
            this.Player2MoneyValue = new System.Windows.Forms.TextBox();
            this.CommunityChest = new System.Windows.Forms.PictureBox();
            this.Chance = new System.Windows.Forms.PictureBox();
            this.DicePictureBox1 = new System.Windows.Forms.PictureBox();
            this.DicePictureBox2 = new System.Windows.Forms.PictureBox();
            this.ThrowDiceButton = new System.Windows.Forms.Button();
            this.Dice1ValueLabel = new System.Windows.Forms.Label();
            this.Dice2ValueLabel = new System.Windows.Forms.Label();
            this.TotalDiceValue = new System.Windows.Forms.Label();
            this.howManyPlayersTB = new System.Windows.Forms.TextBox();
            this.startPlayer1 = new System.Windows.Forms.Button();
            this.startPlayer2 = new System.Windows.Forms.Button();
            this.startPlayer3 = new System.Windows.Forms.Button();
            this.startPlayer4 = new System.Windows.Forms.Button();
            this.startGameButton = new System.Windows.Forms.Button();
            this.DebugLabel = new System.Windows.Forms.Label();
            this.player1PositionDebug = new System.Windows.Forms.Label();
            this.player2PositionDebug = new System.Windows.Forms.Label();
            this.player3PositionDebug = new System.Windows.Forms.Label();
            this.player4PositionDebug = new System.Windows.Forms.Label();
            this.player1PositionTextBox = new System.Windows.Forms.TextBox();
            this.player4PositionTextBox = new System.Windows.Forms.TextBox();
            this.player3PositionTextBox = new System.Windows.Forms.TextBox();
            this.player2PositionTextBox = new System.Windows.Forms.TextBox();
            this.DebugPlayer1Move = new System.Windows.Forms.Button();
            this.debugPlayer2Move = new System.Windows.Forms.Button();
            this.debugPlayer3Move = new System.Windows.Forms.Button();
            this.debugPlayer4Move = new System.Windows.Forms.Button();
            this.poundP1 = new System.Windows.Forms.TextBox();
            this.poundP4 = new System.Windows.Forms.TextBox();
            this.poundP3 = new System.Windows.Forms.TextBox();
            this.poundP2 = new System.Windows.Forms.TextBox();
            this.endTurn = new System.Windows.Forms.Button();
            this.oldKentRoadOwnedP1 = new System.Windows.Forms.PictureBox();
            this.oldKentRoadOwnedP2 = new System.Windows.Forms.PictureBox();
            this.oldKentRoadOwnedP3 = new System.Windows.Forms.PictureBox();
            this.oldKentRoadOwnedP4 = new System.Windows.Forms.PictureBox();
            this.whitechapelRoadOwnedP4 = new System.Windows.Forms.PictureBox();
            this.whitechapelRoadOwnedP3 = new System.Windows.Forms.PictureBox();
            this.whitechapelRoadOwnedP2 = new System.Windows.Forms.PictureBox();
            this.whitechapelRoadOwnedP1 = new System.Windows.Forms.PictureBox();
            this.kingsCrossOwnedP4 = new System.Windows.Forms.PictureBox();
            this.kingsCrossOwnedP3 = new System.Windows.Forms.PictureBox();
            this.kingsCrossOwnedP2 = new System.Windows.Forms.PictureBox();
            this.kingsCrossOwnedP1 = new System.Windows.Forms.PictureBox();
            this.angelIslingtonOwnedP4 = new System.Windows.Forms.PictureBox();
            this.angelIslingtonOwnedP3 = new System.Windows.Forms.PictureBox();
            this.angelIslingtonOwnedP2 = new System.Windows.Forms.PictureBox();
            this.angelIslingtonOwnedP1 = new System.Windows.Forms.PictureBox();
            this.eustonRoadOwnedP4 = new System.Windows.Forms.PictureBox();
            this.eustonRoadOwnedP3 = new System.Windows.Forms.PictureBox();
            this.eustonRoadOwnedP2 = new System.Windows.Forms.PictureBox();
            this.eustonRoadOwnedP1 = new System.Windows.Forms.PictureBox();
            this.pentonvilleRoadOwnedP4 = new System.Windows.Forms.PictureBox();
            this.pentonvilleRoadOwnedP3 = new System.Windows.Forms.PictureBox();
            this.pentonvilleRoadOwnedP2 = new System.Windows.Forms.PictureBox();
            this.pentonvilleRoadOwnedP1 = new System.Windows.Forms.PictureBox();
            this.pallMallOwnedP4 = new System.Windows.Forms.PictureBox();
            this.pallMallOwnedP3 = new System.Windows.Forms.PictureBox();
            this.pallMallOwnedP2 = new System.Windows.Forms.PictureBox();
            this.pallMallOwnedP1 = new System.Windows.Forms.PictureBox();
            this.whitehallOwnedP4 = new System.Windows.Forms.PictureBox();
            this.whitehallOwnedP3 = new System.Windows.Forms.PictureBox();
            this.whitehallOwnedP2 = new System.Windows.Forms.PictureBox();
            this.whitehallOwnedP1 = new System.Windows.Forms.PictureBox();
            this.northumberlandOwnedP4 = new System.Windows.Forms.PictureBox();
            this.northumberlandOwnedP3 = new System.Windows.Forms.PictureBox();
            this.northumberlandOwnedP2 = new System.Windows.Forms.PictureBox();
            this.northumberlandOwnedP1 = new System.Windows.Forms.PictureBox();
            this.maryleboneStationOwnedP4 = new System.Windows.Forms.PictureBox();
            this.maryleboneStationOwnedP3 = new System.Windows.Forms.PictureBox();
            this.maryleboneStationOwnedP2 = new System.Windows.Forms.PictureBox();
            this.maryleboneStationOwnedP1 = new System.Windows.Forms.PictureBox();
            this.bowStreetOwnedP4 = new System.Windows.Forms.PictureBox();
            this.bowStreetOwnedP3 = new System.Windows.Forms.PictureBox();
            this.bowStreetOwnedP2 = new System.Windows.Forms.PictureBox();
            this.bowStreetOwnedP1 = new System.Windows.Forms.PictureBox();
            this.marlboroughStreetOwnedP4 = new System.Windows.Forms.PictureBox();
            this.marlboroughStreetOwnedP3 = new System.Windows.Forms.PictureBox();
            this.marlboroughStreetOwnedP2 = new System.Windows.Forms.PictureBox();
            this.marlboroughStreetOwnedP1 = new System.Windows.Forms.PictureBox();
            this.vineStreetOwnedP4 = new System.Windows.Forms.PictureBox();
            this.vineStreetOwnedP3 = new System.Windows.Forms.PictureBox();
            this.vineStreetOwnedP2 = new System.Windows.Forms.PictureBox();
            this.vineStreetOwnedP1 = new System.Windows.Forms.PictureBox();
            this.electricCompanyOwnedP4 = new System.Windows.Forms.PictureBox();
            this.electricCompanyOwnedP3 = new System.Windows.Forms.PictureBox();
            this.electricCompanyOwnedP2 = new System.Windows.Forms.PictureBox();
            this.electricCompanyOwnedP1 = new System.Windows.Forms.PictureBox();
            this.strandOwnedP4 = new System.Windows.Forms.PictureBox();
            this.strandOwnedP3 = new System.Windows.Forms.PictureBox();
            this.strandOwnedP2 = new System.Windows.Forms.PictureBox();
            this.strandOwnedP1 = new System.Windows.Forms.PictureBox();
            this.FleetStreetOwnedP4 = new System.Windows.Forms.PictureBox();
            this.FleetStreetOwnedP3 = new System.Windows.Forms.PictureBox();
            this.FleetStreetOwnedP2 = new System.Windows.Forms.PictureBox();
            this.FleetStreetOwnedP1 = new System.Windows.Forms.PictureBox();
            this.trafalgarSquareOwnedP4 = new System.Windows.Forms.PictureBox();
            this.trafalgarSquareOwnedP3 = new System.Windows.Forms.PictureBox();
            this.trafalgarSquareOwnedP2 = new System.Windows.Forms.PictureBox();
            this.trafalgarSquareOwnedP1 = new System.Windows.Forms.PictureBox();
            this.leicesterSquareOwnedP4 = new System.Windows.Forms.PictureBox();
            this.leicesterSquareOwnedP3 = new System.Windows.Forms.PictureBox();
            this.leicesterSquareOwnedP2 = new System.Windows.Forms.PictureBox();
            this.leicesterSquareOwnedP1 = new System.Windows.Forms.PictureBox();
            this.coventryStreetOwnedP4 = new System.Windows.Forms.PictureBox();
            this.coventryStreetOwnedP3 = new System.Windows.Forms.PictureBox();
            this.coventryStreetOwnedP2 = new System.Windows.Forms.PictureBox();
            this.coventryStreetOwnedP1 = new System.Windows.Forms.PictureBox();
            this.piccadillyOwnedP4 = new System.Windows.Forms.PictureBox();
            this.piccadillyOwnedP3 = new System.Windows.Forms.PictureBox();
            this.piccadillyOwnedP2 = new System.Windows.Forms.PictureBox();
            this.piccadillyOwnedP1 = new System.Windows.Forms.PictureBox();
            this.fenchurchStationOwnedP4 = new System.Windows.Forms.PictureBox();
            this.fenchurchStationOwnedP3 = new System.Windows.Forms.PictureBox();
            this.fenchurchStationOwnedP2 = new System.Windows.Forms.PictureBox();
            this.fenchurchStationOwnedP1 = new System.Windows.Forms.PictureBox();
            this.waterworksOwnedP4 = new System.Windows.Forms.PictureBox();
            this.waterworksOwnedP3 = new System.Windows.Forms.PictureBox();
            this.waterworksOwnedP2 = new System.Windows.Forms.PictureBox();
            this.waterworksOwnedP1 = new System.Windows.Forms.PictureBox();
            this.regentStreetOwnedP4 = new System.Windows.Forms.PictureBox();
            this.regentStreetOwnedP3 = new System.Windows.Forms.PictureBox();
            this.regentStreetOwnedP2 = new System.Windows.Forms.PictureBox();
            this.regentStreetOwnedP1 = new System.Windows.Forms.PictureBox();
            this.oxfordStreetOwnedP4 = new System.Windows.Forms.PictureBox();
            this.oxfordStreetOwnedP3 = new System.Windows.Forms.PictureBox();
            this.oxfordStreetOwnedP2 = new System.Windows.Forms.PictureBox();
            this.oxfordStreetOwnedP1 = new System.Windows.Forms.PictureBox();
            this.bondStreetOwnedP4 = new System.Windows.Forms.PictureBox();
            this.bondStreetOwnedP3 = new System.Windows.Forms.PictureBox();
            this.bondStreetOwnedP2 = new System.Windows.Forms.PictureBox();
            this.bondStreetOwnedP1 = new System.Windows.Forms.PictureBox();
            this.livStreetStationOwnedP4 = new System.Windows.Forms.PictureBox();
            this.livStreetStationOwnedP3 = new System.Windows.Forms.PictureBox();
            this.livStreetStationOwnedP2 = new System.Windows.Forms.PictureBox();
            this.livStreetStationOwnedP1 = new System.Windows.Forms.PictureBox();
            this.parkLaneOwnedP4 = new System.Windows.Forms.PictureBox();
            this.parkLaneOwnedP3 = new System.Windows.Forms.PictureBox();
            this.parkLaneOwnedP2 = new System.Windows.Forms.PictureBox();
            this.parkLaneOwnedP1 = new System.Windows.Forms.PictureBox();
            this.mayfairOwnedP4 = new System.Windows.Forms.PictureBox();
            this.mayfairOwnedP3 = new System.Windows.Forms.PictureBox();
            this.mayfairOwnedP2 = new System.Windows.Forms.PictureBox();
            this.mayfairOwnedP1 = new System.Windows.Forms.PictureBox();
            this.player1TurnTB = new System.Windows.Forms.TextBox();
            this.player2TurnTB = new System.Windows.Forms.TextBox();
            this.player3TurnTB = new System.Windows.Forms.TextBox();
            this.player4TurnTB = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.MonopolyBoard)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.player4GamePiece)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.player1GamePiece)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.player2GamePiece)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.player3GamePiece)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.CommunityChest)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Chance)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DicePictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DicePictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.oldKentRoadOwnedP1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.oldKentRoadOwnedP2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.oldKentRoadOwnedP3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.oldKentRoadOwnedP4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.whitechapelRoadOwnedP4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.whitechapelRoadOwnedP3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.whitechapelRoadOwnedP2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.whitechapelRoadOwnedP1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kingsCrossOwnedP4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kingsCrossOwnedP3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kingsCrossOwnedP2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kingsCrossOwnedP1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.angelIslingtonOwnedP4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.angelIslingtonOwnedP3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.angelIslingtonOwnedP2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.angelIslingtonOwnedP1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.eustonRoadOwnedP4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.eustonRoadOwnedP3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.eustonRoadOwnedP2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.eustonRoadOwnedP1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pentonvilleRoadOwnedP4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pentonvilleRoadOwnedP3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pentonvilleRoadOwnedP2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pentonvilleRoadOwnedP1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pallMallOwnedP4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pallMallOwnedP3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pallMallOwnedP2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pallMallOwnedP1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.whitehallOwnedP4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.whitehallOwnedP3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.whitehallOwnedP2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.whitehallOwnedP1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.northumberlandOwnedP4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.northumberlandOwnedP3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.northumberlandOwnedP2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.northumberlandOwnedP1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.maryleboneStationOwnedP4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.maryleboneStationOwnedP3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.maryleboneStationOwnedP2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.maryleboneStationOwnedP1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bowStreetOwnedP4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bowStreetOwnedP3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bowStreetOwnedP2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bowStreetOwnedP1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.marlboroughStreetOwnedP4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.marlboroughStreetOwnedP3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.marlboroughStreetOwnedP2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.marlboroughStreetOwnedP1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vineStreetOwnedP4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vineStreetOwnedP3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vineStreetOwnedP2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vineStreetOwnedP1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.electricCompanyOwnedP4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.electricCompanyOwnedP3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.electricCompanyOwnedP2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.electricCompanyOwnedP1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.strandOwnedP4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.strandOwnedP3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.strandOwnedP2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.strandOwnedP1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.FleetStreetOwnedP4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.FleetStreetOwnedP3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.FleetStreetOwnedP2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.FleetStreetOwnedP1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trafalgarSquareOwnedP4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trafalgarSquareOwnedP3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trafalgarSquareOwnedP2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trafalgarSquareOwnedP1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.leicesterSquareOwnedP4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.leicesterSquareOwnedP3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.leicesterSquareOwnedP2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.leicesterSquareOwnedP1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.coventryStreetOwnedP4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.coventryStreetOwnedP3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.coventryStreetOwnedP2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.coventryStreetOwnedP1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.piccadillyOwnedP4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.piccadillyOwnedP3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.piccadillyOwnedP2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.piccadillyOwnedP1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fenchurchStationOwnedP4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fenchurchStationOwnedP3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fenchurchStationOwnedP2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fenchurchStationOwnedP1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.waterworksOwnedP4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.waterworksOwnedP3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.waterworksOwnedP2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.waterworksOwnedP1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.regentStreetOwnedP4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.regentStreetOwnedP3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.regentStreetOwnedP2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.regentStreetOwnedP1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.oxfordStreetOwnedP4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.oxfordStreetOwnedP3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.oxfordStreetOwnedP2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.oxfordStreetOwnedP1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bondStreetOwnedP4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bondStreetOwnedP3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bondStreetOwnedP2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bondStreetOwnedP1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.livStreetStationOwnedP4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.livStreetStationOwnedP3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.livStreetStationOwnedP2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.livStreetStationOwnedP1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.parkLaneOwnedP4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.parkLaneOwnedP3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.parkLaneOwnedP2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.parkLaneOwnedP1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mayfairOwnedP4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mayfairOwnedP3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mayfairOwnedP2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mayfairOwnedP1)).BeginInit();
            this.SuspendLayout();
            // 
            // MonopolyBoard
            // 
            this.MonopolyBoard.BackColor = System.Drawing.Color.Transparent;
            this.MonopolyBoard.BackgroundImage = global::monopoly1.Properties.Resources.monopoly_board;
            this.MonopolyBoard.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.MonopolyBoard.Location = new System.Drawing.Point(30, 3);
            this.MonopolyBoard.Name = "MonopolyBoard";
            this.MonopolyBoard.Size = new System.Drawing.Size(1142, 1003);
            this.MonopolyBoard.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.MonopolyBoard.TabIndex = 0;
            this.MonopolyBoard.TabStop = false;
            // 
            // player4GamePiece
            // 
            this.player4GamePiece.BackColor = System.Drawing.Color.Fuchsia;
            this.player4GamePiece.BackgroundImage = global::monopoly1.Properties.Resources.wheel_transparent_monopoly;
            this.player4GamePiece.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.player4GamePiece.Location = new System.Drawing.Point(1196, 243);
            this.player4GamePiece.Name = "player4GamePiece";
            this.player4GamePiece.Size = new System.Drawing.Size(30, 29);
            this.player4GamePiece.TabIndex = 1;
            this.player4GamePiece.TabStop = false;
            // 
            // player1GamePiece
            // 
            this.player1GamePiece.BackColor = System.Drawing.Color.Red;
            this.player1GamePiece.BackgroundImage = global::monopoly1.Properties.Resources.car_transparent_monopoly;
            this.player1GamePiece.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.player1GamePiece.Image = global::monopoly1.Properties.Resources.car_transparent_monopoly;
            this.player1GamePiece.Location = new System.Drawing.Point(1200, 91);
            this.player1GamePiece.Name = "player1GamePiece";
            this.player1GamePiece.Size = new System.Drawing.Size(30, 30);
            this.player1GamePiece.TabIndex = 2;
            this.player1GamePiece.TabStop = false;
            // 
            // player2GamePiece
            // 
            this.player2GamePiece.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.player2GamePiece.BackgroundImage = global::monopoly1.Properties.Resources.dog_transparent;
            this.player2GamePiece.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.player2GamePiece.Location = new System.Drawing.Point(1200, 137);
            this.player2GamePiece.Name = "player2GamePiece";
            this.player2GamePiece.Size = new System.Drawing.Size(30, 29);
            this.player2GamePiece.TabIndex = 3;
            this.player2GamePiece.TabStop = false;
            // 
            // player3GamePiece
            // 
            this.player3GamePiece.BackColor = System.Drawing.Color.Blue;
            this.player3GamePiece.BackgroundImage = global::monopoly1.Properties.Resources.hat_transparent_monopolu;
            this.player3GamePiece.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.player3GamePiece.Location = new System.Drawing.Point(1196, 192);
            this.player3GamePiece.Name = "player3GamePiece";
            this.player3GamePiece.Size = new System.Drawing.Size(30, 29);
            this.player3GamePiece.TabIndex = 4;
            this.player3GamePiece.TabStop = false;
            // 
            // ScoreBoardHeader
            // 
            this.ScoreBoardHeader.BackColor = System.Drawing.Color.PaleGreen;
            this.ScoreBoardHeader.Font = new System.Drawing.Font("Elephant", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ScoreBoardHeader.Location = new System.Drawing.Point(1236, 17);
            this.ScoreBoardHeader.Name = "ScoreBoardHeader";
            this.ScoreBoardHeader.Size = new System.Drawing.Size(252, 54);
            this.ScoreBoardHeader.TabIndex = 5;
            this.ScoreBoardHeader.Text = "ScoreBoard:";
            // 
            // Player1ScoreboardName
            // 
            this.Player1ScoreboardName.BackColor = System.Drawing.Color.PaleGreen;
            this.Player1ScoreboardName.Font = new System.Drawing.Font("Elephant", 14F);
            this.Player1ScoreboardName.Location = new System.Drawing.Point(1236, 77);
            this.Player1ScoreboardName.Name = "Player1ScoreboardName";
            this.Player1ScoreboardName.Size = new System.Drawing.Size(126, 44);
            this.Player1ScoreboardName.TabIndex = 6;
            this.Player1ScoreboardName.Text = "Player 1";
            // 
            // Player4ScoreboardName
            // 
            this.Player4ScoreboardName.BackColor = System.Drawing.Color.PaleGreen;
            this.Player4ScoreboardName.Font = new System.Drawing.Font("Elephant", 14F);
            this.Player4ScoreboardName.Location = new System.Drawing.Point(1236, 228);
            this.Player4ScoreboardName.Name = "Player4ScoreboardName";
            this.Player4ScoreboardName.Size = new System.Drawing.Size(126, 44);
            this.Player4ScoreboardName.TabIndex = 7;
            this.Player4ScoreboardName.Text = "Player 4";
            // 
            // Player3ScoreboardName
            // 
            this.Player3ScoreboardName.BackColor = System.Drawing.Color.PaleGreen;
            this.Player3ScoreboardName.Font = new System.Drawing.Font("Elephant", 14F);
            this.Player3ScoreboardName.Location = new System.Drawing.Point(1236, 177);
            this.Player3ScoreboardName.Name = "Player3ScoreboardName";
            this.Player3ScoreboardName.Size = new System.Drawing.Size(126, 44);
            this.Player3ScoreboardName.TabIndex = 8;
            this.Player3ScoreboardName.Text = "Player 3";
            // 
            // Player2ScoreboardName
            // 
            this.Player2ScoreboardName.BackColor = System.Drawing.Color.PaleGreen;
            this.Player2ScoreboardName.Font = new System.Drawing.Font("Elephant", 14F);
            this.Player2ScoreboardName.Location = new System.Drawing.Point(1236, 128);
            this.Player2ScoreboardName.Name = "Player2ScoreboardName";
            this.Player2ScoreboardName.Size = new System.Drawing.Size(126, 44);
            this.Player2ScoreboardName.TabIndex = 9;
            this.Player2ScoreboardName.Text = "Player 2";
            // 
            // Player1MoneyValue
            // 
            this.Player1MoneyValue.BackColor = System.Drawing.Color.PaleGreen;
            this.Player1MoneyValue.Font = new System.Drawing.Font("Elephant", 14F);
            this.Player1MoneyValue.Location = new System.Drawing.Point(1396, 77);
            this.Player1MoneyValue.Name = "Player1MoneyValue";
            this.Player1MoneyValue.Size = new System.Drawing.Size(94, 44);
            this.Player1MoneyValue.TabIndex = 13;
            this.Player1MoneyValue.Text = "0000";
            // 
            // Player4MoneyValue
            // 
            this.Player4MoneyValue.BackColor = System.Drawing.Color.PaleGreen;
            this.Player4MoneyValue.Font = new System.Drawing.Font("Elephant", 14F);
            this.Player4MoneyValue.Location = new System.Drawing.Point(1396, 228);
            this.Player4MoneyValue.Name = "Player4MoneyValue";
            this.Player4MoneyValue.Size = new System.Drawing.Size(94, 44);
            this.Player4MoneyValue.TabIndex = 14;
            this.Player4MoneyValue.Text = "0000";
            // 
            // Player3MoneyValue
            // 
            this.Player3MoneyValue.BackColor = System.Drawing.Color.PaleGreen;
            this.Player3MoneyValue.Font = new System.Drawing.Font("Elephant", 14F);
            this.Player3MoneyValue.Location = new System.Drawing.Point(1396, 177);
            this.Player3MoneyValue.Name = "Player3MoneyValue";
            this.Player3MoneyValue.Size = new System.Drawing.Size(94, 44);
            this.Player3MoneyValue.TabIndex = 15;
            this.Player3MoneyValue.Text = "0000";
            // 
            // Player2MoneyValue
            // 
            this.Player2MoneyValue.BackColor = System.Drawing.Color.PaleGreen;
            this.Player2MoneyValue.Font = new System.Drawing.Font("Elephant", 14F);
            this.Player2MoneyValue.Location = new System.Drawing.Point(1396, 128);
            this.Player2MoneyValue.Name = "Player2MoneyValue";
            this.Player2MoneyValue.Size = new System.Drawing.Size(94, 44);
            this.Player2MoneyValue.TabIndex = 16;
            this.Player2MoneyValue.Text = "0000";
            // 
            // CommunityChest
            // 
            this.CommunityChest.BackColor = System.Drawing.Color.Transparent;
            this.CommunityChest.BackgroundImage = global::monopoly1.Properties.Resources.rotated_community_chest;
            this.CommunityChest.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.CommunityChest.Location = new System.Drawing.Point(184, 137);
            this.CommunityChest.Name = "CommunityChest";
            this.CommunityChest.Size = new System.Drawing.Size(290, 274);
            this.CommunityChest.TabIndex = 17;
            this.CommunityChest.TabStop = false;
            // 
            // Chance
            // 
            this.Chance.BackColor = System.Drawing.Color.Transparent;
            this.Chance.BackgroundImage = global::monopoly1.Properties.Resources.rotated_chance;
            this.Chance.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Chance.Location = new System.Drawing.Point(712, 598);
            this.Chance.Name = "Chance";
            this.Chance.Size = new System.Drawing.Size(306, 272);
            this.Chance.TabIndex = 18;
            this.Chance.TabStop = false;
            // 
            // DicePictureBox1
            // 
            this.DicePictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.DicePictureBox1.Location = new System.Drawing.Point(1196, 372);
            this.DicePictureBox1.Name = "DicePictureBox1";
            this.DicePictureBox1.Size = new System.Drawing.Size(150, 149);
            this.DicePictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.DicePictureBox1.TabIndex = 24;
            this.DicePictureBox1.TabStop = false;
            // 
            // DicePictureBox2
            // 
            this.DicePictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.DicePictureBox2.Location = new System.Drawing.Point(1383, 372);
            this.DicePictureBox2.Name = "DicePictureBox2";
            this.DicePictureBox2.Size = new System.Drawing.Size(150, 149);
            this.DicePictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.DicePictureBox2.TabIndex = 25;
            this.DicePictureBox2.TabStop = false;
            // 
            // ThrowDiceButton
            // 
            this.ThrowDiceButton.BackColor = System.Drawing.Color.PaleGreen;
            this.ThrowDiceButton.Font = new System.Drawing.Font("Elephant", 18F);
            this.ThrowDiceButton.Location = new System.Drawing.Point(1217, 308);
            this.ThrowDiceButton.Name = "ThrowDiceButton";
            this.ThrowDiceButton.Size = new System.Drawing.Size(300, 58);
            this.ThrowDiceButton.TabIndex = 26;
            this.ThrowDiceButton.Text = "Throw Dice";
            this.ThrowDiceButton.UseVisualStyleBackColor = false;
            this.ThrowDiceButton.Click += new System.EventHandler(this.ThrowDiceButton_Click);
            // 
            // Dice1ValueLabel
            // 
            this.Dice1ValueLabel.AutoSize = true;
            this.Dice1ValueLabel.BackColor = System.Drawing.Color.PaleGreen;
            this.Dice1ValueLabel.Font = new System.Drawing.Font("Elephant", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Dice1ValueLabel.Location = new System.Drawing.Point(1222, 535);
            this.Dice1ValueLabel.Name = "Dice1ValueLabel";
            this.Dice1ValueLabel.Size = new System.Drawing.Size(105, 37);
            this.Dice1ValueLabel.TabIndex = 27;
            this.Dice1ValueLabel.Text = "Dice 1";
            this.Dice1ValueLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Dice2ValueLabel
            // 
            this.Dice2ValueLabel.AutoSize = true;
            this.Dice2ValueLabel.BackColor = System.Drawing.Color.PaleGreen;
            this.Dice2ValueLabel.Font = new System.Drawing.Font("Elephant", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Dice2ValueLabel.Location = new System.Drawing.Point(1407, 535);
            this.Dice2ValueLabel.Name = "Dice2ValueLabel";
            this.Dice2ValueLabel.Size = new System.Drawing.Size(110, 37);
            this.Dice2ValueLabel.TabIndex = 28;
            this.Dice2ValueLabel.Text = "Dice 2";
            this.Dice2ValueLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // TotalDiceValue
            // 
            this.TotalDiceValue.AutoSize = true;
            this.TotalDiceValue.BackColor = System.Drawing.Color.PaleGreen;
            this.TotalDiceValue.Font = new System.Drawing.Font("Elephant", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TotalDiceValue.Location = new System.Drawing.Point(1334, 586);
            this.TotalDiceValue.Name = "TotalDiceValue";
            this.TotalDiceValue.Size = new System.Drawing.Size(67, 37);
            this.TotalDiceValue.TabIndex = 29;
            this.TotalDiceValue.Text = "T V";
            this.TotalDiceValue.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // howManyPlayersTB
            // 
            this.howManyPlayersTB.BackColor = System.Drawing.Color.PaleGreen;
            this.howManyPlayersTB.Font = new System.Drawing.Font("Elephant", 9F);
            this.howManyPlayersTB.Location = new System.Drawing.Point(1494, 17);
            this.howManyPlayersTB.Multiline = true;
            this.howManyPlayersTB.Name = "howManyPlayersTB";
            this.howManyPlayersTB.Size = new System.Drawing.Size(194, 53);
            this.howManyPlayersTB.TabIndex = 30;
            this.howManyPlayersTB.Text = "How many players \r\nare playing?";
            this.howManyPlayersTB.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // startPlayer1
            // 
            this.startPlayer1.BackColor = System.Drawing.Color.PaleGreen;
            this.startPlayer1.Font = new System.Drawing.Font("Elephant", 12F);
            this.startPlayer1.Location = new System.Drawing.Point(1494, 77);
            this.startPlayer1.Name = "startPlayer1";
            this.startPlayer1.Size = new System.Drawing.Size(194, 45);
            this.startPlayer1.TabIndex = 31;
            this.startPlayer1.Text = "START!";
            this.startPlayer1.UseVisualStyleBackColor = false;
            this.startPlayer1.Click += new System.EventHandler(this.startPlayer1_Click);
            // 
            // startPlayer2
            // 
            this.startPlayer2.BackColor = System.Drawing.Color.PaleGreen;
            this.startPlayer2.Font = new System.Drawing.Font("Elephant", 12F);
            this.startPlayer2.Location = new System.Drawing.Point(1494, 128);
            this.startPlayer2.Name = "startPlayer2";
            this.startPlayer2.Size = new System.Drawing.Size(194, 45);
            this.startPlayer2.TabIndex = 32;
            this.startPlayer2.Text = "START!";
            this.startPlayer2.UseVisualStyleBackColor = false;
            this.startPlayer2.Click += new System.EventHandler(this.startPlayer2_Click);
            // 
            // startPlayer3
            // 
            this.startPlayer3.BackColor = System.Drawing.Color.PaleGreen;
            this.startPlayer3.Font = new System.Drawing.Font("Elephant", 12F);
            this.startPlayer3.Location = new System.Drawing.Point(1494, 177);
            this.startPlayer3.Name = "startPlayer3";
            this.startPlayer3.Size = new System.Drawing.Size(194, 45);
            this.startPlayer3.TabIndex = 33;
            this.startPlayer3.Text = "START!";
            this.startPlayer3.UseVisualStyleBackColor = false;
            this.startPlayer3.Click += new System.EventHandler(this.startPlayer3_Click);
            // 
            // startPlayer4
            // 
            this.startPlayer4.BackColor = System.Drawing.Color.PaleGreen;
            this.startPlayer4.Font = new System.Drawing.Font("Elephant", 12F);
            this.startPlayer4.Location = new System.Drawing.Point(1494, 228);
            this.startPlayer4.Name = "startPlayer4";
            this.startPlayer4.Size = new System.Drawing.Size(194, 45);
            this.startPlayer4.TabIndex = 34;
            this.startPlayer4.Text = "START!";
            this.startPlayer4.UseVisualStyleBackColor = false;
            this.startPlayer4.Click += new System.EventHandler(this.startPlayer4_Click);
            // 
            // startGameButton
            // 
            this.startGameButton.BackColor = System.Drawing.Color.PaleGreen;
            this.startGameButton.Font = new System.Drawing.Font("Elephant", 20F);
            this.startGameButton.Location = new System.Drawing.Point(1694, 17);
            this.startGameButton.Name = "startGameButton";
            this.startGameButton.Size = new System.Drawing.Size(204, 132);
            this.startGameButton.TabIndex = 35;
            this.startGameButton.Text = "START GAME!";
            this.startGameButton.UseVisualStyleBackColor = false;
            this.startGameButton.Click += new System.EventHandler(this.startGameButton_Click);
            // 
            // DebugLabel
            // 
            this.DebugLabel.AutoSize = true;
            this.DebugLabel.Location = new System.Drawing.Point(1210, 718);
            this.DebugLabel.Name = "DebugLabel";
            this.DebugLabel.Size = new System.Drawing.Size(57, 20);
            this.DebugLabel.TabIndex = 36;
            this.DebugLabel.Text = "Debug";
            // 
            // player1PositionDebug
            // 
            this.player1PositionDebug.AutoSize = true;
            this.player1PositionDebug.Location = new System.Drawing.Point(1192, 757);
            this.player1PositionDebug.Name = "player1PositionDebug";
            this.player1PositionDebug.Size = new System.Drawing.Size(164, 20);
            this.player1PositionDebug.TabIndex = 37;
            this.player1PositionDebug.Text = "player1PositionDebug";
            // 
            // player2PositionDebug
            // 
            this.player2PositionDebug.AutoSize = true;
            this.player2PositionDebug.Location = new System.Drawing.Point(1192, 789);
            this.player2PositionDebug.Name = "player2PositionDebug";
            this.player2PositionDebug.Size = new System.Drawing.Size(164, 20);
            this.player2PositionDebug.TabIndex = 38;
            this.player2PositionDebug.Text = "player2PositionDebug";
            // 
            // player3PositionDebug
            // 
            this.player3PositionDebug.AutoSize = true;
            this.player3PositionDebug.Location = new System.Drawing.Point(1192, 823);
            this.player3PositionDebug.Name = "player3PositionDebug";
            this.player3PositionDebug.Size = new System.Drawing.Size(164, 20);
            this.player3PositionDebug.TabIndex = 39;
            this.player3PositionDebug.Text = "player3PositionDebug";
            // 
            // player4PositionDebug
            // 
            this.player4PositionDebug.AutoSize = true;
            this.player4PositionDebug.Location = new System.Drawing.Point(1192, 852);
            this.player4PositionDebug.Name = "player4PositionDebug";
            this.player4PositionDebug.Size = new System.Drawing.Size(164, 20);
            this.player4PositionDebug.TabIndex = 40;
            this.player4PositionDebug.Text = "player4PositionDebug";
            // 
            // player1PositionTextBox
            // 
            this.player1PositionTextBox.Location = new System.Drawing.Point(1372, 754);
            this.player1PositionTextBox.Name = "player1PositionTextBox";
            this.player1PositionTextBox.Size = new System.Drawing.Size(166, 26);
            this.player1PositionTextBox.TabIndex = 41;
            // 
            // player4PositionTextBox
            // 
            this.player4PositionTextBox.Location = new System.Drawing.Point(1372, 852);
            this.player4PositionTextBox.Name = "player4PositionTextBox";
            this.player4PositionTextBox.Size = new System.Drawing.Size(161, 26);
            this.player4PositionTextBox.TabIndex = 42;
            // 
            // player3PositionTextBox
            // 
            this.player3PositionTextBox.Location = new System.Drawing.Point(1372, 818);
            this.player3PositionTextBox.Name = "player3PositionTextBox";
            this.player3PositionTextBox.Size = new System.Drawing.Size(161, 26);
            this.player3PositionTextBox.TabIndex = 43;
            // 
            // player2PositionTextBox
            // 
            this.player2PositionTextBox.Location = new System.Drawing.Point(1372, 786);
            this.player2PositionTextBox.Name = "player2PositionTextBox";
            this.player2PositionTextBox.Size = new System.Drawing.Size(161, 26);
            this.player2PositionTextBox.TabIndex = 44;
            // 
            // DebugPlayer1Move
            // 
            this.DebugPlayer1Move.Location = new System.Drawing.Point(1553, 754);
            this.DebugPlayer1Move.Name = "DebugPlayer1Move";
            this.DebugPlayer1Move.Size = new System.Drawing.Size(135, 26);
            this.DebugPlayer1Move.TabIndex = 45;
            this.DebugPlayer1Move.Text = "Player 1 Move";
            this.DebugPlayer1Move.UseVisualStyleBackColor = true;
            this.DebugPlayer1Move.Click += new System.EventHandler(this.DebugPlayer1Move_Click);
            // 
            // debugPlayer2Move
            // 
            this.debugPlayer2Move.Location = new System.Drawing.Point(1553, 788);
            this.debugPlayer2Move.Name = "debugPlayer2Move";
            this.debugPlayer2Move.Size = new System.Drawing.Size(135, 26);
            this.debugPlayer2Move.TabIndex = 46;
            this.debugPlayer2Move.Text = "Player 2 Move";
            this.debugPlayer2Move.UseVisualStyleBackColor = true;
            this.debugPlayer2Move.Click += new System.EventHandler(this.debugPlayer2Move_Click);
            // 
            // debugPlayer3Move
            // 
            this.debugPlayer3Move.Location = new System.Drawing.Point(1553, 820);
            this.debugPlayer3Move.Name = "debugPlayer3Move";
            this.debugPlayer3Move.Size = new System.Drawing.Size(135, 26);
            this.debugPlayer3Move.TabIndex = 47;
            this.debugPlayer3Move.Text = "Player 3 Move";
            this.debugPlayer3Move.UseVisualStyleBackColor = true;
            this.debugPlayer3Move.Click += new System.EventHandler(this.debugPlayer3Move_Click);
            // 
            // debugPlayer4Move
            // 
            this.debugPlayer4Move.Location = new System.Drawing.Point(1553, 849);
            this.debugPlayer4Move.Name = "debugPlayer4Move";
            this.debugPlayer4Move.Size = new System.Drawing.Size(135, 26);
            this.debugPlayer4Move.TabIndex = 48;
            this.debugPlayer4Move.Text = "Player 4 Move";
            this.debugPlayer4Move.UseVisualStyleBackColor = true;
            this.debugPlayer4Move.Click += new System.EventHandler(this.debugPlayer4Move_Click);
            // 
            // poundP1
            // 
            this.poundP1.BackColor = System.Drawing.Color.PaleGreen;
            this.poundP1.Font = new System.Drawing.Font("Elephant", 14F);
            this.poundP1.Location = new System.Drawing.Point(1363, 77);
            this.poundP1.Name = "poundP1";
            this.poundP1.Size = new System.Drawing.Size(33, 44);
            this.poundP1.TabIndex = 49;
            this.poundP1.Text = "£";
            // 
            // poundP4
            // 
            this.poundP4.BackColor = System.Drawing.Color.PaleGreen;
            this.poundP4.Font = new System.Drawing.Font("Elephant", 14F);
            this.poundP4.Location = new System.Drawing.Point(1363, 228);
            this.poundP4.Name = "poundP4";
            this.poundP4.Size = new System.Drawing.Size(33, 44);
            this.poundP4.TabIndex = 50;
            this.poundP4.Text = "£";
            // 
            // poundP3
            // 
            this.poundP3.BackColor = System.Drawing.Color.PaleGreen;
            this.poundP3.Font = new System.Drawing.Font("Elephant", 14F);
            this.poundP3.Location = new System.Drawing.Point(1363, 177);
            this.poundP3.Name = "poundP3";
            this.poundP3.Size = new System.Drawing.Size(33, 44);
            this.poundP3.TabIndex = 51;
            this.poundP3.Text = "£";
            // 
            // poundP2
            // 
            this.poundP2.BackColor = System.Drawing.Color.PaleGreen;
            this.poundP2.Font = new System.Drawing.Font("Elephant", 14F);
            this.poundP2.Location = new System.Drawing.Point(1363, 128);
            this.poundP2.Name = "poundP2";
            this.poundP2.Size = new System.Drawing.Size(33, 44);
            this.poundP2.TabIndex = 52;
            this.poundP2.Text = "£";
            // 
            // endTurn
            // 
            this.endTurn.BackColor = System.Drawing.Color.PaleGreen;
            this.endTurn.Font = new System.Drawing.Font("Elephant", 18F);
            this.endTurn.Location = new System.Drawing.Point(1229, 626);
            this.endTurn.Name = "endTurn";
            this.endTurn.Size = new System.Drawing.Size(241, 58);
            this.endTurn.TabIndex = 53;
            this.endTurn.Text = "End Turn";
            this.endTurn.UseVisualStyleBackColor = false;
            this.endTurn.Click += new System.EventHandler(this.endTurn_Click);
            // 
            // oldKentRoadOwnedP1
            // 
            this.oldKentRoadOwnedP1.BackColor = System.Drawing.Color.Red;
            this.oldKentRoadOwnedP1.BackgroundImage = global::monopoly1.Properties.Resources.car_transparent_monopoly;
            this.oldKentRoadOwnedP1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.oldKentRoadOwnedP1.Image = global::monopoly1.Properties.Resources.car_transparent_monopoly;
            this.oldKentRoadOwnedP1.Location = new System.Drawing.Point(926, 876);
            this.oldKentRoadOwnedP1.Name = "oldKentRoadOwnedP1";
            this.oldKentRoadOwnedP1.Size = new System.Drawing.Size(25, 25);
            this.oldKentRoadOwnedP1.TabIndex = 54;
            this.oldKentRoadOwnedP1.TabStop = false;
            this.oldKentRoadOwnedP1.Visible = false;
            // 
            // oldKentRoadOwnedP2
            // 
            this.oldKentRoadOwnedP2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.oldKentRoadOwnedP2.BackgroundImage = global::monopoly1.Properties.Resources.dog_transparent;
            this.oldKentRoadOwnedP2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.oldKentRoadOwnedP2.Location = new System.Drawing.Point(947, 876);
            this.oldKentRoadOwnedP2.Name = "oldKentRoadOwnedP2";
            this.oldKentRoadOwnedP2.Size = new System.Drawing.Size(25, 25);
            this.oldKentRoadOwnedP2.TabIndex = 55;
            this.oldKentRoadOwnedP2.TabStop = false;
            this.oldKentRoadOwnedP2.Visible = false;
            // 
            // oldKentRoadOwnedP3
            // 
            this.oldKentRoadOwnedP3.BackColor = System.Drawing.Color.Blue;
            this.oldKentRoadOwnedP3.BackgroundImage = global::monopoly1.Properties.Resources.hat_transparent_monopolu;
            this.oldKentRoadOwnedP3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.oldKentRoadOwnedP3.Location = new System.Drawing.Point(971, 876);
            this.oldKentRoadOwnedP3.Name = "oldKentRoadOwnedP3";
            this.oldKentRoadOwnedP3.Size = new System.Drawing.Size(25, 25);
            this.oldKentRoadOwnedP3.TabIndex = 56;
            this.oldKentRoadOwnedP3.TabStop = false;
            this.oldKentRoadOwnedP3.Visible = false;
            // 
            // oldKentRoadOwnedP4
            // 
            this.oldKentRoadOwnedP4.BackColor = System.Drawing.Color.Fuchsia;
            this.oldKentRoadOwnedP4.BackgroundImage = global::monopoly1.Properties.Resources.wheel_transparent_monopoly;
            this.oldKentRoadOwnedP4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.oldKentRoadOwnedP4.Location = new System.Drawing.Point(993, 876);
            this.oldKentRoadOwnedP4.Name = "oldKentRoadOwnedP4";
            this.oldKentRoadOwnedP4.Size = new System.Drawing.Size(25, 25);
            this.oldKentRoadOwnedP4.TabIndex = 57;
            this.oldKentRoadOwnedP4.TabStop = false;
            this.oldKentRoadOwnedP4.Visible = false;
            // 
            // whitechapelRoadOwnedP4
            // 
            this.whitechapelRoadOwnedP4.BackColor = System.Drawing.Color.Fuchsia;
            this.whitechapelRoadOwnedP4.BackgroundImage = global::monopoly1.Properties.Resources.wheel_transparent_monopoly;
            this.whitechapelRoadOwnedP4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.whitechapelRoadOwnedP4.Location = new System.Drawing.Point(808, 876);
            this.whitechapelRoadOwnedP4.Name = "whitechapelRoadOwnedP4";
            this.whitechapelRoadOwnedP4.Size = new System.Drawing.Size(25, 25);
            this.whitechapelRoadOwnedP4.TabIndex = 61;
            this.whitechapelRoadOwnedP4.TabStop = false;
            this.whitechapelRoadOwnedP4.Visible = false;
            // 
            // whitechapelRoadOwnedP3
            // 
            this.whitechapelRoadOwnedP3.BackColor = System.Drawing.Color.Blue;
            this.whitechapelRoadOwnedP3.BackgroundImage = global::monopoly1.Properties.Resources.hat_transparent_monopolu;
            this.whitechapelRoadOwnedP3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.whitechapelRoadOwnedP3.Location = new System.Drawing.Point(786, 876);
            this.whitechapelRoadOwnedP3.Name = "whitechapelRoadOwnedP3";
            this.whitechapelRoadOwnedP3.Size = new System.Drawing.Size(25, 25);
            this.whitechapelRoadOwnedP3.TabIndex = 60;
            this.whitechapelRoadOwnedP3.TabStop = false;
            this.whitechapelRoadOwnedP3.Visible = false;
            // 
            // whitechapelRoadOwnedP2
            // 
            this.whitechapelRoadOwnedP2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.whitechapelRoadOwnedP2.BackgroundImage = global::monopoly1.Properties.Resources.dog_transparent;
            this.whitechapelRoadOwnedP2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.whitechapelRoadOwnedP2.Location = new System.Drawing.Point(762, 876);
            this.whitechapelRoadOwnedP2.Name = "whitechapelRoadOwnedP2";
            this.whitechapelRoadOwnedP2.Size = new System.Drawing.Size(25, 25);
            this.whitechapelRoadOwnedP2.TabIndex = 59;
            this.whitechapelRoadOwnedP2.TabStop = false;
            this.whitechapelRoadOwnedP2.Visible = false;
            // 
            // whitechapelRoadOwnedP1
            // 
            this.whitechapelRoadOwnedP1.BackColor = System.Drawing.Color.Red;
            this.whitechapelRoadOwnedP1.BackgroundImage = global::monopoly1.Properties.Resources.car_transparent_monopoly;
            this.whitechapelRoadOwnedP1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.whitechapelRoadOwnedP1.Image = global::monopoly1.Properties.Resources.car_transparent_monopoly;
            this.whitechapelRoadOwnedP1.Location = new System.Drawing.Point(741, 876);
            this.whitechapelRoadOwnedP1.Name = "whitechapelRoadOwnedP1";
            this.whitechapelRoadOwnedP1.Size = new System.Drawing.Size(25, 25);
            this.whitechapelRoadOwnedP1.TabIndex = 58;
            this.whitechapelRoadOwnedP1.TabStop = false;
            this.whitechapelRoadOwnedP1.Visible = false;
            // 
            // kingsCrossOwnedP4
            // 
            this.kingsCrossOwnedP4.BackColor = System.Drawing.Color.Fuchsia;
            this.kingsCrossOwnedP4.BackgroundImage = global::monopoly1.Properties.Resources.wheel_transparent_monopoly;
            this.kingsCrossOwnedP4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.kingsCrossOwnedP4.Location = new System.Drawing.Point(622, 861);
            this.kingsCrossOwnedP4.Name = "kingsCrossOwnedP4";
            this.kingsCrossOwnedP4.Size = new System.Drawing.Size(25, 25);
            this.kingsCrossOwnedP4.TabIndex = 65;
            this.kingsCrossOwnedP4.TabStop = false;
            this.kingsCrossOwnedP4.Visible = false;
            // 
            // kingsCrossOwnedP3
            // 
            this.kingsCrossOwnedP3.BackColor = System.Drawing.Color.Blue;
            this.kingsCrossOwnedP3.BackgroundImage = global::monopoly1.Properties.Resources.hat_transparent_monopolu;
            this.kingsCrossOwnedP3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.kingsCrossOwnedP3.Location = new System.Drawing.Point(600, 861);
            this.kingsCrossOwnedP3.Name = "kingsCrossOwnedP3";
            this.kingsCrossOwnedP3.Size = new System.Drawing.Size(25, 25);
            this.kingsCrossOwnedP3.TabIndex = 64;
            this.kingsCrossOwnedP3.TabStop = false;
            this.kingsCrossOwnedP3.Visible = false;
            // 
            // kingsCrossOwnedP2
            // 
            this.kingsCrossOwnedP2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.kingsCrossOwnedP2.BackgroundImage = global::monopoly1.Properties.Resources.dog_transparent;
            this.kingsCrossOwnedP2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.kingsCrossOwnedP2.Location = new System.Drawing.Point(576, 861);
            this.kingsCrossOwnedP2.Name = "kingsCrossOwnedP2";
            this.kingsCrossOwnedP2.Size = new System.Drawing.Size(25, 25);
            this.kingsCrossOwnedP2.TabIndex = 63;
            this.kingsCrossOwnedP2.TabStop = false;
            this.kingsCrossOwnedP2.Visible = false;
            // 
            // kingsCrossOwnedP1
            // 
            this.kingsCrossOwnedP1.BackColor = System.Drawing.Color.Red;
            this.kingsCrossOwnedP1.BackgroundImage = global::monopoly1.Properties.Resources.car_transparent_monopoly;
            this.kingsCrossOwnedP1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.kingsCrossOwnedP1.Image = global::monopoly1.Properties.Resources.car_transparent_monopoly;
            this.kingsCrossOwnedP1.Location = new System.Drawing.Point(555, 861);
            this.kingsCrossOwnedP1.Name = "kingsCrossOwnedP1";
            this.kingsCrossOwnedP1.Size = new System.Drawing.Size(25, 25);
            this.kingsCrossOwnedP1.TabIndex = 62;
            this.kingsCrossOwnedP1.TabStop = false;
            this.kingsCrossOwnedP1.Visible = false;
            // 
            // angelIslingtonOwnedP4
            // 
            this.angelIslingtonOwnedP4.BackColor = System.Drawing.Color.Fuchsia;
            this.angelIslingtonOwnedP4.BackgroundImage = global::monopoly1.Properties.Resources.wheel_transparent_monopoly;
            this.angelIslingtonOwnedP4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.angelIslingtonOwnedP4.Location = new System.Drawing.Point(529, 876);
            this.angelIslingtonOwnedP4.Name = "angelIslingtonOwnedP4";
            this.angelIslingtonOwnedP4.Size = new System.Drawing.Size(25, 25);
            this.angelIslingtonOwnedP4.TabIndex = 69;
            this.angelIslingtonOwnedP4.TabStop = false;
            this.angelIslingtonOwnedP4.Visible = false;
            // 
            // angelIslingtonOwnedP3
            // 
            this.angelIslingtonOwnedP3.BackColor = System.Drawing.Color.Blue;
            this.angelIslingtonOwnedP3.BackgroundImage = global::monopoly1.Properties.Resources.hat_transparent_monopolu;
            this.angelIslingtonOwnedP3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.angelIslingtonOwnedP3.Location = new System.Drawing.Point(507, 876);
            this.angelIslingtonOwnedP3.Name = "angelIslingtonOwnedP3";
            this.angelIslingtonOwnedP3.Size = new System.Drawing.Size(25, 25);
            this.angelIslingtonOwnedP3.TabIndex = 68;
            this.angelIslingtonOwnedP3.TabStop = false;
            this.angelIslingtonOwnedP3.Visible = false;
            // 
            // angelIslingtonOwnedP2
            // 
            this.angelIslingtonOwnedP2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.angelIslingtonOwnedP2.BackgroundImage = global::monopoly1.Properties.Resources.dog_transparent;
            this.angelIslingtonOwnedP2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.angelIslingtonOwnedP2.Location = new System.Drawing.Point(483, 876);
            this.angelIslingtonOwnedP2.Name = "angelIslingtonOwnedP2";
            this.angelIslingtonOwnedP2.Size = new System.Drawing.Size(25, 25);
            this.angelIslingtonOwnedP2.TabIndex = 67;
            this.angelIslingtonOwnedP2.TabStop = false;
            this.angelIslingtonOwnedP2.Visible = false;
            // 
            // angelIslingtonOwnedP1
            // 
            this.angelIslingtonOwnedP1.BackColor = System.Drawing.Color.Red;
            this.angelIslingtonOwnedP1.BackgroundImage = global::monopoly1.Properties.Resources.car_transparent_monopoly;
            this.angelIslingtonOwnedP1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.angelIslingtonOwnedP1.Image = global::monopoly1.Properties.Resources.car_transparent_monopoly;
            this.angelIslingtonOwnedP1.Location = new System.Drawing.Point(462, 876);
            this.angelIslingtonOwnedP1.Name = "angelIslingtonOwnedP1";
            this.angelIslingtonOwnedP1.Size = new System.Drawing.Size(25, 25);
            this.angelIslingtonOwnedP1.TabIndex = 66;
            this.angelIslingtonOwnedP1.TabStop = false;
            this.angelIslingtonOwnedP1.Visible = false;
            // 
            // eustonRoadOwnedP4
            // 
            this.eustonRoadOwnedP4.BackColor = System.Drawing.Color.Fuchsia;
            this.eustonRoadOwnedP4.BackgroundImage = global::monopoly1.Properties.Resources.wheel_transparent_monopoly;
            this.eustonRoadOwnedP4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.eustonRoadOwnedP4.Location = new System.Drawing.Point(343, 876);
            this.eustonRoadOwnedP4.Name = "eustonRoadOwnedP4";
            this.eustonRoadOwnedP4.Size = new System.Drawing.Size(25, 25);
            this.eustonRoadOwnedP4.TabIndex = 73;
            this.eustonRoadOwnedP4.TabStop = false;
            this.eustonRoadOwnedP4.Visible = false;
            // 
            // eustonRoadOwnedP3
            // 
            this.eustonRoadOwnedP3.BackColor = System.Drawing.Color.Blue;
            this.eustonRoadOwnedP3.BackgroundImage = global::monopoly1.Properties.Resources.hat_transparent_monopolu;
            this.eustonRoadOwnedP3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.eustonRoadOwnedP3.Location = new System.Drawing.Point(321, 876);
            this.eustonRoadOwnedP3.Name = "eustonRoadOwnedP3";
            this.eustonRoadOwnedP3.Size = new System.Drawing.Size(25, 25);
            this.eustonRoadOwnedP3.TabIndex = 72;
            this.eustonRoadOwnedP3.TabStop = false;
            this.eustonRoadOwnedP3.Visible = false;
            // 
            // eustonRoadOwnedP2
            // 
            this.eustonRoadOwnedP2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.eustonRoadOwnedP2.BackgroundImage = global::monopoly1.Properties.Resources.dog_transparent;
            this.eustonRoadOwnedP2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.eustonRoadOwnedP2.Location = new System.Drawing.Point(297, 876);
            this.eustonRoadOwnedP2.Name = "eustonRoadOwnedP2";
            this.eustonRoadOwnedP2.Size = new System.Drawing.Size(25, 25);
            this.eustonRoadOwnedP2.TabIndex = 71;
            this.eustonRoadOwnedP2.TabStop = false;
            this.eustonRoadOwnedP2.Visible = false;
            // 
            // eustonRoadOwnedP1
            // 
            this.eustonRoadOwnedP1.BackColor = System.Drawing.Color.Red;
            this.eustonRoadOwnedP1.BackgroundImage = global::monopoly1.Properties.Resources.car_transparent_monopoly;
            this.eustonRoadOwnedP1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.eustonRoadOwnedP1.Image = global::monopoly1.Properties.Resources.car_transparent_monopoly;
            this.eustonRoadOwnedP1.Location = new System.Drawing.Point(276, 876);
            this.eustonRoadOwnedP1.Name = "eustonRoadOwnedP1";
            this.eustonRoadOwnedP1.Size = new System.Drawing.Size(25, 25);
            this.eustonRoadOwnedP1.TabIndex = 70;
            this.eustonRoadOwnedP1.TabStop = false;
            this.eustonRoadOwnedP1.Visible = false;
            // 
            // pentonvilleRoadOwnedP4
            // 
            this.pentonvilleRoadOwnedP4.BackColor = System.Drawing.Color.Fuchsia;
            this.pentonvilleRoadOwnedP4.BackgroundImage = global::monopoly1.Properties.Resources.wheel_transparent_monopoly;
            this.pentonvilleRoadOwnedP4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pentonvilleRoadOwnedP4.Location = new System.Drawing.Point(251, 876);
            this.pentonvilleRoadOwnedP4.Name = "pentonvilleRoadOwnedP4";
            this.pentonvilleRoadOwnedP4.Size = new System.Drawing.Size(25, 25);
            this.pentonvilleRoadOwnedP4.TabIndex = 77;
            this.pentonvilleRoadOwnedP4.TabStop = false;
            this.pentonvilleRoadOwnedP4.Visible = false;
            // 
            // pentonvilleRoadOwnedP3
            // 
            this.pentonvilleRoadOwnedP3.BackColor = System.Drawing.Color.Blue;
            this.pentonvilleRoadOwnedP3.BackgroundImage = global::monopoly1.Properties.Resources.hat_transparent_monopolu;
            this.pentonvilleRoadOwnedP3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pentonvilleRoadOwnedP3.Location = new System.Drawing.Point(229, 876);
            this.pentonvilleRoadOwnedP3.Name = "pentonvilleRoadOwnedP3";
            this.pentonvilleRoadOwnedP3.Size = new System.Drawing.Size(25, 25);
            this.pentonvilleRoadOwnedP3.TabIndex = 76;
            this.pentonvilleRoadOwnedP3.TabStop = false;
            this.pentonvilleRoadOwnedP3.Visible = false;
            // 
            // pentonvilleRoadOwnedP2
            // 
            this.pentonvilleRoadOwnedP2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.pentonvilleRoadOwnedP2.BackgroundImage = global::monopoly1.Properties.Resources.dog_transparent;
            this.pentonvilleRoadOwnedP2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pentonvilleRoadOwnedP2.Location = new System.Drawing.Point(205, 876);
            this.pentonvilleRoadOwnedP2.Name = "pentonvilleRoadOwnedP2";
            this.pentonvilleRoadOwnedP2.Size = new System.Drawing.Size(25, 25);
            this.pentonvilleRoadOwnedP2.TabIndex = 75;
            this.pentonvilleRoadOwnedP2.TabStop = false;
            this.pentonvilleRoadOwnedP2.Visible = false;
            // 
            // pentonvilleRoadOwnedP1
            // 
            this.pentonvilleRoadOwnedP1.BackColor = System.Drawing.Color.Red;
            this.pentonvilleRoadOwnedP1.BackgroundImage = global::monopoly1.Properties.Resources.car_transparent_monopoly;
            this.pentonvilleRoadOwnedP1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pentonvilleRoadOwnedP1.Image = global::monopoly1.Properties.Resources.car_transparent_monopoly;
            this.pentonvilleRoadOwnedP1.Location = new System.Drawing.Point(184, 876);
            this.pentonvilleRoadOwnedP1.Name = "pentonvilleRoadOwnedP1";
            this.pentonvilleRoadOwnedP1.Size = new System.Drawing.Size(25, 25);
            this.pentonvilleRoadOwnedP1.TabIndex = 74;
            this.pentonvilleRoadOwnedP1.TabStop = false;
            this.pentonvilleRoadOwnedP1.Visible = false;
            // 
            // pallMallOwnedP4
            // 
            this.pallMallOwnedP4.BackColor = System.Drawing.Color.Fuchsia;
            this.pallMallOwnedP4.BackgroundImage = global::monopoly1.Properties.Resources.wheel_transparent_monopoly;
            this.pallMallOwnedP4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pallMallOwnedP4.Location = new System.Drawing.Point(153, 792);
            this.pallMallOwnedP4.Name = "pallMallOwnedP4";
            this.pallMallOwnedP4.Size = new System.Drawing.Size(25, 25);
            this.pallMallOwnedP4.TabIndex = 81;
            this.pallMallOwnedP4.TabStop = false;
            this.pallMallOwnedP4.Visible = false;
            // 
            // pallMallOwnedP3
            // 
            this.pallMallOwnedP3.BackColor = System.Drawing.Color.Blue;
            this.pallMallOwnedP3.BackgroundImage = global::monopoly1.Properties.Resources.hat_transparent_monopolu;
            this.pallMallOwnedP3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pallMallOwnedP3.Location = new System.Drawing.Point(153, 812);
            this.pallMallOwnedP3.Name = "pallMallOwnedP3";
            this.pallMallOwnedP3.Size = new System.Drawing.Size(25, 25);
            this.pallMallOwnedP3.TabIndex = 80;
            this.pallMallOwnedP3.TabStop = false;
            this.pallMallOwnedP3.Visible = false;
            // 
            // pallMallOwnedP2
            // 
            this.pallMallOwnedP2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.pallMallOwnedP2.BackgroundImage = global::monopoly1.Properties.Resources.dog_transparent;
            this.pallMallOwnedP2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pallMallOwnedP2.Location = new System.Drawing.Point(153, 835);
            this.pallMallOwnedP2.Name = "pallMallOwnedP2";
            this.pallMallOwnedP2.Size = new System.Drawing.Size(25, 25);
            this.pallMallOwnedP2.TabIndex = 79;
            this.pallMallOwnedP2.TabStop = false;
            this.pallMallOwnedP2.Visible = false;
            // 
            // pallMallOwnedP1
            // 
            this.pallMallOwnedP1.BackColor = System.Drawing.Color.Red;
            this.pallMallOwnedP1.BackgroundImage = global::monopoly1.Properties.Resources.car_transparent_monopoly;
            this.pallMallOwnedP1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pallMallOwnedP1.Image = global::monopoly1.Properties.Resources.car_transparent_monopoly;
            this.pallMallOwnedP1.Location = new System.Drawing.Point(153, 854);
            this.pallMallOwnedP1.Name = "pallMallOwnedP1";
            this.pallMallOwnedP1.Size = new System.Drawing.Size(25, 25);
            this.pallMallOwnedP1.TabIndex = 78;
            this.pallMallOwnedP1.TabStop = false;
            this.pallMallOwnedP1.Visible = false;
            // 
            // whitehallOwnedP4
            // 
            this.whitehallOwnedP4.BackColor = System.Drawing.Color.Fuchsia;
            this.whitehallOwnedP4.BackgroundImage = global::monopoly1.Properties.Resources.wheel_transparent_monopoly;
            this.whitehallOwnedP4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.whitehallOwnedP4.Location = new System.Drawing.Point(153, 629);
            this.whitehallOwnedP4.Name = "whitehallOwnedP4";
            this.whitehallOwnedP4.Size = new System.Drawing.Size(25, 25);
            this.whitehallOwnedP4.TabIndex = 85;
            this.whitehallOwnedP4.TabStop = false;
            this.whitehallOwnedP4.Visible = false;
            // 
            // whitehallOwnedP3
            // 
            this.whitehallOwnedP3.BackColor = System.Drawing.Color.Blue;
            this.whitehallOwnedP3.BackgroundImage = global::monopoly1.Properties.Resources.hat_transparent_monopolu;
            this.whitehallOwnedP3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.whitehallOwnedP3.Location = new System.Drawing.Point(153, 649);
            this.whitehallOwnedP3.Name = "whitehallOwnedP3";
            this.whitehallOwnedP3.Size = new System.Drawing.Size(25, 25);
            this.whitehallOwnedP3.TabIndex = 84;
            this.whitehallOwnedP3.TabStop = false;
            this.whitehallOwnedP3.Visible = false;
            // 
            // whitehallOwnedP2
            // 
            this.whitehallOwnedP2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.whitehallOwnedP2.BackgroundImage = global::monopoly1.Properties.Resources.dog_transparent;
            this.whitehallOwnedP2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.whitehallOwnedP2.Location = new System.Drawing.Point(153, 672);
            this.whitehallOwnedP2.Name = "whitehallOwnedP2";
            this.whitehallOwnedP2.Size = new System.Drawing.Size(25, 25);
            this.whitehallOwnedP2.TabIndex = 83;
            this.whitehallOwnedP2.TabStop = false;
            this.whitehallOwnedP2.Visible = false;
            // 
            // whitehallOwnedP1
            // 
            this.whitehallOwnedP1.BackColor = System.Drawing.Color.Red;
            this.whitehallOwnedP1.BackgroundImage = global::monopoly1.Properties.Resources.car_transparent_monopoly;
            this.whitehallOwnedP1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.whitehallOwnedP1.Image = global::monopoly1.Properties.Resources.car_transparent_monopoly;
            this.whitehallOwnedP1.Location = new System.Drawing.Point(153, 691);
            this.whitehallOwnedP1.Name = "whitehallOwnedP1";
            this.whitehallOwnedP1.Size = new System.Drawing.Size(25, 25);
            this.whitehallOwnedP1.TabIndex = 82;
            this.whitehallOwnedP1.TabStop = false;
            this.whitehallOwnedP1.Visible = false;
            // 
            // northumberlandOwnedP4
            // 
            this.northumberlandOwnedP4.BackColor = System.Drawing.Color.Fuchsia;
            this.northumberlandOwnedP4.BackgroundImage = global::monopoly1.Properties.Resources.wheel_transparent_monopoly;
            this.northumberlandOwnedP4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.northumberlandOwnedP4.Location = new System.Drawing.Point(153, 544);
            this.northumberlandOwnedP4.Name = "northumberlandOwnedP4";
            this.northumberlandOwnedP4.Size = new System.Drawing.Size(25, 25);
            this.northumberlandOwnedP4.TabIndex = 89;
            this.northumberlandOwnedP4.TabStop = false;
            this.northumberlandOwnedP4.Visible = false;
            // 
            // northumberlandOwnedP3
            // 
            this.northumberlandOwnedP3.BackColor = System.Drawing.Color.Blue;
            this.northumberlandOwnedP3.BackgroundImage = global::monopoly1.Properties.Resources.hat_transparent_monopolu;
            this.northumberlandOwnedP3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.northumberlandOwnedP3.Location = new System.Drawing.Point(153, 564);
            this.northumberlandOwnedP3.Name = "northumberlandOwnedP3";
            this.northumberlandOwnedP3.Size = new System.Drawing.Size(25, 25);
            this.northumberlandOwnedP3.TabIndex = 88;
            this.northumberlandOwnedP3.TabStop = false;
            this.northumberlandOwnedP3.Visible = false;
            // 
            // northumberlandOwnedP2
            // 
            this.northumberlandOwnedP2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.northumberlandOwnedP2.BackgroundImage = global::monopoly1.Properties.Resources.dog_transparent;
            this.northumberlandOwnedP2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.northumberlandOwnedP2.Location = new System.Drawing.Point(153, 587);
            this.northumberlandOwnedP2.Name = "northumberlandOwnedP2";
            this.northumberlandOwnedP2.Size = new System.Drawing.Size(25, 25);
            this.northumberlandOwnedP2.TabIndex = 87;
            this.northumberlandOwnedP2.TabStop = false;
            this.northumberlandOwnedP2.Visible = false;
            // 
            // northumberlandOwnedP1
            // 
            this.northumberlandOwnedP1.BackColor = System.Drawing.Color.Red;
            this.northumberlandOwnedP1.BackgroundImage = global::monopoly1.Properties.Resources.car_transparent_monopoly;
            this.northumberlandOwnedP1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.northumberlandOwnedP1.Image = global::monopoly1.Properties.Resources.car_transparent_monopoly;
            this.northumberlandOwnedP1.Location = new System.Drawing.Point(153, 606);
            this.northumberlandOwnedP1.Name = "northumberlandOwnedP1";
            this.northumberlandOwnedP1.Size = new System.Drawing.Size(25, 25);
            this.northumberlandOwnedP1.TabIndex = 86;
            this.northumberlandOwnedP1.TabStop = false;
            this.northumberlandOwnedP1.Visible = false;
            // 
            // maryleboneStationOwnedP4
            // 
            this.maryleboneStationOwnedP4.BackColor = System.Drawing.Color.Fuchsia;
            this.maryleboneStationOwnedP4.BackgroundImage = global::monopoly1.Properties.Resources.wheel_transparent_monopoly;
            this.maryleboneStationOwnedP4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.maryleboneStationOwnedP4.Location = new System.Drawing.Point(171, 460);
            this.maryleboneStationOwnedP4.Name = "maryleboneStationOwnedP4";
            this.maryleboneStationOwnedP4.Size = new System.Drawing.Size(25, 25);
            this.maryleboneStationOwnedP4.TabIndex = 93;
            this.maryleboneStationOwnedP4.TabStop = false;
            this.maryleboneStationOwnedP4.Visible = false;
            // 
            // maryleboneStationOwnedP3
            // 
            this.maryleboneStationOwnedP3.BackColor = System.Drawing.Color.Blue;
            this.maryleboneStationOwnedP3.BackgroundImage = global::monopoly1.Properties.Resources.hat_transparent_monopolu;
            this.maryleboneStationOwnedP3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.maryleboneStationOwnedP3.Location = new System.Drawing.Point(171, 480);
            this.maryleboneStationOwnedP3.Name = "maryleboneStationOwnedP3";
            this.maryleboneStationOwnedP3.Size = new System.Drawing.Size(25, 25);
            this.maryleboneStationOwnedP3.TabIndex = 92;
            this.maryleboneStationOwnedP3.TabStop = false;
            this.maryleboneStationOwnedP3.Visible = false;
            // 
            // maryleboneStationOwnedP2
            // 
            this.maryleboneStationOwnedP2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.maryleboneStationOwnedP2.BackgroundImage = global::monopoly1.Properties.Resources.dog_transparent;
            this.maryleboneStationOwnedP2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.maryleboneStationOwnedP2.Location = new System.Drawing.Point(171, 503);
            this.maryleboneStationOwnedP2.Name = "maryleboneStationOwnedP2";
            this.maryleboneStationOwnedP2.Size = new System.Drawing.Size(25, 25);
            this.maryleboneStationOwnedP2.TabIndex = 91;
            this.maryleboneStationOwnedP2.TabStop = false;
            this.maryleboneStationOwnedP2.Visible = false;
            // 
            // maryleboneStationOwnedP1
            // 
            this.maryleboneStationOwnedP1.BackColor = System.Drawing.Color.Red;
            this.maryleboneStationOwnedP1.BackgroundImage = global::monopoly1.Properties.Resources.car_transparent_monopoly;
            this.maryleboneStationOwnedP1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.maryleboneStationOwnedP1.Image = global::monopoly1.Properties.Resources.car_transparent_monopoly;
            this.maryleboneStationOwnedP1.Location = new System.Drawing.Point(171, 522);
            this.maryleboneStationOwnedP1.Name = "maryleboneStationOwnedP1";
            this.maryleboneStationOwnedP1.Size = new System.Drawing.Size(25, 25);
            this.maryleboneStationOwnedP1.TabIndex = 90;
            this.maryleboneStationOwnedP1.TabStop = false;
            this.maryleboneStationOwnedP1.Visible = false;
            // 
            // bowStreetOwnedP4
            // 
            this.bowStreetOwnedP4.BackColor = System.Drawing.Color.Fuchsia;
            this.bowStreetOwnedP4.BackgroundImage = global::monopoly1.Properties.Resources.wheel_transparent_monopoly;
            this.bowStreetOwnedP4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bowStreetOwnedP4.Location = new System.Drawing.Point(153, 378);
            this.bowStreetOwnedP4.Name = "bowStreetOwnedP4";
            this.bowStreetOwnedP4.Size = new System.Drawing.Size(25, 25);
            this.bowStreetOwnedP4.TabIndex = 97;
            this.bowStreetOwnedP4.TabStop = false;
            this.bowStreetOwnedP4.Visible = false;
            // 
            // bowStreetOwnedP3
            // 
            this.bowStreetOwnedP3.BackColor = System.Drawing.Color.Blue;
            this.bowStreetOwnedP3.BackgroundImage = global::monopoly1.Properties.Resources.hat_transparent_monopolu;
            this.bowStreetOwnedP3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bowStreetOwnedP3.Location = new System.Drawing.Point(153, 398);
            this.bowStreetOwnedP3.Name = "bowStreetOwnedP3";
            this.bowStreetOwnedP3.Size = new System.Drawing.Size(25, 25);
            this.bowStreetOwnedP3.TabIndex = 96;
            this.bowStreetOwnedP3.TabStop = false;
            this.bowStreetOwnedP3.Visible = false;
            // 
            // bowStreetOwnedP2
            // 
            this.bowStreetOwnedP2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.bowStreetOwnedP2.BackgroundImage = global::monopoly1.Properties.Resources.dog_transparent;
            this.bowStreetOwnedP2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bowStreetOwnedP2.Location = new System.Drawing.Point(153, 421);
            this.bowStreetOwnedP2.Name = "bowStreetOwnedP2";
            this.bowStreetOwnedP2.Size = new System.Drawing.Size(25, 25);
            this.bowStreetOwnedP2.TabIndex = 95;
            this.bowStreetOwnedP2.TabStop = false;
            this.bowStreetOwnedP2.Visible = false;
            // 
            // bowStreetOwnedP1
            // 
            this.bowStreetOwnedP1.BackColor = System.Drawing.Color.Red;
            this.bowStreetOwnedP1.BackgroundImage = global::monopoly1.Properties.Resources.car_transparent_monopoly;
            this.bowStreetOwnedP1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bowStreetOwnedP1.Image = global::monopoly1.Properties.Resources.car_transparent_monopoly;
            this.bowStreetOwnedP1.Location = new System.Drawing.Point(153, 440);
            this.bowStreetOwnedP1.Name = "bowStreetOwnedP1";
            this.bowStreetOwnedP1.Size = new System.Drawing.Size(25, 25);
            this.bowStreetOwnedP1.TabIndex = 94;
            this.bowStreetOwnedP1.TabStop = false;
            this.bowStreetOwnedP1.Visible = false;
            // 
            // marlboroughStreetOwnedP4
            // 
            this.marlboroughStreetOwnedP4.BackColor = System.Drawing.Color.Fuchsia;
            this.marlboroughStreetOwnedP4.BackgroundImage = global::monopoly1.Properties.Resources.wheel_transparent_monopoly;
            this.marlboroughStreetOwnedP4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.marlboroughStreetOwnedP4.Location = new System.Drawing.Point(153, 215);
            this.marlboroughStreetOwnedP4.Name = "marlboroughStreetOwnedP4";
            this.marlboroughStreetOwnedP4.Size = new System.Drawing.Size(25, 25);
            this.marlboroughStreetOwnedP4.TabIndex = 101;
            this.marlboroughStreetOwnedP4.TabStop = false;
            this.marlboroughStreetOwnedP4.Visible = false;
            // 
            // marlboroughStreetOwnedP3
            // 
            this.marlboroughStreetOwnedP3.BackColor = System.Drawing.Color.Blue;
            this.marlboroughStreetOwnedP3.BackgroundImage = global::monopoly1.Properties.Resources.hat_transparent_monopolu;
            this.marlboroughStreetOwnedP3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.marlboroughStreetOwnedP3.Location = new System.Drawing.Point(153, 235);
            this.marlboroughStreetOwnedP3.Name = "marlboroughStreetOwnedP3";
            this.marlboroughStreetOwnedP3.Size = new System.Drawing.Size(25, 25);
            this.marlboroughStreetOwnedP3.TabIndex = 100;
            this.marlboroughStreetOwnedP3.TabStop = false;
            this.marlboroughStreetOwnedP3.Visible = false;
            // 
            // marlboroughStreetOwnedP2
            // 
            this.marlboroughStreetOwnedP2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.marlboroughStreetOwnedP2.BackgroundImage = global::monopoly1.Properties.Resources.dog_transparent;
            this.marlboroughStreetOwnedP2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.marlboroughStreetOwnedP2.Location = new System.Drawing.Point(153, 258);
            this.marlboroughStreetOwnedP2.Name = "marlboroughStreetOwnedP2";
            this.marlboroughStreetOwnedP2.Size = new System.Drawing.Size(25, 25);
            this.marlboroughStreetOwnedP2.TabIndex = 99;
            this.marlboroughStreetOwnedP2.TabStop = false;
            this.marlboroughStreetOwnedP2.Visible = false;
            // 
            // marlboroughStreetOwnedP1
            // 
            this.marlboroughStreetOwnedP1.BackColor = System.Drawing.Color.Red;
            this.marlboroughStreetOwnedP1.BackgroundImage = global::monopoly1.Properties.Resources.car_transparent_monopoly;
            this.marlboroughStreetOwnedP1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.marlboroughStreetOwnedP1.Image = global::monopoly1.Properties.Resources.car_transparent_monopoly;
            this.marlboroughStreetOwnedP1.Location = new System.Drawing.Point(153, 277);
            this.marlboroughStreetOwnedP1.Name = "marlboroughStreetOwnedP1";
            this.marlboroughStreetOwnedP1.Size = new System.Drawing.Size(25, 25);
            this.marlboroughStreetOwnedP1.TabIndex = 98;
            this.marlboroughStreetOwnedP1.TabStop = false;
            this.marlboroughStreetOwnedP1.Visible = false;
            // 
            // vineStreetOwnedP4
            // 
            this.vineStreetOwnedP4.BackColor = System.Drawing.Color.Fuchsia;
            this.vineStreetOwnedP4.BackgroundImage = global::monopoly1.Properties.Resources.wheel_transparent_monopoly;
            this.vineStreetOwnedP4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.vineStreetOwnedP4.Location = new System.Drawing.Point(153, 130);
            this.vineStreetOwnedP4.Name = "vineStreetOwnedP4";
            this.vineStreetOwnedP4.Size = new System.Drawing.Size(25, 25);
            this.vineStreetOwnedP4.TabIndex = 105;
            this.vineStreetOwnedP4.TabStop = false;
            this.vineStreetOwnedP4.Visible = false;
            // 
            // vineStreetOwnedP3
            // 
            this.vineStreetOwnedP3.BackColor = System.Drawing.Color.Blue;
            this.vineStreetOwnedP3.BackgroundImage = global::monopoly1.Properties.Resources.hat_transparent_monopolu;
            this.vineStreetOwnedP3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.vineStreetOwnedP3.Location = new System.Drawing.Point(153, 150);
            this.vineStreetOwnedP3.Name = "vineStreetOwnedP3";
            this.vineStreetOwnedP3.Size = new System.Drawing.Size(25, 25);
            this.vineStreetOwnedP3.TabIndex = 104;
            this.vineStreetOwnedP3.TabStop = false;
            this.vineStreetOwnedP3.Visible = false;
            // 
            // vineStreetOwnedP2
            // 
            this.vineStreetOwnedP2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.vineStreetOwnedP2.BackgroundImage = global::monopoly1.Properties.Resources.dog_transparent;
            this.vineStreetOwnedP2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.vineStreetOwnedP2.Location = new System.Drawing.Point(153, 173);
            this.vineStreetOwnedP2.Name = "vineStreetOwnedP2";
            this.vineStreetOwnedP2.Size = new System.Drawing.Size(25, 25);
            this.vineStreetOwnedP2.TabIndex = 103;
            this.vineStreetOwnedP2.TabStop = false;
            this.vineStreetOwnedP2.Visible = false;
            // 
            // vineStreetOwnedP1
            // 
            this.vineStreetOwnedP1.BackColor = System.Drawing.Color.Red;
            this.vineStreetOwnedP1.BackgroundImage = global::monopoly1.Properties.Resources.car_transparent_monopoly;
            this.vineStreetOwnedP1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.vineStreetOwnedP1.Image = global::monopoly1.Properties.Resources.car_transparent_monopoly;
            this.vineStreetOwnedP1.Location = new System.Drawing.Point(153, 192);
            this.vineStreetOwnedP1.Name = "vineStreetOwnedP1";
            this.vineStreetOwnedP1.Size = new System.Drawing.Size(25, 25);
            this.vineStreetOwnedP1.TabIndex = 102;
            this.vineStreetOwnedP1.TabStop = false;
            this.vineStreetOwnedP1.Visible = false;
            // 
            // electricCompanyOwnedP4
            // 
            this.electricCompanyOwnedP4.BackColor = System.Drawing.Color.Fuchsia;
            this.electricCompanyOwnedP4.BackgroundImage = global::monopoly1.Properties.Resources.wheel_transparent_monopoly;
            this.electricCompanyOwnedP4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.electricCompanyOwnedP4.Location = new System.Drawing.Point(171, 708);
            this.electricCompanyOwnedP4.Name = "electricCompanyOwnedP4";
            this.electricCompanyOwnedP4.Size = new System.Drawing.Size(25, 25);
            this.electricCompanyOwnedP4.TabIndex = 109;
            this.electricCompanyOwnedP4.TabStop = false;
            this.electricCompanyOwnedP4.Visible = false;
            // 
            // electricCompanyOwnedP3
            // 
            this.electricCompanyOwnedP3.BackColor = System.Drawing.Color.Blue;
            this.electricCompanyOwnedP3.BackgroundImage = global::monopoly1.Properties.Resources.hat_transparent_monopolu;
            this.electricCompanyOwnedP3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.electricCompanyOwnedP3.Location = new System.Drawing.Point(171, 728);
            this.electricCompanyOwnedP3.Name = "electricCompanyOwnedP3";
            this.electricCompanyOwnedP3.Size = new System.Drawing.Size(25, 25);
            this.electricCompanyOwnedP3.TabIndex = 108;
            this.electricCompanyOwnedP3.TabStop = false;
            this.electricCompanyOwnedP3.Visible = false;
            // 
            // electricCompanyOwnedP2
            // 
            this.electricCompanyOwnedP2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.electricCompanyOwnedP2.BackgroundImage = global::monopoly1.Properties.Resources.dog_transparent;
            this.electricCompanyOwnedP2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.electricCompanyOwnedP2.Location = new System.Drawing.Point(171, 751);
            this.electricCompanyOwnedP2.Name = "electricCompanyOwnedP2";
            this.electricCompanyOwnedP2.Size = new System.Drawing.Size(25, 25);
            this.electricCompanyOwnedP2.TabIndex = 107;
            this.electricCompanyOwnedP2.TabStop = false;
            this.electricCompanyOwnedP2.Visible = false;
            // 
            // electricCompanyOwnedP1
            // 
            this.electricCompanyOwnedP1.BackColor = System.Drawing.Color.Red;
            this.electricCompanyOwnedP1.BackgroundImage = global::monopoly1.Properties.Resources.car_transparent_monopoly;
            this.electricCompanyOwnedP1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.electricCompanyOwnedP1.Image = global::monopoly1.Properties.Resources.car_transparent_monopoly;
            this.electricCompanyOwnedP1.Location = new System.Drawing.Point(171, 770);
            this.electricCompanyOwnedP1.Name = "electricCompanyOwnedP1";
            this.electricCompanyOwnedP1.Size = new System.Drawing.Size(25, 25);
            this.electricCompanyOwnedP1.TabIndex = 106;
            this.electricCompanyOwnedP1.TabStop = false;
            this.electricCompanyOwnedP1.Visible = false;
            // 
            // strandOwnedP4
            // 
            this.strandOwnedP4.BackColor = System.Drawing.Color.Fuchsia;
            this.strandOwnedP4.BackgroundImage = global::monopoly1.Properties.Resources.wheel_transparent_monopoly;
            this.strandOwnedP4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.strandOwnedP4.Location = new System.Drawing.Point(251, 106);
            this.strandOwnedP4.Name = "strandOwnedP4";
            this.strandOwnedP4.Size = new System.Drawing.Size(25, 25);
            this.strandOwnedP4.TabIndex = 113;
            this.strandOwnedP4.TabStop = false;
            this.strandOwnedP4.Visible = false;
            // 
            // strandOwnedP3
            // 
            this.strandOwnedP3.BackColor = System.Drawing.Color.Blue;
            this.strandOwnedP3.BackgroundImage = global::monopoly1.Properties.Resources.hat_transparent_monopolu;
            this.strandOwnedP3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.strandOwnedP3.Location = new System.Drawing.Point(229, 106);
            this.strandOwnedP3.Name = "strandOwnedP3";
            this.strandOwnedP3.Size = new System.Drawing.Size(25, 25);
            this.strandOwnedP3.TabIndex = 112;
            this.strandOwnedP3.TabStop = false;
            this.strandOwnedP3.Visible = false;
            // 
            // strandOwnedP2
            // 
            this.strandOwnedP2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.strandOwnedP2.BackgroundImage = global::monopoly1.Properties.Resources.dog_transparent;
            this.strandOwnedP2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.strandOwnedP2.Location = new System.Drawing.Point(205, 106);
            this.strandOwnedP2.Name = "strandOwnedP2";
            this.strandOwnedP2.Size = new System.Drawing.Size(25, 25);
            this.strandOwnedP2.TabIndex = 111;
            this.strandOwnedP2.TabStop = false;
            this.strandOwnedP2.Visible = false;
            // 
            // strandOwnedP1
            // 
            this.strandOwnedP1.BackColor = System.Drawing.Color.Red;
            this.strandOwnedP1.BackgroundImage = global::monopoly1.Properties.Resources.car_transparent_monopoly;
            this.strandOwnedP1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.strandOwnedP1.Image = global::monopoly1.Properties.Resources.car_transparent_monopoly;
            this.strandOwnedP1.Location = new System.Drawing.Point(184, 106);
            this.strandOwnedP1.Name = "strandOwnedP1";
            this.strandOwnedP1.Size = new System.Drawing.Size(25, 25);
            this.strandOwnedP1.TabIndex = 110;
            this.strandOwnedP1.TabStop = false;
            this.strandOwnedP1.Visible = false;
            // 
            // FleetStreetOwnedP4
            // 
            this.FleetStreetOwnedP4.BackColor = System.Drawing.Color.Fuchsia;
            this.FleetStreetOwnedP4.BackgroundImage = global::monopoly1.Properties.Resources.wheel_transparent_monopoly;
            this.FleetStreetOwnedP4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.FleetStreetOwnedP4.Location = new System.Drawing.Point(435, 106);
            this.FleetStreetOwnedP4.Name = "FleetStreetOwnedP4";
            this.FleetStreetOwnedP4.Size = new System.Drawing.Size(25, 25);
            this.FleetStreetOwnedP4.TabIndex = 117;
            this.FleetStreetOwnedP4.TabStop = false;
            this.FleetStreetOwnedP4.Visible = false;
            // 
            // FleetStreetOwnedP3
            // 
            this.FleetStreetOwnedP3.BackColor = System.Drawing.Color.Blue;
            this.FleetStreetOwnedP3.BackgroundImage = global::monopoly1.Properties.Resources.hat_transparent_monopolu;
            this.FleetStreetOwnedP3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.FleetStreetOwnedP3.Location = new System.Drawing.Point(413, 106);
            this.FleetStreetOwnedP3.Name = "FleetStreetOwnedP3";
            this.FleetStreetOwnedP3.Size = new System.Drawing.Size(25, 25);
            this.FleetStreetOwnedP3.TabIndex = 116;
            this.FleetStreetOwnedP3.TabStop = false;
            this.FleetStreetOwnedP3.Visible = false;
            // 
            // FleetStreetOwnedP2
            // 
            this.FleetStreetOwnedP2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.FleetStreetOwnedP2.BackgroundImage = global::monopoly1.Properties.Resources.dog_transparent;
            this.FleetStreetOwnedP2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.FleetStreetOwnedP2.Location = new System.Drawing.Point(389, 106);
            this.FleetStreetOwnedP2.Name = "FleetStreetOwnedP2";
            this.FleetStreetOwnedP2.Size = new System.Drawing.Size(25, 25);
            this.FleetStreetOwnedP2.TabIndex = 115;
            this.FleetStreetOwnedP2.TabStop = false;
            this.FleetStreetOwnedP2.Visible = false;
            // 
            // FleetStreetOwnedP1
            // 
            this.FleetStreetOwnedP1.BackColor = System.Drawing.Color.Red;
            this.FleetStreetOwnedP1.BackgroundImage = global::monopoly1.Properties.Resources.car_transparent_monopoly;
            this.FleetStreetOwnedP1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.FleetStreetOwnedP1.Image = global::monopoly1.Properties.Resources.car_transparent_monopoly;
            this.FleetStreetOwnedP1.Location = new System.Drawing.Point(368, 106);
            this.FleetStreetOwnedP1.Name = "FleetStreetOwnedP1";
            this.FleetStreetOwnedP1.Size = new System.Drawing.Size(25, 25);
            this.FleetStreetOwnedP1.TabIndex = 114;
            this.FleetStreetOwnedP1.TabStop = false;
            this.FleetStreetOwnedP1.Visible = false;
            // 
            // trafalgarSquareOwnedP4
            // 
            this.trafalgarSquareOwnedP4.BackColor = System.Drawing.Color.Fuchsia;
            this.trafalgarSquareOwnedP4.BackgroundImage = global::monopoly1.Properties.Resources.wheel_transparent_monopoly;
            this.trafalgarSquareOwnedP4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.trafalgarSquareOwnedP4.Location = new System.Drawing.Point(529, 106);
            this.trafalgarSquareOwnedP4.Name = "trafalgarSquareOwnedP4";
            this.trafalgarSquareOwnedP4.Size = new System.Drawing.Size(25, 25);
            this.trafalgarSquareOwnedP4.TabIndex = 121;
            this.trafalgarSquareOwnedP4.TabStop = false;
            this.trafalgarSquareOwnedP4.Visible = false;
            // 
            // trafalgarSquareOwnedP3
            // 
            this.trafalgarSquareOwnedP3.BackColor = System.Drawing.Color.Blue;
            this.trafalgarSquareOwnedP3.BackgroundImage = global::monopoly1.Properties.Resources.hat_transparent_monopolu;
            this.trafalgarSquareOwnedP3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.trafalgarSquareOwnedP3.Location = new System.Drawing.Point(507, 106);
            this.trafalgarSquareOwnedP3.Name = "trafalgarSquareOwnedP3";
            this.trafalgarSquareOwnedP3.Size = new System.Drawing.Size(25, 25);
            this.trafalgarSquareOwnedP3.TabIndex = 120;
            this.trafalgarSquareOwnedP3.TabStop = false;
            this.trafalgarSquareOwnedP3.Visible = false;
            // 
            // trafalgarSquareOwnedP2
            // 
            this.trafalgarSquareOwnedP2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.trafalgarSquareOwnedP2.BackgroundImage = global::monopoly1.Properties.Resources.dog_transparent;
            this.trafalgarSquareOwnedP2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.trafalgarSquareOwnedP2.Location = new System.Drawing.Point(483, 106);
            this.trafalgarSquareOwnedP2.Name = "trafalgarSquareOwnedP2";
            this.trafalgarSquareOwnedP2.Size = new System.Drawing.Size(25, 25);
            this.trafalgarSquareOwnedP2.TabIndex = 119;
            this.trafalgarSquareOwnedP2.TabStop = false;
            this.trafalgarSquareOwnedP2.Visible = false;
            // 
            // trafalgarSquareOwnedP1
            // 
            this.trafalgarSquareOwnedP1.BackColor = System.Drawing.Color.Red;
            this.trafalgarSquareOwnedP1.BackgroundImage = global::monopoly1.Properties.Resources.car_transparent_monopoly;
            this.trafalgarSquareOwnedP1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.trafalgarSquareOwnedP1.Image = global::monopoly1.Properties.Resources.car_transparent_monopoly;
            this.trafalgarSquareOwnedP1.Location = new System.Drawing.Point(462, 106);
            this.trafalgarSquareOwnedP1.Name = "trafalgarSquareOwnedP1";
            this.trafalgarSquareOwnedP1.Size = new System.Drawing.Size(25, 25);
            this.trafalgarSquareOwnedP1.TabIndex = 118;
            this.trafalgarSquareOwnedP1.TabStop = false;
            this.trafalgarSquareOwnedP1.Visible = false;
            // 
            // leicesterSquareOwnedP4
            // 
            this.leicesterSquareOwnedP4.BackColor = System.Drawing.Color.Fuchsia;
            this.leicesterSquareOwnedP4.BackgroundImage = global::monopoly1.Properties.Resources.wheel_transparent_monopoly;
            this.leicesterSquareOwnedP4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.leicesterSquareOwnedP4.Location = new System.Drawing.Point(715, 106);
            this.leicesterSquareOwnedP4.Name = "leicesterSquareOwnedP4";
            this.leicesterSquareOwnedP4.Size = new System.Drawing.Size(25, 25);
            this.leicesterSquareOwnedP4.TabIndex = 125;
            this.leicesterSquareOwnedP4.TabStop = false;
            this.leicesterSquareOwnedP4.Visible = false;
            // 
            // leicesterSquareOwnedP3
            // 
            this.leicesterSquareOwnedP3.BackColor = System.Drawing.Color.Blue;
            this.leicesterSquareOwnedP3.BackgroundImage = global::monopoly1.Properties.Resources.hat_transparent_monopolu;
            this.leicesterSquareOwnedP3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.leicesterSquareOwnedP3.Location = new System.Drawing.Point(693, 106);
            this.leicesterSquareOwnedP3.Name = "leicesterSquareOwnedP3";
            this.leicesterSquareOwnedP3.Size = new System.Drawing.Size(25, 25);
            this.leicesterSquareOwnedP3.TabIndex = 124;
            this.leicesterSquareOwnedP3.TabStop = false;
            this.leicesterSquareOwnedP3.Visible = false;
            // 
            // leicesterSquareOwnedP2
            // 
            this.leicesterSquareOwnedP2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.leicesterSquareOwnedP2.BackgroundImage = global::monopoly1.Properties.Resources.dog_transparent;
            this.leicesterSquareOwnedP2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.leicesterSquareOwnedP2.Location = new System.Drawing.Point(669, 106);
            this.leicesterSquareOwnedP2.Name = "leicesterSquareOwnedP2";
            this.leicesterSquareOwnedP2.Size = new System.Drawing.Size(25, 25);
            this.leicesterSquareOwnedP2.TabIndex = 123;
            this.leicesterSquareOwnedP2.TabStop = false;
            this.leicesterSquareOwnedP2.Visible = false;
            // 
            // leicesterSquareOwnedP1
            // 
            this.leicesterSquareOwnedP1.BackColor = System.Drawing.Color.Red;
            this.leicesterSquareOwnedP1.BackgroundImage = global::monopoly1.Properties.Resources.car_transparent_monopoly;
            this.leicesterSquareOwnedP1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.leicesterSquareOwnedP1.Image = global::monopoly1.Properties.Resources.car_transparent_monopoly;
            this.leicesterSquareOwnedP1.Location = new System.Drawing.Point(648, 106);
            this.leicesterSquareOwnedP1.Name = "leicesterSquareOwnedP1";
            this.leicesterSquareOwnedP1.Size = new System.Drawing.Size(25, 25);
            this.leicesterSquareOwnedP1.TabIndex = 122;
            this.leicesterSquareOwnedP1.TabStop = false;
            this.leicesterSquareOwnedP1.Visible = false;
            // 
            // coventryStreetOwnedP4
            // 
            this.coventryStreetOwnedP4.BackColor = System.Drawing.Color.Fuchsia;
            this.coventryStreetOwnedP4.BackgroundImage = global::monopoly1.Properties.Resources.wheel_transparent_monopoly;
            this.coventryStreetOwnedP4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.coventryStreetOwnedP4.Location = new System.Drawing.Point(808, 106);
            this.coventryStreetOwnedP4.Name = "coventryStreetOwnedP4";
            this.coventryStreetOwnedP4.Size = new System.Drawing.Size(25, 25);
            this.coventryStreetOwnedP4.TabIndex = 129;
            this.coventryStreetOwnedP4.TabStop = false;
            this.coventryStreetOwnedP4.Visible = false;
            // 
            // coventryStreetOwnedP3
            // 
            this.coventryStreetOwnedP3.BackColor = System.Drawing.Color.Blue;
            this.coventryStreetOwnedP3.BackgroundImage = global::monopoly1.Properties.Resources.hat_transparent_monopolu;
            this.coventryStreetOwnedP3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.coventryStreetOwnedP3.Location = new System.Drawing.Point(786, 106);
            this.coventryStreetOwnedP3.Name = "coventryStreetOwnedP3";
            this.coventryStreetOwnedP3.Size = new System.Drawing.Size(25, 25);
            this.coventryStreetOwnedP3.TabIndex = 128;
            this.coventryStreetOwnedP3.TabStop = false;
            this.coventryStreetOwnedP3.Visible = false;
            // 
            // coventryStreetOwnedP2
            // 
            this.coventryStreetOwnedP2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.coventryStreetOwnedP2.BackgroundImage = global::monopoly1.Properties.Resources.dog_transparent;
            this.coventryStreetOwnedP2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.coventryStreetOwnedP2.Location = new System.Drawing.Point(762, 106);
            this.coventryStreetOwnedP2.Name = "coventryStreetOwnedP2";
            this.coventryStreetOwnedP2.Size = new System.Drawing.Size(25, 25);
            this.coventryStreetOwnedP2.TabIndex = 127;
            this.coventryStreetOwnedP2.TabStop = false;
            this.coventryStreetOwnedP2.Visible = false;
            // 
            // coventryStreetOwnedP1
            // 
            this.coventryStreetOwnedP1.BackColor = System.Drawing.Color.Red;
            this.coventryStreetOwnedP1.BackgroundImage = global::monopoly1.Properties.Resources.car_transparent_monopoly;
            this.coventryStreetOwnedP1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.coventryStreetOwnedP1.Image = global::monopoly1.Properties.Resources.car_transparent_monopoly;
            this.coventryStreetOwnedP1.Location = new System.Drawing.Point(741, 106);
            this.coventryStreetOwnedP1.Name = "coventryStreetOwnedP1";
            this.coventryStreetOwnedP1.Size = new System.Drawing.Size(25, 25);
            this.coventryStreetOwnedP1.TabIndex = 126;
            this.coventryStreetOwnedP1.TabStop = false;
            this.coventryStreetOwnedP1.Visible = false;
            // 
            // piccadillyOwnedP4
            // 
            this.piccadillyOwnedP4.BackColor = System.Drawing.Color.Fuchsia;
            this.piccadillyOwnedP4.BackgroundImage = global::monopoly1.Properties.Resources.wheel_transparent_monopoly;
            this.piccadillyOwnedP4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.piccadillyOwnedP4.Location = new System.Drawing.Point(993, 106);
            this.piccadillyOwnedP4.Name = "piccadillyOwnedP4";
            this.piccadillyOwnedP4.Size = new System.Drawing.Size(25, 25);
            this.piccadillyOwnedP4.TabIndex = 133;
            this.piccadillyOwnedP4.TabStop = false;
            this.piccadillyOwnedP4.Visible = false;
            // 
            // piccadillyOwnedP3
            // 
            this.piccadillyOwnedP3.BackColor = System.Drawing.Color.Blue;
            this.piccadillyOwnedP3.BackgroundImage = global::monopoly1.Properties.Resources.hat_transparent_monopolu;
            this.piccadillyOwnedP3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.piccadillyOwnedP3.Location = new System.Drawing.Point(971, 106);
            this.piccadillyOwnedP3.Name = "piccadillyOwnedP3";
            this.piccadillyOwnedP3.Size = new System.Drawing.Size(25, 25);
            this.piccadillyOwnedP3.TabIndex = 132;
            this.piccadillyOwnedP3.TabStop = false;
            this.piccadillyOwnedP3.Visible = false;
            // 
            // piccadillyOwnedP2
            // 
            this.piccadillyOwnedP2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.piccadillyOwnedP2.BackgroundImage = global::monopoly1.Properties.Resources.dog_transparent;
            this.piccadillyOwnedP2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.piccadillyOwnedP2.Location = new System.Drawing.Point(947, 106);
            this.piccadillyOwnedP2.Name = "piccadillyOwnedP2";
            this.piccadillyOwnedP2.Size = new System.Drawing.Size(25, 25);
            this.piccadillyOwnedP2.TabIndex = 131;
            this.piccadillyOwnedP2.TabStop = false;
            this.piccadillyOwnedP2.Visible = false;
            // 
            // piccadillyOwnedP1
            // 
            this.piccadillyOwnedP1.BackColor = System.Drawing.Color.Red;
            this.piccadillyOwnedP1.BackgroundImage = global::monopoly1.Properties.Resources.car_transparent_monopoly;
            this.piccadillyOwnedP1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.piccadillyOwnedP1.Image = global::monopoly1.Properties.Resources.car_transparent_monopoly;
            this.piccadillyOwnedP1.Location = new System.Drawing.Point(926, 106);
            this.piccadillyOwnedP1.Name = "piccadillyOwnedP1";
            this.piccadillyOwnedP1.Size = new System.Drawing.Size(25, 25);
            this.piccadillyOwnedP1.TabIndex = 130;
            this.piccadillyOwnedP1.TabStop = false;
            this.piccadillyOwnedP1.Visible = false;
            // 
            // fenchurchStationOwnedP4
            // 
            this.fenchurchStationOwnedP4.BackColor = System.Drawing.Color.Fuchsia;
            this.fenchurchStationOwnedP4.BackgroundImage = global::monopoly1.Properties.Resources.wheel_transparent_monopoly;
            this.fenchurchStationOwnedP4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.fenchurchStationOwnedP4.Location = new System.Drawing.Point(622, 124);
            this.fenchurchStationOwnedP4.Name = "fenchurchStationOwnedP4";
            this.fenchurchStationOwnedP4.Size = new System.Drawing.Size(25, 25);
            this.fenchurchStationOwnedP4.TabIndex = 137;
            this.fenchurchStationOwnedP4.TabStop = false;
            this.fenchurchStationOwnedP4.Visible = false;
            // 
            // fenchurchStationOwnedP3
            // 
            this.fenchurchStationOwnedP3.BackColor = System.Drawing.Color.Blue;
            this.fenchurchStationOwnedP3.BackgroundImage = global::monopoly1.Properties.Resources.hat_transparent_monopolu;
            this.fenchurchStationOwnedP3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.fenchurchStationOwnedP3.Location = new System.Drawing.Point(600, 124);
            this.fenchurchStationOwnedP3.Name = "fenchurchStationOwnedP3";
            this.fenchurchStationOwnedP3.Size = new System.Drawing.Size(25, 25);
            this.fenchurchStationOwnedP3.TabIndex = 136;
            this.fenchurchStationOwnedP3.TabStop = false;
            this.fenchurchStationOwnedP3.Visible = false;
            // 
            // fenchurchStationOwnedP2
            // 
            this.fenchurchStationOwnedP2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.fenchurchStationOwnedP2.BackgroundImage = global::monopoly1.Properties.Resources.dog_transparent;
            this.fenchurchStationOwnedP2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.fenchurchStationOwnedP2.Location = new System.Drawing.Point(576, 124);
            this.fenchurchStationOwnedP2.Name = "fenchurchStationOwnedP2";
            this.fenchurchStationOwnedP2.Size = new System.Drawing.Size(25, 25);
            this.fenchurchStationOwnedP2.TabIndex = 135;
            this.fenchurchStationOwnedP2.TabStop = false;
            this.fenchurchStationOwnedP2.Visible = false;
            // 
            // fenchurchStationOwnedP1
            // 
            this.fenchurchStationOwnedP1.BackColor = System.Drawing.Color.Red;
            this.fenchurchStationOwnedP1.BackgroundImage = global::monopoly1.Properties.Resources.car_transparent_monopoly;
            this.fenchurchStationOwnedP1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.fenchurchStationOwnedP1.Image = global::monopoly1.Properties.Resources.car_transparent_monopoly;
            this.fenchurchStationOwnedP1.Location = new System.Drawing.Point(555, 124);
            this.fenchurchStationOwnedP1.Name = "fenchurchStationOwnedP1";
            this.fenchurchStationOwnedP1.Size = new System.Drawing.Size(25, 25);
            this.fenchurchStationOwnedP1.TabIndex = 134;
            this.fenchurchStationOwnedP1.TabStop = false;
            this.fenchurchStationOwnedP1.Visible = false;
            // 
            // waterworksOwnedP4
            // 
            this.waterworksOwnedP4.BackColor = System.Drawing.Color.Fuchsia;
            this.waterworksOwnedP4.BackgroundImage = global::monopoly1.Properties.Resources.wheel_transparent_monopoly;
            this.waterworksOwnedP4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.waterworksOwnedP4.Location = new System.Drawing.Point(901, 122);
            this.waterworksOwnedP4.Name = "waterworksOwnedP4";
            this.waterworksOwnedP4.Size = new System.Drawing.Size(25, 25);
            this.waterworksOwnedP4.TabIndex = 141;
            this.waterworksOwnedP4.TabStop = false;
            this.waterworksOwnedP4.Visible = false;
            // 
            // waterworksOwnedP3
            // 
            this.waterworksOwnedP3.BackColor = System.Drawing.Color.Blue;
            this.waterworksOwnedP3.BackgroundImage = global::monopoly1.Properties.Resources.hat_transparent_monopolu;
            this.waterworksOwnedP3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.waterworksOwnedP3.Location = new System.Drawing.Point(879, 122);
            this.waterworksOwnedP3.Name = "waterworksOwnedP3";
            this.waterworksOwnedP3.Size = new System.Drawing.Size(25, 25);
            this.waterworksOwnedP3.TabIndex = 140;
            this.waterworksOwnedP3.TabStop = false;
            this.waterworksOwnedP3.Visible = false;
            // 
            // waterworksOwnedP2
            // 
            this.waterworksOwnedP2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.waterworksOwnedP2.BackgroundImage = global::monopoly1.Properties.Resources.dog_transparent;
            this.waterworksOwnedP2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.waterworksOwnedP2.Location = new System.Drawing.Point(855, 122);
            this.waterworksOwnedP2.Name = "waterworksOwnedP2";
            this.waterworksOwnedP2.Size = new System.Drawing.Size(25, 25);
            this.waterworksOwnedP2.TabIndex = 139;
            this.waterworksOwnedP2.TabStop = false;
            this.waterworksOwnedP2.Visible = false;
            // 
            // waterworksOwnedP1
            // 
            this.waterworksOwnedP1.BackColor = System.Drawing.Color.Red;
            this.waterworksOwnedP1.BackgroundImage = global::monopoly1.Properties.Resources.car_transparent_monopoly;
            this.waterworksOwnedP1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.waterworksOwnedP1.Image = global::monopoly1.Properties.Resources.car_transparent_monopoly;
            this.waterworksOwnedP1.Location = new System.Drawing.Point(834, 122);
            this.waterworksOwnedP1.Name = "waterworksOwnedP1";
            this.waterworksOwnedP1.Size = new System.Drawing.Size(25, 25);
            this.waterworksOwnedP1.TabIndex = 138;
            this.waterworksOwnedP1.TabStop = false;
            this.waterworksOwnedP1.Visible = false;
            // 
            // regentStreetOwnedP4
            // 
            this.regentStreetOwnedP4.BackColor = System.Drawing.Color.Fuchsia;
            this.regentStreetOwnedP4.BackgroundImage = global::monopoly1.Properties.Resources.wheel_transparent_monopoly;
            this.regentStreetOwnedP4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.regentStreetOwnedP4.Location = new System.Drawing.Point(1024, 130);
            this.regentStreetOwnedP4.Name = "regentStreetOwnedP4";
            this.regentStreetOwnedP4.Size = new System.Drawing.Size(25, 25);
            this.regentStreetOwnedP4.TabIndex = 145;
            this.regentStreetOwnedP4.TabStop = false;
            this.regentStreetOwnedP4.Visible = false;
            // 
            // regentStreetOwnedP3
            // 
            this.regentStreetOwnedP3.BackColor = System.Drawing.Color.Blue;
            this.regentStreetOwnedP3.BackgroundImage = global::monopoly1.Properties.Resources.hat_transparent_monopolu;
            this.regentStreetOwnedP3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.regentStreetOwnedP3.Location = new System.Drawing.Point(1024, 150);
            this.regentStreetOwnedP3.Name = "regentStreetOwnedP3";
            this.regentStreetOwnedP3.Size = new System.Drawing.Size(25, 25);
            this.regentStreetOwnedP3.TabIndex = 144;
            this.regentStreetOwnedP3.TabStop = false;
            this.regentStreetOwnedP3.Visible = false;
            // 
            // regentStreetOwnedP2
            // 
            this.regentStreetOwnedP2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.regentStreetOwnedP2.BackgroundImage = global::monopoly1.Properties.Resources.dog_transparent;
            this.regentStreetOwnedP2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.regentStreetOwnedP2.Location = new System.Drawing.Point(1024, 173);
            this.regentStreetOwnedP2.Name = "regentStreetOwnedP2";
            this.regentStreetOwnedP2.Size = new System.Drawing.Size(25, 25);
            this.regentStreetOwnedP2.TabIndex = 143;
            this.regentStreetOwnedP2.TabStop = false;
            this.regentStreetOwnedP2.Visible = false;
            // 
            // regentStreetOwnedP1
            // 
            this.regentStreetOwnedP1.BackColor = System.Drawing.Color.Red;
            this.regentStreetOwnedP1.BackgroundImage = global::monopoly1.Properties.Resources.car_transparent_monopoly;
            this.regentStreetOwnedP1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.regentStreetOwnedP1.Image = global::monopoly1.Properties.Resources.car_transparent_monopoly;
            this.regentStreetOwnedP1.Location = new System.Drawing.Point(1024, 192);
            this.regentStreetOwnedP1.Name = "regentStreetOwnedP1";
            this.regentStreetOwnedP1.Size = new System.Drawing.Size(25, 25);
            this.regentStreetOwnedP1.TabIndex = 142;
            this.regentStreetOwnedP1.TabStop = false;
            this.regentStreetOwnedP1.Visible = false;
            // 
            // oxfordStreetOwnedP4
            // 
            this.oxfordStreetOwnedP4.BackColor = System.Drawing.Color.Fuchsia;
            this.oxfordStreetOwnedP4.BackgroundImage = global::monopoly1.Properties.Resources.wheel_transparent_monopoly;
            this.oxfordStreetOwnedP4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.oxfordStreetOwnedP4.Location = new System.Drawing.Point(1024, 215);
            this.oxfordStreetOwnedP4.Name = "oxfordStreetOwnedP4";
            this.oxfordStreetOwnedP4.Size = new System.Drawing.Size(25, 25);
            this.oxfordStreetOwnedP4.TabIndex = 149;
            this.oxfordStreetOwnedP4.TabStop = false;
            this.oxfordStreetOwnedP4.Visible = false;
            // 
            // oxfordStreetOwnedP3
            // 
            this.oxfordStreetOwnedP3.BackColor = System.Drawing.Color.Blue;
            this.oxfordStreetOwnedP3.BackgroundImage = global::monopoly1.Properties.Resources.hat_transparent_monopolu;
            this.oxfordStreetOwnedP3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.oxfordStreetOwnedP3.Location = new System.Drawing.Point(1024, 235);
            this.oxfordStreetOwnedP3.Name = "oxfordStreetOwnedP3";
            this.oxfordStreetOwnedP3.Size = new System.Drawing.Size(25, 25);
            this.oxfordStreetOwnedP3.TabIndex = 148;
            this.oxfordStreetOwnedP3.TabStop = false;
            this.oxfordStreetOwnedP3.Visible = false;
            // 
            // oxfordStreetOwnedP2
            // 
            this.oxfordStreetOwnedP2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.oxfordStreetOwnedP2.BackgroundImage = global::monopoly1.Properties.Resources.dog_transparent;
            this.oxfordStreetOwnedP2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.oxfordStreetOwnedP2.Location = new System.Drawing.Point(1024, 258);
            this.oxfordStreetOwnedP2.Name = "oxfordStreetOwnedP2";
            this.oxfordStreetOwnedP2.Size = new System.Drawing.Size(25, 25);
            this.oxfordStreetOwnedP2.TabIndex = 147;
            this.oxfordStreetOwnedP2.TabStop = false;
            this.oxfordStreetOwnedP2.Visible = false;
            // 
            // oxfordStreetOwnedP1
            // 
            this.oxfordStreetOwnedP1.BackColor = System.Drawing.Color.Red;
            this.oxfordStreetOwnedP1.BackgroundImage = global::monopoly1.Properties.Resources.car_transparent_monopoly;
            this.oxfordStreetOwnedP1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.oxfordStreetOwnedP1.Image = global::monopoly1.Properties.Resources.car_transparent_monopoly;
            this.oxfordStreetOwnedP1.Location = new System.Drawing.Point(1024, 277);
            this.oxfordStreetOwnedP1.Name = "oxfordStreetOwnedP1";
            this.oxfordStreetOwnedP1.Size = new System.Drawing.Size(25, 25);
            this.oxfordStreetOwnedP1.TabIndex = 146;
            this.oxfordStreetOwnedP1.TabStop = false;
            this.oxfordStreetOwnedP1.Visible = false;
            // 
            // bondStreetOwnedP4
            // 
            this.bondStreetOwnedP4.BackColor = System.Drawing.Color.Fuchsia;
            this.bondStreetOwnedP4.BackgroundImage = global::monopoly1.Properties.Resources.wheel_transparent_monopoly;
            this.bondStreetOwnedP4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bondStreetOwnedP4.Location = new System.Drawing.Point(1024, 378);
            this.bondStreetOwnedP4.Name = "bondStreetOwnedP4";
            this.bondStreetOwnedP4.Size = new System.Drawing.Size(25, 25);
            this.bondStreetOwnedP4.TabIndex = 153;
            this.bondStreetOwnedP4.TabStop = false;
            this.bondStreetOwnedP4.Visible = false;
            // 
            // bondStreetOwnedP3
            // 
            this.bondStreetOwnedP3.BackColor = System.Drawing.Color.Blue;
            this.bondStreetOwnedP3.BackgroundImage = global::monopoly1.Properties.Resources.hat_transparent_monopolu;
            this.bondStreetOwnedP3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bondStreetOwnedP3.Location = new System.Drawing.Point(1024, 398);
            this.bondStreetOwnedP3.Name = "bondStreetOwnedP3";
            this.bondStreetOwnedP3.Size = new System.Drawing.Size(25, 25);
            this.bondStreetOwnedP3.TabIndex = 152;
            this.bondStreetOwnedP3.TabStop = false;
            this.bondStreetOwnedP3.Visible = false;
            // 
            // bondStreetOwnedP2
            // 
            this.bondStreetOwnedP2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.bondStreetOwnedP2.BackgroundImage = global::monopoly1.Properties.Resources.dog_transparent;
            this.bondStreetOwnedP2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bondStreetOwnedP2.Location = new System.Drawing.Point(1024, 421);
            this.bondStreetOwnedP2.Name = "bondStreetOwnedP2";
            this.bondStreetOwnedP2.Size = new System.Drawing.Size(25, 25);
            this.bondStreetOwnedP2.TabIndex = 151;
            this.bondStreetOwnedP2.TabStop = false;
            this.bondStreetOwnedP2.Visible = false;
            // 
            // bondStreetOwnedP1
            // 
            this.bondStreetOwnedP1.BackColor = System.Drawing.Color.Red;
            this.bondStreetOwnedP1.BackgroundImage = global::monopoly1.Properties.Resources.car_transparent_monopoly;
            this.bondStreetOwnedP1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bondStreetOwnedP1.Image = global::monopoly1.Properties.Resources.car_transparent_monopoly;
            this.bondStreetOwnedP1.Location = new System.Drawing.Point(1024, 440);
            this.bondStreetOwnedP1.Name = "bondStreetOwnedP1";
            this.bondStreetOwnedP1.Size = new System.Drawing.Size(25, 25);
            this.bondStreetOwnedP1.TabIndex = 150;
            this.bondStreetOwnedP1.TabStop = false;
            this.bondStreetOwnedP1.Visible = false;
            // 
            // livStreetStationOwnedP4
            // 
            this.livStreetStationOwnedP4.BackColor = System.Drawing.Color.Fuchsia;
            this.livStreetStationOwnedP4.BackgroundImage = global::monopoly1.Properties.Resources.wheel_transparent_monopoly;
            this.livStreetStationOwnedP4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.livStreetStationOwnedP4.Location = new System.Drawing.Point(1004, 460);
            this.livStreetStationOwnedP4.Name = "livStreetStationOwnedP4";
            this.livStreetStationOwnedP4.Size = new System.Drawing.Size(25, 25);
            this.livStreetStationOwnedP4.TabIndex = 157;
            this.livStreetStationOwnedP4.TabStop = false;
            this.livStreetStationOwnedP4.Visible = false;
            // 
            // livStreetStationOwnedP3
            // 
            this.livStreetStationOwnedP3.BackColor = System.Drawing.Color.Blue;
            this.livStreetStationOwnedP3.BackgroundImage = global::monopoly1.Properties.Resources.hat_transparent_monopolu;
            this.livStreetStationOwnedP3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.livStreetStationOwnedP3.Location = new System.Drawing.Point(1004, 480);
            this.livStreetStationOwnedP3.Name = "livStreetStationOwnedP3";
            this.livStreetStationOwnedP3.Size = new System.Drawing.Size(25, 25);
            this.livStreetStationOwnedP3.TabIndex = 156;
            this.livStreetStationOwnedP3.TabStop = false;
            this.livStreetStationOwnedP3.Visible = false;
            // 
            // livStreetStationOwnedP2
            // 
            this.livStreetStationOwnedP2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.livStreetStationOwnedP2.BackgroundImage = global::monopoly1.Properties.Resources.dog_transparent;
            this.livStreetStationOwnedP2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.livStreetStationOwnedP2.Location = new System.Drawing.Point(1004, 503);
            this.livStreetStationOwnedP2.Name = "livStreetStationOwnedP2";
            this.livStreetStationOwnedP2.Size = new System.Drawing.Size(25, 25);
            this.livStreetStationOwnedP2.TabIndex = 155;
            this.livStreetStationOwnedP2.TabStop = false;
            this.livStreetStationOwnedP2.Visible = false;
            // 
            // livStreetStationOwnedP1
            // 
            this.livStreetStationOwnedP1.BackColor = System.Drawing.Color.Red;
            this.livStreetStationOwnedP1.BackgroundImage = global::monopoly1.Properties.Resources.car_transparent_monopoly;
            this.livStreetStationOwnedP1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.livStreetStationOwnedP1.Image = global::monopoly1.Properties.Resources.car_transparent_monopoly;
            this.livStreetStationOwnedP1.Location = new System.Drawing.Point(1004, 522);
            this.livStreetStationOwnedP1.Name = "livStreetStationOwnedP1";
            this.livStreetStationOwnedP1.Size = new System.Drawing.Size(25, 25);
            this.livStreetStationOwnedP1.TabIndex = 154;
            this.livStreetStationOwnedP1.TabStop = false;
            this.livStreetStationOwnedP1.Visible = false;
            // 
            // parkLaneOwnedP4
            // 
            this.parkLaneOwnedP4.BackColor = System.Drawing.Color.Fuchsia;
            this.parkLaneOwnedP4.BackgroundImage = global::monopoly1.Properties.Resources.wheel_transparent_monopoly;
            this.parkLaneOwnedP4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.parkLaneOwnedP4.Location = new System.Drawing.Point(1024, 629);
            this.parkLaneOwnedP4.Name = "parkLaneOwnedP4";
            this.parkLaneOwnedP4.Size = new System.Drawing.Size(25, 25);
            this.parkLaneOwnedP4.TabIndex = 161;
            this.parkLaneOwnedP4.TabStop = false;
            this.parkLaneOwnedP4.Visible = false;
            // 
            // parkLaneOwnedP3
            // 
            this.parkLaneOwnedP3.BackColor = System.Drawing.Color.Blue;
            this.parkLaneOwnedP3.BackgroundImage = global::monopoly1.Properties.Resources.hat_transparent_monopolu;
            this.parkLaneOwnedP3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.parkLaneOwnedP3.Location = new System.Drawing.Point(1024, 649);
            this.parkLaneOwnedP3.Name = "parkLaneOwnedP3";
            this.parkLaneOwnedP3.Size = new System.Drawing.Size(25, 25);
            this.parkLaneOwnedP3.TabIndex = 160;
            this.parkLaneOwnedP3.TabStop = false;
            this.parkLaneOwnedP3.Visible = false;
            // 
            // parkLaneOwnedP2
            // 
            this.parkLaneOwnedP2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.parkLaneOwnedP2.BackgroundImage = global::monopoly1.Properties.Resources.dog_transparent;
            this.parkLaneOwnedP2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.parkLaneOwnedP2.Location = new System.Drawing.Point(1024, 672);
            this.parkLaneOwnedP2.Name = "parkLaneOwnedP2";
            this.parkLaneOwnedP2.Size = new System.Drawing.Size(25, 25);
            this.parkLaneOwnedP2.TabIndex = 159;
            this.parkLaneOwnedP2.TabStop = false;
            this.parkLaneOwnedP2.Visible = false;
            // 
            // parkLaneOwnedP1
            // 
            this.parkLaneOwnedP1.BackColor = System.Drawing.Color.Red;
            this.parkLaneOwnedP1.BackgroundImage = global::monopoly1.Properties.Resources.car_transparent_monopoly;
            this.parkLaneOwnedP1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.parkLaneOwnedP1.Image = global::monopoly1.Properties.Resources.car_transparent_monopoly;
            this.parkLaneOwnedP1.Location = new System.Drawing.Point(1024, 691);
            this.parkLaneOwnedP1.Name = "parkLaneOwnedP1";
            this.parkLaneOwnedP1.Size = new System.Drawing.Size(25, 25);
            this.parkLaneOwnedP1.TabIndex = 158;
            this.parkLaneOwnedP1.TabStop = false;
            this.parkLaneOwnedP1.Visible = false;
            // 
            // mayfairOwnedP4
            // 
            this.mayfairOwnedP4.BackColor = System.Drawing.Color.Fuchsia;
            this.mayfairOwnedP4.BackgroundImage = global::monopoly1.Properties.Resources.wheel_transparent_monopoly;
            this.mayfairOwnedP4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.mayfairOwnedP4.Location = new System.Drawing.Point(1024, 790);
            this.mayfairOwnedP4.Name = "mayfairOwnedP4";
            this.mayfairOwnedP4.Size = new System.Drawing.Size(25, 25);
            this.mayfairOwnedP4.TabIndex = 165;
            this.mayfairOwnedP4.TabStop = false;
            this.mayfairOwnedP4.Visible = false;
            // 
            // mayfairOwnedP3
            // 
            this.mayfairOwnedP3.BackColor = System.Drawing.Color.Blue;
            this.mayfairOwnedP3.BackgroundImage = global::monopoly1.Properties.Resources.hat_transparent_monopolu;
            this.mayfairOwnedP3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.mayfairOwnedP3.Location = new System.Drawing.Point(1024, 810);
            this.mayfairOwnedP3.Name = "mayfairOwnedP3";
            this.mayfairOwnedP3.Size = new System.Drawing.Size(25, 25);
            this.mayfairOwnedP3.TabIndex = 164;
            this.mayfairOwnedP3.TabStop = false;
            this.mayfairOwnedP3.Visible = false;
            // 
            // mayfairOwnedP2
            // 
            this.mayfairOwnedP2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.mayfairOwnedP2.BackgroundImage = global::monopoly1.Properties.Resources.dog_transparent;
            this.mayfairOwnedP2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.mayfairOwnedP2.Location = new System.Drawing.Point(1024, 833);
            this.mayfairOwnedP2.Name = "mayfairOwnedP2";
            this.mayfairOwnedP2.Size = new System.Drawing.Size(25, 25);
            this.mayfairOwnedP2.TabIndex = 163;
            this.mayfairOwnedP2.TabStop = false;
            this.mayfairOwnedP2.Visible = false;
            // 
            // mayfairOwnedP1
            // 
            this.mayfairOwnedP1.BackColor = System.Drawing.Color.Red;
            this.mayfairOwnedP1.BackgroundImage = global::monopoly1.Properties.Resources.car_transparent_monopoly;
            this.mayfairOwnedP1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.mayfairOwnedP1.Image = global::monopoly1.Properties.Resources.car_transparent_monopoly;
            this.mayfairOwnedP1.Location = new System.Drawing.Point(1024, 852);
            this.mayfairOwnedP1.Name = "mayfairOwnedP1";
            this.mayfairOwnedP1.Size = new System.Drawing.Size(25, 25);
            this.mayfairOwnedP1.TabIndex = 162;
            this.mayfairOwnedP1.TabStop = false;
            this.mayfairOwnedP1.Visible = false;
            // 
            // player1TurnTB
            // 
            this.player1TurnTB.BackColor = System.Drawing.Color.Red;
            this.player1TurnTB.Font = new System.Drawing.Font("Elephant", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.player1TurnTB.Location = new System.Drawing.Point(535, 173);
            this.player1TurnTB.Name = "player1TurnTB";
            this.player1TurnTB.Size = new System.Drawing.Size(261, 54);
            this.player1TurnTB.TabIndex = 166;
            this.player1TurnTB.Text = "Player 1 Turn";
            this.player1TurnTB.Visible = false;
            // 
            // player2TurnTB
            // 
            this.player2TurnTB.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.player2TurnTB.Font = new System.Drawing.Font("Elephant", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.player2TurnTB.Location = new System.Drawing.Point(535, 173);
            this.player2TurnTB.Name = "player2TurnTB";
            this.player2TurnTB.Size = new System.Drawing.Size(261, 54);
            this.player2TurnTB.TabIndex = 167;
            this.player2TurnTB.Text = "Player 2 Turn";
            this.player2TurnTB.Visible = false;
            // 
            // player3TurnTB
            // 
            this.player3TurnTB.BackColor = System.Drawing.Color.Blue;
            this.player3TurnTB.Font = new System.Drawing.Font("Elephant", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.player3TurnTB.Location = new System.Drawing.Point(535, 173);
            this.player3TurnTB.Name = "player3TurnTB";
            this.player3TurnTB.Size = new System.Drawing.Size(261, 54);
            this.player3TurnTB.TabIndex = 168;
            this.player3TurnTB.Text = "Player 3 Turn";
            this.player3TurnTB.Visible = false;
            // 
            // player4TurnTB
            // 
            this.player4TurnTB.BackColor = System.Drawing.Color.Fuchsia;
            this.player4TurnTB.Font = new System.Drawing.Font("Elephant", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.player4TurnTB.Location = new System.Drawing.Point(535, 173);
            this.player4TurnTB.Name = "player4TurnTB";
            this.player4TurnTB.Size = new System.Drawing.Size(261, 54);
            this.player4TurnTB.TabIndex = 169;
            this.player4TurnTB.Text = "Player 4 Turn";
            this.player4TurnTB.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::monopoly1.Properties.Resources.Monopoly_background;
            this.ClientSize = new System.Drawing.Size(1924, 1050);
            this.Controls.Add(this.player4TurnTB);
            this.Controls.Add(this.player3TurnTB);
            this.Controls.Add(this.player2TurnTB);
            this.Controls.Add(this.player1TurnTB);
            this.Controls.Add(this.mayfairOwnedP4);
            this.Controls.Add(this.mayfairOwnedP3);
            this.Controls.Add(this.mayfairOwnedP2);
            this.Controls.Add(this.mayfairOwnedP1);
            this.Controls.Add(this.parkLaneOwnedP4);
            this.Controls.Add(this.parkLaneOwnedP3);
            this.Controls.Add(this.parkLaneOwnedP2);
            this.Controls.Add(this.parkLaneOwnedP1);
            this.Controls.Add(this.livStreetStationOwnedP4);
            this.Controls.Add(this.livStreetStationOwnedP3);
            this.Controls.Add(this.livStreetStationOwnedP2);
            this.Controls.Add(this.livStreetStationOwnedP1);
            this.Controls.Add(this.bondStreetOwnedP4);
            this.Controls.Add(this.bondStreetOwnedP3);
            this.Controls.Add(this.bondStreetOwnedP2);
            this.Controls.Add(this.bondStreetOwnedP1);
            this.Controls.Add(this.oxfordStreetOwnedP4);
            this.Controls.Add(this.oxfordStreetOwnedP3);
            this.Controls.Add(this.oxfordStreetOwnedP2);
            this.Controls.Add(this.oxfordStreetOwnedP1);
            this.Controls.Add(this.regentStreetOwnedP4);
            this.Controls.Add(this.regentStreetOwnedP3);
            this.Controls.Add(this.regentStreetOwnedP2);
            this.Controls.Add(this.regentStreetOwnedP1);
            this.Controls.Add(this.waterworksOwnedP4);
            this.Controls.Add(this.waterworksOwnedP3);
            this.Controls.Add(this.waterworksOwnedP2);
            this.Controls.Add(this.waterworksOwnedP1);
            this.Controls.Add(this.fenchurchStationOwnedP4);
            this.Controls.Add(this.fenchurchStationOwnedP3);
            this.Controls.Add(this.fenchurchStationOwnedP2);
            this.Controls.Add(this.fenchurchStationOwnedP1);
            this.Controls.Add(this.piccadillyOwnedP4);
            this.Controls.Add(this.piccadillyOwnedP3);
            this.Controls.Add(this.piccadillyOwnedP2);
            this.Controls.Add(this.piccadillyOwnedP1);
            this.Controls.Add(this.coventryStreetOwnedP4);
            this.Controls.Add(this.coventryStreetOwnedP3);
            this.Controls.Add(this.coventryStreetOwnedP2);
            this.Controls.Add(this.coventryStreetOwnedP1);
            this.Controls.Add(this.leicesterSquareOwnedP4);
            this.Controls.Add(this.leicesterSquareOwnedP3);
            this.Controls.Add(this.leicesterSquareOwnedP2);
            this.Controls.Add(this.leicesterSquareOwnedP1);
            this.Controls.Add(this.trafalgarSquareOwnedP4);
            this.Controls.Add(this.trafalgarSquareOwnedP3);
            this.Controls.Add(this.trafalgarSquareOwnedP2);
            this.Controls.Add(this.trafalgarSquareOwnedP1);
            this.Controls.Add(this.FleetStreetOwnedP4);
            this.Controls.Add(this.FleetStreetOwnedP3);
            this.Controls.Add(this.FleetStreetOwnedP2);
            this.Controls.Add(this.FleetStreetOwnedP1);
            this.Controls.Add(this.strandOwnedP4);
            this.Controls.Add(this.strandOwnedP3);
            this.Controls.Add(this.strandOwnedP2);
            this.Controls.Add(this.strandOwnedP1);
            this.Controls.Add(this.electricCompanyOwnedP4);
            this.Controls.Add(this.electricCompanyOwnedP3);
            this.Controls.Add(this.electricCompanyOwnedP2);
            this.Controls.Add(this.electricCompanyOwnedP1);
            this.Controls.Add(this.vineStreetOwnedP4);
            this.Controls.Add(this.vineStreetOwnedP3);
            this.Controls.Add(this.vineStreetOwnedP2);
            this.Controls.Add(this.vineStreetOwnedP1);
            this.Controls.Add(this.marlboroughStreetOwnedP4);
            this.Controls.Add(this.marlboroughStreetOwnedP3);
            this.Controls.Add(this.marlboroughStreetOwnedP2);
            this.Controls.Add(this.marlboroughStreetOwnedP1);
            this.Controls.Add(this.bowStreetOwnedP4);
            this.Controls.Add(this.bowStreetOwnedP3);
            this.Controls.Add(this.bowStreetOwnedP2);
            this.Controls.Add(this.bowStreetOwnedP1);
            this.Controls.Add(this.maryleboneStationOwnedP4);
            this.Controls.Add(this.maryleboneStationOwnedP3);
            this.Controls.Add(this.maryleboneStationOwnedP2);
            this.Controls.Add(this.maryleboneStationOwnedP1);
            this.Controls.Add(this.northumberlandOwnedP4);
            this.Controls.Add(this.northumberlandOwnedP3);
            this.Controls.Add(this.northumberlandOwnedP2);
            this.Controls.Add(this.northumberlandOwnedP1);
            this.Controls.Add(this.whitehallOwnedP4);
            this.Controls.Add(this.whitehallOwnedP3);
            this.Controls.Add(this.whitehallOwnedP2);
            this.Controls.Add(this.whitehallOwnedP1);
            this.Controls.Add(this.pallMallOwnedP4);
            this.Controls.Add(this.pallMallOwnedP3);
            this.Controls.Add(this.pallMallOwnedP2);
            this.Controls.Add(this.pallMallOwnedP1);
            this.Controls.Add(this.pentonvilleRoadOwnedP4);
            this.Controls.Add(this.pentonvilleRoadOwnedP3);
            this.Controls.Add(this.pentonvilleRoadOwnedP2);
            this.Controls.Add(this.pentonvilleRoadOwnedP1);
            this.Controls.Add(this.eustonRoadOwnedP4);
            this.Controls.Add(this.eustonRoadOwnedP3);
            this.Controls.Add(this.eustonRoadOwnedP2);
            this.Controls.Add(this.eustonRoadOwnedP1);
            this.Controls.Add(this.angelIslingtonOwnedP4);
            this.Controls.Add(this.angelIslingtonOwnedP3);
            this.Controls.Add(this.angelIslingtonOwnedP2);
            this.Controls.Add(this.angelIslingtonOwnedP1);
            this.Controls.Add(this.kingsCrossOwnedP4);
            this.Controls.Add(this.kingsCrossOwnedP3);
            this.Controls.Add(this.kingsCrossOwnedP2);
            this.Controls.Add(this.kingsCrossOwnedP1);
            this.Controls.Add(this.whitechapelRoadOwnedP4);
            this.Controls.Add(this.whitechapelRoadOwnedP3);
            this.Controls.Add(this.whitechapelRoadOwnedP2);
            this.Controls.Add(this.whitechapelRoadOwnedP1);
            this.Controls.Add(this.oldKentRoadOwnedP4);
            this.Controls.Add(this.oldKentRoadOwnedP3);
            this.Controls.Add(this.oldKentRoadOwnedP2);
            this.Controls.Add(this.oldKentRoadOwnedP1);
            this.Controls.Add(this.endTurn);
            this.Controls.Add(this.poundP2);
            this.Controls.Add(this.poundP3);
            this.Controls.Add(this.poundP4);
            this.Controls.Add(this.poundP1);
            this.Controls.Add(this.debugPlayer4Move);
            this.Controls.Add(this.debugPlayer3Move);
            this.Controls.Add(this.debugPlayer2Move);
            this.Controls.Add(this.DebugPlayer1Move);
            this.Controls.Add(this.player2PositionTextBox);
            this.Controls.Add(this.player3PositionTextBox);
            this.Controls.Add(this.player4PositionTextBox);
            this.Controls.Add(this.player1PositionTextBox);
            this.Controls.Add(this.player4PositionDebug);
            this.Controls.Add(this.player3PositionDebug);
            this.Controls.Add(this.player2PositionDebug);
            this.Controls.Add(this.player1PositionDebug);
            this.Controls.Add(this.DebugLabel);
            this.Controls.Add(this.startGameButton);
            this.Controls.Add(this.startPlayer4);
            this.Controls.Add(this.startPlayer3);
            this.Controls.Add(this.startPlayer2);
            this.Controls.Add(this.startPlayer1);
            this.Controls.Add(this.howManyPlayersTB);
            this.Controls.Add(this.TotalDiceValue);
            this.Controls.Add(this.Dice2ValueLabel);
            this.Controls.Add(this.Dice1ValueLabel);
            this.Controls.Add(this.ThrowDiceButton);
            this.Controls.Add(this.DicePictureBox2);
            this.Controls.Add(this.DicePictureBox1);
            this.Controls.Add(this.Chance);
            this.Controls.Add(this.CommunityChest);
            this.Controls.Add(this.Player2MoneyValue);
            this.Controls.Add(this.Player3MoneyValue);
            this.Controls.Add(this.Player4MoneyValue);
            this.Controls.Add(this.Player1MoneyValue);
            this.Controls.Add(this.Player2ScoreboardName);
            this.Controls.Add(this.Player3ScoreboardName);
            this.Controls.Add(this.Player4ScoreboardName);
            this.Controls.Add(this.Player1ScoreboardName);
            this.Controls.Add(this.ScoreBoardHeader);
            this.Controls.Add(this.player3GamePiece);
            this.Controls.Add(this.player2GamePiece);
            this.Controls.Add(this.player1GamePiece);
            this.Controls.Add(this.player4GamePiece);
            this.Controls.Add(this.MonopolyBoard);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.MonopolyBoard)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.player4GamePiece)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.player1GamePiece)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.player2GamePiece)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.player3GamePiece)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.CommunityChest)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Chance)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DicePictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DicePictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.oldKentRoadOwnedP1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.oldKentRoadOwnedP2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.oldKentRoadOwnedP3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.oldKentRoadOwnedP4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.whitechapelRoadOwnedP4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.whitechapelRoadOwnedP3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.whitechapelRoadOwnedP2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.whitechapelRoadOwnedP1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kingsCrossOwnedP4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kingsCrossOwnedP3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kingsCrossOwnedP2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kingsCrossOwnedP1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.angelIslingtonOwnedP4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.angelIslingtonOwnedP3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.angelIslingtonOwnedP2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.angelIslingtonOwnedP1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.eustonRoadOwnedP4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.eustonRoadOwnedP3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.eustonRoadOwnedP2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.eustonRoadOwnedP1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pentonvilleRoadOwnedP4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pentonvilleRoadOwnedP3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pentonvilleRoadOwnedP2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pentonvilleRoadOwnedP1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pallMallOwnedP4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pallMallOwnedP3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pallMallOwnedP2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pallMallOwnedP1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.whitehallOwnedP4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.whitehallOwnedP3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.whitehallOwnedP2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.whitehallOwnedP1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.northumberlandOwnedP4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.northumberlandOwnedP3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.northumberlandOwnedP2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.northumberlandOwnedP1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.maryleboneStationOwnedP4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.maryleboneStationOwnedP3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.maryleboneStationOwnedP2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.maryleboneStationOwnedP1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bowStreetOwnedP4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bowStreetOwnedP3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bowStreetOwnedP2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bowStreetOwnedP1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.marlboroughStreetOwnedP4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.marlboroughStreetOwnedP3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.marlboroughStreetOwnedP2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.marlboroughStreetOwnedP1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vineStreetOwnedP4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vineStreetOwnedP3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vineStreetOwnedP2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vineStreetOwnedP1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.electricCompanyOwnedP4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.electricCompanyOwnedP3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.electricCompanyOwnedP2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.electricCompanyOwnedP1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.strandOwnedP4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.strandOwnedP3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.strandOwnedP2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.strandOwnedP1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.FleetStreetOwnedP4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.FleetStreetOwnedP3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.FleetStreetOwnedP2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.FleetStreetOwnedP1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trafalgarSquareOwnedP4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trafalgarSquareOwnedP3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trafalgarSquareOwnedP2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trafalgarSquareOwnedP1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.leicesterSquareOwnedP4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.leicesterSquareOwnedP3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.leicesterSquareOwnedP2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.leicesterSquareOwnedP1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.coventryStreetOwnedP4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.coventryStreetOwnedP3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.coventryStreetOwnedP2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.coventryStreetOwnedP1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.piccadillyOwnedP4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.piccadillyOwnedP3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.piccadillyOwnedP2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.piccadillyOwnedP1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fenchurchStationOwnedP4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fenchurchStationOwnedP3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fenchurchStationOwnedP2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fenchurchStationOwnedP1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.waterworksOwnedP4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.waterworksOwnedP3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.waterworksOwnedP2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.waterworksOwnedP1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.regentStreetOwnedP4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.regentStreetOwnedP3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.regentStreetOwnedP2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.regentStreetOwnedP1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.oxfordStreetOwnedP4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.oxfordStreetOwnedP3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.oxfordStreetOwnedP2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.oxfordStreetOwnedP1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bondStreetOwnedP4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bondStreetOwnedP3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bondStreetOwnedP2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bondStreetOwnedP1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.livStreetStationOwnedP4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.livStreetStationOwnedP3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.livStreetStationOwnedP2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.livStreetStationOwnedP1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.parkLaneOwnedP4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.parkLaneOwnedP3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.parkLaneOwnedP2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.parkLaneOwnedP1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mayfairOwnedP4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mayfairOwnedP3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mayfairOwnedP2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mayfairOwnedP1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox MonopolyBoard;
        private System.Windows.Forms.PictureBox player4GamePiece;
        private System.Windows.Forms.PictureBox player1GamePiece;
        private System.Windows.Forms.PictureBox player2GamePiece;
        private System.Windows.Forms.PictureBox player3GamePiece;
        private System.Windows.Forms.TextBox ScoreBoardHeader;
        private System.Windows.Forms.TextBox Player1ScoreboardName;
        private System.Windows.Forms.TextBox Player4ScoreboardName;
        private System.Windows.Forms.TextBox Player3ScoreboardName;
        private System.Windows.Forms.TextBox Player2ScoreboardName;
        private System.Windows.Forms.TextBox Player1MoneyValue;
        private System.Windows.Forms.TextBox Player4MoneyValue;
        private System.Windows.Forms.TextBox Player3MoneyValue;
        private System.Windows.Forms.TextBox Player2MoneyValue;
        private System.Windows.Forms.PictureBox CommunityChest;
        private System.Windows.Forms.PictureBox Chance;
        private System.Windows.Forms.PictureBox DicePictureBox1;
        private System.Windows.Forms.PictureBox DicePictureBox2;
        private System.Windows.Forms.Button ThrowDiceButton;
        private System.Windows.Forms.Label Dice1ValueLabel;
        private System.Windows.Forms.Label Dice2ValueLabel;
        private System.Windows.Forms.Label TotalDiceValue;
        private System.Windows.Forms.TextBox howManyPlayersTB;
        private System.Windows.Forms.Button startPlayer1;
        private System.Windows.Forms.Button startPlayer2;
        private System.Windows.Forms.Button startPlayer3;
        private System.Windows.Forms.Button startPlayer4;
        private System.Windows.Forms.Button startGameButton;
        private System.Windows.Forms.Label DebugLabel;
        private System.Windows.Forms.Label player1PositionDebug;
        private System.Windows.Forms.Label player2PositionDebug;
        private System.Windows.Forms.Label player3PositionDebug;
        private System.Windows.Forms.Label player4PositionDebug;
        private System.Windows.Forms.TextBox player1PositionTextBox;
        private System.Windows.Forms.TextBox player4PositionTextBox;
        private System.Windows.Forms.TextBox player3PositionTextBox;
        private System.Windows.Forms.TextBox player2PositionTextBox;
        private System.Windows.Forms.Button DebugPlayer1Move;
        private System.Windows.Forms.Button debugPlayer2Move;
        private System.Windows.Forms.Button debugPlayer3Move;
        private System.Windows.Forms.Button debugPlayer4Move;
        private System.Windows.Forms.TextBox poundP1;
        private System.Windows.Forms.TextBox poundP4;
        private System.Windows.Forms.TextBox poundP3;
        private System.Windows.Forms.TextBox poundP2;
        private System.Windows.Forms.Button endTurn;
        private System.Windows.Forms.PictureBox oldKentRoadOwnedP1;
        private System.Windows.Forms.PictureBox oldKentRoadOwnedP2;
        private System.Windows.Forms.PictureBox oldKentRoadOwnedP3;
        private System.Windows.Forms.PictureBox oldKentRoadOwnedP4;
        private System.Windows.Forms.PictureBox whitechapelRoadOwnedP4;
        private System.Windows.Forms.PictureBox whitechapelRoadOwnedP3;
        private System.Windows.Forms.PictureBox whitechapelRoadOwnedP2;
        private System.Windows.Forms.PictureBox whitechapelRoadOwnedP1;
        private System.Windows.Forms.PictureBox kingsCrossOwnedP4;
        private System.Windows.Forms.PictureBox kingsCrossOwnedP3;
        private System.Windows.Forms.PictureBox kingsCrossOwnedP2;
        private System.Windows.Forms.PictureBox kingsCrossOwnedP1;
        private System.Windows.Forms.PictureBox angelIslingtonOwnedP4;
        private System.Windows.Forms.PictureBox angelIslingtonOwnedP3;
        private System.Windows.Forms.PictureBox angelIslingtonOwnedP2;
        private System.Windows.Forms.PictureBox angelIslingtonOwnedP1;
        private System.Windows.Forms.PictureBox eustonRoadOwnedP4;
        private System.Windows.Forms.PictureBox eustonRoadOwnedP3;
        private System.Windows.Forms.PictureBox eustonRoadOwnedP2;
        private System.Windows.Forms.PictureBox eustonRoadOwnedP1;
        private System.Windows.Forms.PictureBox pentonvilleRoadOwnedP4;
        private System.Windows.Forms.PictureBox pentonvilleRoadOwnedP3;
        private System.Windows.Forms.PictureBox pentonvilleRoadOwnedP2;
        private System.Windows.Forms.PictureBox pentonvilleRoadOwnedP1;
        private System.Windows.Forms.PictureBox pallMallOwnedP4;
        private System.Windows.Forms.PictureBox pallMallOwnedP3;
        private System.Windows.Forms.PictureBox pallMallOwnedP2;
        private System.Windows.Forms.PictureBox pallMallOwnedP1;
        private System.Windows.Forms.PictureBox whitehallOwnedP4;
        private System.Windows.Forms.PictureBox whitehallOwnedP3;
        private System.Windows.Forms.PictureBox whitehallOwnedP2;
        private System.Windows.Forms.PictureBox whitehallOwnedP1;
        private System.Windows.Forms.PictureBox northumberlandOwnedP4;
        private System.Windows.Forms.PictureBox northumberlandOwnedP3;
        private System.Windows.Forms.PictureBox northumberlandOwnedP2;
        private System.Windows.Forms.PictureBox northumberlandOwnedP1;
        private System.Windows.Forms.PictureBox maryleboneStationOwnedP4;
        private System.Windows.Forms.PictureBox maryleboneStationOwnedP3;
        private System.Windows.Forms.PictureBox maryleboneStationOwnedP2;
        private System.Windows.Forms.PictureBox maryleboneStationOwnedP1;
        private System.Windows.Forms.PictureBox bowStreetOwnedP4;
        private System.Windows.Forms.PictureBox bowStreetOwnedP3;
        private System.Windows.Forms.PictureBox bowStreetOwnedP2;
        private System.Windows.Forms.PictureBox bowStreetOwnedP1;
        private System.Windows.Forms.PictureBox marlboroughStreetOwnedP4;
        private System.Windows.Forms.PictureBox marlboroughStreetOwnedP3;
        private System.Windows.Forms.PictureBox marlboroughStreetOwnedP2;
        private System.Windows.Forms.PictureBox marlboroughStreetOwnedP1;
        private System.Windows.Forms.PictureBox vineStreetOwnedP4;
        private System.Windows.Forms.PictureBox vineStreetOwnedP3;
        private System.Windows.Forms.PictureBox vineStreetOwnedP2;
        private System.Windows.Forms.PictureBox vineStreetOwnedP1;
        private System.Windows.Forms.PictureBox electricCompanyOwnedP4;
        private System.Windows.Forms.PictureBox electricCompanyOwnedP3;
        private System.Windows.Forms.PictureBox electricCompanyOwnedP2;
        private System.Windows.Forms.PictureBox electricCompanyOwnedP1;
        private System.Windows.Forms.PictureBox strandOwnedP4;
        private System.Windows.Forms.PictureBox strandOwnedP3;
        private System.Windows.Forms.PictureBox strandOwnedP2;
        private System.Windows.Forms.PictureBox strandOwnedP1;
        private System.Windows.Forms.PictureBox FleetStreetOwnedP4;
        private System.Windows.Forms.PictureBox FleetStreetOwnedP3;
        private System.Windows.Forms.PictureBox FleetStreetOwnedP2;
        private System.Windows.Forms.PictureBox FleetStreetOwnedP1;
        private System.Windows.Forms.PictureBox trafalgarSquareOwnedP4;
        private System.Windows.Forms.PictureBox trafalgarSquareOwnedP3;
        private System.Windows.Forms.PictureBox trafalgarSquareOwnedP2;
        private System.Windows.Forms.PictureBox trafalgarSquareOwnedP1;
        private System.Windows.Forms.PictureBox leicesterSquareOwnedP4;
        private System.Windows.Forms.PictureBox leicesterSquareOwnedP3;
        private System.Windows.Forms.PictureBox leicesterSquareOwnedP2;
        private System.Windows.Forms.PictureBox leicesterSquareOwnedP1;
        private System.Windows.Forms.PictureBox coventryStreetOwnedP4;
        private System.Windows.Forms.PictureBox coventryStreetOwnedP3;
        private System.Windows.Forms.PictureBox coventryStreetOwnedP2;
        private System.Windows.Forms.PictureBox coventryStreetOwnedP1;
        private System.Windows.Forms.PictureBox piccadillyOwnedP4;
        private System.Windows.Forms.PictureBox piccadillyOwnedP3;
        private System.Windows.Forms.PictureBox piccadillyOwnedP2;
        private System.Windows.Forms.PictureBox piccadillyOwnedP1;
        private System.Windows.Forms.PictureBox fenchurchStationOwnedP4;
        private System.Windows.Forms.PictureBox fenchurchStationOwnedP3;
        private System.Windows.Forms.PictureBox fenchurchStationOwnedP2;
        private System.Windows.Forms.PictureBox fenchurchStationOwnedP1;
        private System.Windows.Forms.PictureBox waterworksOwnedP4;
        private System.Windows.Forms.PictureBox waterworksOwnedP3;
        private System.Windows.Forms.PictureBox waterworksOwnedP2;
        private System.Windows.Forms.PictureBox waterworksOwnedP1;
        private System.Windows.Forms.PictureBox regentStreetOwnedP4;
        private System.Windows.Forms.PictureBox regentStreetOwnedP3;
        private System.Windows.Forms.PictureBox regentStreetOwnedP2;
        private System.Windows.Forms.PictureBox regentStreetOwnedP1;
        private System.Windows.Forms.PictureBox oxfordStreetOwnedP4;
        private System.Windows.Forms.PictureBox oxfordStreetOwnedP3;
        private System.Windows.Forms.PictureBox oxfordStreetOwnedP2;
        private System.Windows.Forms.PictureBox oxfordStreetOwnedP1;
        private System.Windows.Forms.PictureBox bondStreetOwnedP4;
        private System.Windows.Forms.PictureBox bondStreetOwnedP3;
        private System.Windows.Forms.PictureBox bondStreetOwnedP2;
        private System.Windows.Forms.PictureBox bondStreetOwnedP1;
        private System.Windows.Forms.PictureBox livStreetStationOwnedP4;
        private System.Windows.Forms.PictureBox livStreetStationOwnedP3;
        private System.Windows.Forms.PictureBox livStreetStationOwnedP2;
        private System.Windows.Forms.PictureBox livStreetStationOwnedP1;
        private System.Windows.Forms.PictureBox parkLaneOwnedP4;
        private System.Windows.Forms.PictureBox parkLaneOwnedP3;
        private System.Windows.Forms.PictureBox parkLaneOwnedP2;
        private System.Windows.Forms.PictureBox parkLaneOwnedP1;
        private System.Windows.Forms.PictureBox mayfairOwnedP4;
        private System.Windows.Forms.PictureBox mayfairOwnedP3;
        private System.Windows.Forms.PictureBox mayfairOwnedP2;
        private System.Windows.Forms.PictureBox mayfairOwnedP1;
        private System.Windows.Forms.TextBox player1TurnTB;
        private System.Windows.Forms.TextBox player2TurnTB;
        private System.Windows.Forms.TextBox player3TurnTB;
        private System.Windows.Forms.TextBox player4TurnTB;
    }
}

